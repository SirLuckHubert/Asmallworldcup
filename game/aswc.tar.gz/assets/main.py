"""
RAGDOLL FOOTBALL - 2D side-view physics football, fling-to-move.

Single file, pygame only. Everything is drawn procedurally. Optional audio
in the same folder as this script (.ogg is used first, then .mp3 / .wav -
the browser build can only play .ogg):
  ballkick1          played when the ball gets hit
  playingmusic1      match music (each match picks this or playingmusic2)
  playingmusic2      second match track
  menu1              menus + shop
  openingpack        pack opening for pool A/B players - reveals are timed to it:
                     flag 0:02, position 0:03.5, club 0:05, player 0:07
  impossiblemodeselect  plays while Impossible is picked + on its VS screen
  shock              match intro: TEAM1 / VS / TEAM2 each land with a shock
  cheering           crowd on every goal
  (optional) creditsmusic1  full-time / credits theme

BROWSER BUILD: the loop is async, so pygbag can run this file as main.py.
  In the browser the save goes into the page's localStorage and is handed to
  the website (window.aswcSave), which keeps it against the player's Google
  account. On the desktop it is still save.json next to the script.
  See web/README.md for the build and the site.

THE BALL runs in its own, slower time (BALL_TIME): same arcs, a fifth slower. It
  also takes on the movement of whatever body part touches it (BALL_CARRY), so
  running through it drags it with you instead of punting it away.

LEVELS: win 100 XP, draw 50, loss 20, +10 per goal, +300 for a trophy.
  Level n -> n+1 needs 200 + 100*n XP; each level-up pays 50*level coins.
  Level 5 unlocks IMPOSSIBLE (World Cup only): the CPU never hesitates, reacts
  twice as fast, throws harder, and every opponent card gets +20 rating /
  shooting / strength. Every Impossible match pays 3x coins.
REN AOYAGI (187) is retired: REN_IN_GAME = False, so his card never loads and
  nobody can own or play him. His stats, portrait, sprites, ability kit and
  cutscenes are all still in this file - set REN_IN_GAME = True to put him back,
  and he is then locked behind winning the whole World Cup with JAPAN on
  IMPOSSIBLE (all 7 rounds; dropping the difficulty mid-run cancels it).
PEDRO NETO (150, Chelsea) is the admin card: never in a pack, never in the shop,
  never exchangeable. Only the website's admin console can put him in a save.
MATCH INTRO: round title card, then TEAM1 / VS / TEAM2 in big yellow letters
  over the blurred stadium (like the original), ~6 s, click skips.
STAMINA: -50 per half played; after every match everyone gets +25 and anyone
  who sat the whole match out gets +50 instead.
ESC in a match: pause menu - RESUME, or QUIT MATCH which counts as a 0-3 loss.
  head.png / torso.png / leg.png / ball.png  sprite overrides

CONTROLS
  Mouse    click anywhere, drag, release -> you get FLUNG toward the mouse.
           Longer drag = more power (full power at 600 px). Throw as often as
           you like, even mid-air. Every release throws.
  1 2 3    CPU difficulty: easy / normal / hard
  P        pause      M  mute      R  restart      F11  fullscreen on/off
  F1       show colliders      Esc  quit

How the body works
  The torso + head are one rigid body with real rotation. Its bottom is
  rounded, so it can't stand: it slumps over and lies on the floor until you
  throw it again. In the air it keeps its spin and tumbles freely.
  Arms and legs are single rigid pieces whose angle is a world angle, so
  gravity always pulls them toward the floor whatever way the torso faces
  (fall over to the right and the top arm swings ~90 deg to hang down, while
  the bottom arm tucks under the torso out of sight). Limbs lie flat on the
  floor instead of passing through it. Legs can swing ~100 deg each way from
  the hip, so they drop into the splits.

Match rules
  First to 3 goals wins. No countdown: the ball drops straight away, and
  after a goal it drops on the side of the team that conceded. The GOAL! /
  OWN GOAL! banner stays (in slow-mo) until you click. Hands and feet can hit
  the ball, and limbs drape over the goal frame.

Look & sound
  Pixel art (PIXEL = 3), sunset sky, striped grass, no line markings, no
  outlines, no shadows. Scores in the top corners, no other HUD.
  Subtle screen shake. Sounds: ballkick1.mp3, whistle, shock.mp3 (the TEAM vs
  TEAM intro) and cheering.mp3 (goals) - see SOUNDS_ON. Quiet music.

Team select + World Cup run
  Put the 12 flags (ARG.png, BRA.png, CRO.png, ENG.png, FRA.png, MOR.png,
  JPN.png, POL.png, NET.png, AUS.png, SPA.png, POR.png) in the same folder as
  this script. Pick your team, then click the arrow: a white outline hops
  across the flags, slows down and lands on your opponent - click to start
  the match. Win and you're back on the bracket (your score is shown in the
  round's box) - click the arrow to draw the next round (DAY1, DAY2, DAY3,
  R 16, QRTR, SEMI, FINL). Win all 7 to be champions. Lose once and it's
  GAME OVER: click to restart and pick a team again.
  EASY / MEDIUM / HARD buttons (under the arrow) set the CPU difficulty.
  Every team has 3 players (EASY / MEDIUM / HARD), you or the CPU. Their
  sprites are in the "sprites" folder (TEAM_player_head/torso/arm/leg.png);
  the player list is TEAM_PLAYERS near the top of the script.

Club Football
  Pick CLUB FOOTBALL on the start screen. Choose one of 20 clubs and a
  difficulty (EASY sends out one of the club's 2 Bad players, MEDIUM one of
  the 2 Alright ones, HARD the star). 12 rounds, shown 6 above 6 below: the
  white outline draws your opponent (never one you've faced in the last 2
  rounds), you play them, and every other club plays too (simulated from
  real-life strength, see CLUBS). Then the league table: 3 pts a win. Bottom
  3 for 2 rounds in a row = removed from the league; if that's you, GAME
  OVER. Top after 12 rounds = CHAMPIONS. Badges: sprites/<CODE>_badge.png,
  or drop your own sprites/<CODE>_logo.png to use that instead.

Menu, cards and saving
  TUTORIAL (first launch of a new save): hands-on steps on the pitch (drag to
  throw, throw mid-air, hit the ball, score past a dummy robot), a tour of the
  menu, then 900 coins that you must spend on 3 packs, then pick one beginner
  card (Palmer 101 / Bellingham 100 / Van Dijk 99) - he replaces your weakest
  starter. SKIP skips the lessons but not the packs + pick. Replay the lessons
  any time from TEAM (the rewards only come once).
  The game opens on a menu: PLAY, STORE, TEAM, QUIT. PLAY has WORLD CUP,
  CLUB FOOTBALL, FREEPLAY and PRACTICE.
  FREEPLAY: pick any player you own and any player you own as the CPU (easy /
  medium / hard). Two halves, no lineup, no stamina, no XP - a random 10-100
  coins at full time. Quitting pays nothing.
  PRACTICE: no clock, no score limit. Spawn up to 4 robot CPUs from the panel
  at the top; click a robot to switch it EASY / MEDIUM / HARD / DUMMY (dummies
  just stand there), X removes it. RESET BALL, CLEAR ROBOTS, PLAYER (cycles
  through your squad - card abilities work here too), EXIT.
  Progress is saved to save.json next to the script (coins, cards, squad,
  stamina, your team, the club season). Delete it to start over.
  Coins: win +50, draw +25, loss +10, +2 per goal you score.
  PACKS (draft-style store): the pack list down the left, the featured players
  in sliced panels, the two guarantee bars and 1 DRAW / 10 DRAWS at the bottom;
  WHO'S INSIDE has an A / B / C button that opens that pool's players (the i
  opens pool A), and the list itself has POOL A / POOL B / POOL C tabs. 5 packs: World Cup, 3 club
  packs (21 clubs split 7/7/7) and the NO. 10 PACK (17 playmakers). 300 coins a
  draw, 3,000 for 10 (pity counts every single pack).
  Odds: pool A 1%, pool B 5%, pool C 94%. Pity: pool B or better every 10 packs,
  pool A every 60, counted per pack type.
  Every pack opens with the same walkout as always (pool A/B timed to
  openingpack.mp3, pool C a plain reveal).
  Card art is unchanged too - icons crystal, pool A club/nation, pool B marble,
  pool C plain - EXCEPT the No. 10 pack's own 17 cards, which have three looks of
  their own: A ECLIPSE (black/purple, giant shirt number, metal frame),
  B NEON (navy + cyan scan lines), C STREET (concrete and scratches).
  each (55% bronze / 35% silver / 10% gold). Duplicates stack. New saves
  start with a free starter pack of 5 club players.
  Cards (FC Mobile-style scale): Bad 70-89 bronze, Alright 90-109 silver,
  Good 110-130 gold, ICONS up to 150 (Messi, Ronaldo, Mbappe, Yamal, Salah,
  Van Dijk, Lewandowski, Modric, Suarez) with a white-gold design; World Cup
  cards are navy with a gold trophy trim and the nation's colours.
  Double-click any card for its stats + description.
  ABILITIES: over 100 OVR only. 30 of them - 10 defending, 10 dribbling, 10
  attacking - all passive. 101-110 get 1 bronze, 111-120 1 silver, 121-130 2
  (gold + bronze), 131-140 3 (platinum + silver + bronze), 141+ 4 (diamond, gold,
  silver, bronze). Tier decides how big the effect is. They are fixed per card:
  hand-picked for the big names (ABILITY_SIGNATURE), otherwise drawn from the
  card's position (defenders get defending ones, strikers attacking ones...).
  Both you and the CPU use them. Tier diamonds show on the card, the full list is
  in the card's stats view, and the names sit at the sides of the match HUD.
    OVR  hit power (70 = 85%, 150 = 110%)
    SHO  low = the aim arrow wobbles and your fling goes where it points;
         high = rock steady, and ball hits get steered toward goal
    STR  pull the arrow further for more power; knock other players further
  Abilities: placeholder for later.
  Pack openings: tier A (icons and 120+) get a walkout cutscene (flare,
  position/flag/badge, rating slam, fireworks), tier B (100-119) a short
  one, tier C a plain reveal. Click to skip.
  MY CLUB: team name, 2 colours, pattern (plain/stripes/hoops/sleeves) and
  your squad of 5 cards - they play in your kit with their own heads.
STORE (packs, Star Signing, exchange, Neymar Jr Game Box)
  EXCHANGE: swap players you don't use for STAR POINTS (SP), one copy at a
  time (or every spare duplicate at once). Squad players always keep one copy;
  Neymar Jr, Pedro Neto and Star Signings can't be exchanged. Value by OVR
  (SP_CURVE): 70 = 200, 90 = 600, 100 = 1,250, 110 = 2,500, 120 = 4,500,
  130 = 7,500, 150 = 20,000.
  STAR SIGNING: 40 Star Signing Elite legends (STAR_SIGNINGS), 20K-100K SP.
  Each can be signed once, never sold, and plays in your club squad. Purple
  card: tpl_star_card.png; sprites STAR_<player>_head/torso/arm/leg.png.
Matches
  Two 30-second halves (clock stops for goals). Pick who starts, and at half
  time who plays the second half. Each half costs 50% stamina; sitting out a
  match gives 50% back; a player on 0% can't play. World Cup: your nation's 3
  players, stamina resets each tournament; a knockout draw = golden goal.
  Difficulty now only changes how good the CPU is.

Run `python ragdoll_football.py --selftest` for a headless sanity check.
"""

import array
import asyncio
import json
import math
import os
import random
import sys

import pygame
from pygame import Vector2

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ==========================================================
# CONFIG
# ==========================================================
WIDTH, HEIGHT = 1920, 1080
FPS = 60
# Running inside a browser (pygbag) is far slower than the desktop, so the web build
# draws at a third of the resolution, takes bigger physics steps and caches harder.
WEB_BUILD = (sys.platform == "emscripten")
FIXED_DT = 1.0 / 120.0            # same step everywhere: bigger steps tunnel through the crossbar
MAX_STEPS_PER_FRAME = 3 if WEB_BUILD else 5   # a slow browser frame drops work instead of piling it up

GROUND_Y = HEIGHT - 150
GOAL_DEPTH = 155          # how far the goal mouth reaches in from the wall
GOAL_HEIGHT = 330         # crossbar height above the ground
CROSSBAR_THICK = 11
ROOF_SLOPE = 5            # goal roof tilts slightly toward the pitch so balls roll off

# ---- player body (pixels, torso-local; +y is down) ----
PLAYER_SCALE = 1.15         # player size (1.0 = original size)
TORSO_W, TORSO_H = round(44 * PLAYER_SCALE), round(58 * PLAYER_SCALE)
HEAD_R = round(23 * PLAYER_SCALE)
NECK_GAP = 2
ARM_W, ARM_L = round(15 * PLAYER_SCALE), round(46 * PLAYER_SCALE)
SHOULDER_X = TORSO_W / 2 + ARM_W / 2 - 2     # arms sit on the torso's sides
SHOULDER_Y = -TORSO_H / 2 + 5
LEG_W, LEG_L = round(17 * PLAYER_SCALE), round(44 * PLAYER_SCALE)
HIP_X = round(10 * PLAYER_SCALE)
HIP_Y = TORSO_H / 2 - 3
BOOT_R = round(8 * PLAYER_SCALE)
FOOT_OFFSET = HIP_Y + LEG_L + BOOT_R         # torso centre -> sole
HEAD_TOP = TORSO_H / 2 + NECK_GAP + HEAD_R * 2
BODY_HALF = SHOULDER_X + ARM_W / 2
BODY_R = round(23 * PLAYER_SCALE)   # body capsule radius for ball/opponent hits

# ---- player physics ----
PLAYER_GRAVITY = 2900.0
PLAYER_AIR_DRAG = 0.35
PLAYER_SPEED_CAP = 3300.0
GROUND_FRICTION = 4.5       # per second; high friction, short slide
LAND_BOUNCE_MIN = 700.0     # landings faster than this bounce a little
PLAYER_BOUNCE = 0.22
WALL_BOUNCE = 0.35
PLAYER_MASS = 7.0

THROW_MIN = 700.0
THROW_MAX = 2500.0
THROW_DRAG_RANGE = 600.0    # px of drag for full power
THROW_KEEP = 0.25           # share of old velocity kept when re-thrown
THROW_GROUND_HOP = 260.0    # flat throws from the ground still leave the floor
THROW_COOLDOWN = 0.05       # only stops a double-click firing twice

# ---- ragdoll body ----
HIP_ROUND = round(21 * PLAYER_SCALE)  # rounded bottom: it can't stand, it topples
PLAYER_INERTIA = PLAYER_MASS * (TORSO_W ** 2 + (TORSO_H + 2 * HEAD_R) ** 2) / 12.0
GROUND_RESTITUTION = 0.15
GROUND_MU = 1.1             # floor friction
GROUND_DRAG = 10.0          # extra floor drag: landings stop almost dead
GROUND_ANGULAR_DAMP = 7.0
TOPPLE_PUSH = 5.0           # rad/s^2 nudge so it never balances upright
AIR_ANGULAR_DAMP = 0.15     # spin carries through the air - it tumbles
THROW_SPIN = 0.0012         # spin a throw adds (flung right -> tips back left)
LIMB_LAG = 0.35             # share of shoves (throws/hits/floor) limbs feel
LIMB_FORCE_CAP = 9000.0
LIMB_ABS_DAMP = 0.6
ARM_JOINT_DAMP = 3.0
LEG_JOINT_DAMP = 4.0
LIMB_HIT_SOFTNESS = 0.05    # limbs give a little when they hit the ball
LEG_LIMIT = 1.75            # ~100 deg each way from the hip -> full splits

# ---- ball ----
BALL_GRAVITY = 1850.0
BALL_RADIUS = 30
BALL_MASS = 1.0
BALL_RESTITUTION = 0.68
BALL_PLAYER_RESTITUTION = 0.62
BALL_AIR_DRAG = 0.20
BALL_GROUND_FRICTION = 1.15
BALL_SPEED_CAP = 3400.0
BALL_TIME = 0.8             # the ball's whole motion runs at 80% speed - same arcs, a fifth slower
BALL_CARRY = 0.6            # how much of the body part's own movement the ball takes on
BALL_CURVE = 1.2            # sideways accel per deg/s of spin
BALL_CURVE_MAX = 500.0

GOALS_TO_WIN = 3
GOAL_HOLD = 2.6

# Palette
SKY_TOP = (92, 62, 132)     # sunset: purple overhead...
SKY_BOT = (255, 170, 104)   # ...to orange at the horizon
STAND_DARK = (26, 30, 44)
STAND_LIGHT = (38, 44, 62)
PITCH_A = (46, 128, 58)
PITCH_B = (40, 116, 52)
PITCH_EDGE = (28, 84, 40)
LINE_WHITE = (232, 240, 232)
NET = (196, 206, 214)
INK = (16, 16, 24)
WHITE = (246, 248, 252)
YELLOW = (255, 206, 64)

HOME_KIT = {
    "shirt": (58, 104, 220), "shirt_dark": (34, 64, 158),
    "shorts": (24, 34, 72), "skin": (238, 196, 160),
    "boot": (250, 226, 96), "hair": (58, 40, 34),
}
AWAY_KIT = {
    "shirt": (216, 62, 62), "shirt_dark": (150, 34, 34),
    "shorts": (54, 20, 20), "skin": (198, 148, 108),
    "boot": (240, 240, 248), "hair": (24, 20, 20),
}

SHAKE_CAP = 8.0             # subtle
ARROW_STRETCH = 330.0       # how much longer the aim arrow gets at full power
SOUNDS_ON = ("kick", "tap", "whistle", "shock", "cheer")   # everything else stays silent
PARTICLES_ON = False        # dust / sparks / confetti (off to match the original)
MENU_INPUT_DELAY = 0.8      # a new screen ignores clicks for this long, so you can't click through it
FX_CAP = 220 if WEB_BUILD else 700   # firework squares alive at once (each one is a draw call)
FX_SCALE = 0.5 if WEB_BUILD else 1.0 # and how many a burst spends
BALL_TRAIL_ON = False
PIXEL = 3                   # pixel-art scale: world is drawn at 1/PIXEL res
# The browser CAN draw straight into a small 640 x 360 canvas (nine times fewer pixels a
# frame), but some pygbag templates don't like a canvas smaller than the page, so it is off
# by default and switched on by opening the game frame with ?small=1. Mouse and touch
# positions are scaled back up by VIEW_SCALE when it is on.
WEB_VIEW = False
VIEW_SCALE = 1
TOUCH_OR_WEB = WEB_BUILD          # map finger events and scale window coordinates
MIXER_BUFFER = 2048               # small buffers crackle in the browser
ROT_STEP = 2.0              # rotated sprites are cached every 2 degrees


# ==========================================================
# SMALL HELPERS
# ==========================================================
def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def lerp(a, b, t):
    return a + (b - a) * t


def approach(current, target, rate, dt):
    return current + (target - current) * (1.0 - math.exp(-rate * dt))


def rot(v, a):
    """Rotate a vector by angle a. Positive a turns clockwise on screen."""
    c, s = math.cos(a), math.sin(a)
    return Vector2(v[0] * c - v[1] * s, v[0] * s + v[1] * c)


def perp(v):
    return Vector2(-v.y, v.x)


def closest_on_segment(p, a, b):
    ab = b - a
    l2 = ab.length_squared()
    if l2 < 1e-9:
        return Vector2(a)
    t = clamp((p - a).dot(ab) / l2, 0.0, 1.0)
    return a + ab * t


SPRITES_DIR = os.path.join(SCRIPT_DIR, "sprites")   # all the art lives here


def _search_dirs():
    dirs = [SPRITES_DIR] if os.path.isdir(SPRITES_DIR) else []
    for d in (SCRIPT_DIR, os.getcwd()):
        d = os.path.abspath(d)
        if d not in dirs:
            dirs.append(d)
        try:                                   # also one level of subfolders
            for sub in sorted(os.listdir(d)):
                full = os.path.join(d, sub)
                if os.path.isdir(full) and full not in dirs:
                    dirs.append(full)
        except Exception:
            pass
    return dirs


def find_file(names, exts):
    """Find a file next to the script (or in the current folder, or one
    subfolder down). Case-insensitive; spaces/dashes count as underscores;
    also matches names with a prefix (e.g. 1abd5885-ballkick1.mp3)."""
    norm = lambda t: t.lower().replace(" ", "_").replace("-", "_")
    listing = []
    for d in _search_dirs():
        try:
            listing.append((d, os.listdir(d)))
        except Exception:
            continue
    for exact in (True, False):              # an exact name anywhere beats a prefixed one
        for d, files in listing:
            for base in names:
                for ext in exts:
                    want = norm(base + ext)
                    for fn in files:
                        low = norm(fn)
                        if low == want if exact else low.endswith("_" + want):
                            return os.path.join(d, fn)
    return None


def load_raw(*base_names):
    """Load an image from the sprites folder (or next to the script)."""
    for base in base_names:
        path = find_file((base,), (".png", ".jpg", ".jpeg"))
        if path is None:
            continue
        try:
            return pygame.image.load(path).convert_alpha()
        except Exception:
            continue
    return None


def load_fit(size, *names):
    """Aspect-fit load (for the head and ball)."""
    img = load_raw(*names)
    if img is None:
        return None
    w, h = img.get_size()
    if w <= 0 or h <= 0:
        return None
    s = min(size[0] / w, size[1] / h)
    return pygame.transform.smoothscale(img, (max(1, int(w * s)), max(1, int(h * s))))


def load_exact(size, *names):
    """Scaled once to the piece's fixed size - pieces never stretch at runtime."""
    img = load_raw(*names)
    if img is None:
        return None
    return pygame.transform.smoothscale(img, (int(size[0]), int(size[1])))


MISSING_SPRITES = []

# what a file name needs to contain for each Argentina piece (any match works,
# capitals/spaces don't matter). Exact names like ARG_torso.png win first.
TEAM_ALIASES = {"ARG": ("arg", "argentin"), "BRA": ("bra", "brazil", "brasil")}
_TORSO = ("torso", "body", "shirt", "jersey", "chest", "kit")
_ARM, _LEG = ("arm",), ("leg", "short", "pant")
# name -> (keywords the file name must contain, team it belongs to, words it must NOT contain)
SPRITE_RULES = {
    "ARG_torso": (_TORSO, "ARG", ()),
    "ARG_arm": (_ARM, "ARG", ("black",)),
    "ARG_leg": (_LEG, "ARG", ("black",)),
    "giuliano": (("giuliano", "simeone"), None, ()),
    "lautaro": (("lautaro", "martinez"), None, ()),
    "messi": (("messi",), None, ()),
    "BRA_torso": (_TORSO, "BRA", ()),
    "BRA_arm": (_ARM, "BRA", ("black",)),
    "BRA_leg": (_LEG, "BRA", ("black",)),
    "blackarm": (("blackarm", "black_arm", "black arm", "black-arm"), None, ()),
    "blackleg": (("blackleg", "black_leg", "black leg", "black-leg"), None, ()),
    "igor": (("igor",), None, ()),
    "bruno": (("bruno",), None, ()),
    "vinicius": (("vinicius", "vinícius", "vini"), None, ()),
}


def find_sprite(name):
    """Exact name first (e.g. BRA_torso.png), then any PNG whose name contains
    a keyword for this piece. A kit piece prefers files naming its team and
    never takes one naming another team. Flags and ball.png are skipped."""
    path = find_file((name,), (".png",))
    if path is not None:
        return path
    keys, team, bad = SPRITE_RULES.get(name, ((), None, ()))
    skip = {t.lower() + ".png" for t in TEAMS} | {"ball.png"}
    best = None
    for d in _search_dirs():
        try:
            files = sorted(os.listdir(d))
        except Exception:
            continue
        for fn in files:
            low = fn.lower()
            if not low.endswith(".png") or low in skip:
                continue
            stem = low[:-4]
            if not any(k in stem for k in keys) or any(b in stem for b in bad):
                continue
            score = 1
            if team is not None:
                if any(a in stem for a in TEAM_ALIASES.get(team, ())):
                    score = 0
                elif any(a in stem for t, al in TEAM_ALIASES.items() if t != team for a in al):
                    continue                     # belongs to a different team
            if best is None or score < best[0]:
                best = (score, os.path.join(d, fn))
        if best is not None:
            return best[1]
    return None


def load_pixel(name, size, fit=False, quiet=False):
    """Load a pixel-art sprite from the script folder, trimmed to its visible
    part and scaled with hard pixels (no smoothing). fit=True keeps its shape
    inside `size`; otherwise it fills `size` exactly. None if missing."""
    path = find_sprite(name)
    if path is None and quiet:
        return None
    if path is None:
        print("[ragdoll_football] missing sprite: %s.png (looked in %s)" % (name, SPRITES_DIR))
        MISSING_SPRITES.append(name + ".png")
        return None
    try:
        img = pygame.image.load(path).convert_alpha()
        box = img.get_bounding_rect()
        if box.w > 0 and box.h > 0:
            img = img.subsurface(box).copy()
        w, h = size
        if fit:
            k = min(w / img.get_width(), h / img.get_height())
            w, h = img.get_width() * k, img.get_height() * k
        out = pygame.transform.scale(img, (max(1, int(w)), max(1, int(h))))
        print("[ragdoll_football] loaded sprite:", path)
        return out
    except Exception as exc:
        print("[ragdoll_football] could not load %s: %s" % (path, exc))
        MISSING_SPRITES.append(os.path.basename(path) + " (unreadable)")
        return None


def ordinal(n):
    return "%d%s" % (n, "TH" if 10 <= n % 100 <= 20 else {1: "ST", 2: "ND", 3: "RD"}.get(n % 10, "TH"))


def load_teams():
    """Load the 12 team flags (ARG.png, BRA.png, ...) from the script's folder.
    The team name is the file name without '.png'."""
    teams = []
    for code in TEAMS:
        path = find_file((code,), (".png",)) or \
            os.path.join(SCRIPT_DIR, "flags", code + ".png")    # old layout
        if not os.path.exists(path):
            continue
        try:
            img = pygame.image.load(path).convert_alpha()
        except Exception:
            continue
        teams.append({"name": code, "flag": img})
    return teams


_FLAG_CACHE = {}


def fit_flag(img, w, h):
    """Flag scaled to fit a w x h box (cached)."""
    key = (id(img), int(w), int(h))
    if key not in _FLAG_CACHE:
        iw, ih = img.get_size()
        k = min(w / max(1, iw), h / max(1, ih))
        _FLAG_CACHE[key] = pygame.transform.smoothscale(
            img, (max(1, int(iw * k)), max(1, int(ih * k))))
    return _FLAG_CACHE[key]


def capsule(surface, color, a, b, radius):
    d = b - a
    length = d.length()
    if length > 0.5:
        n = d / length
        p = Vector2(-n.y, n.x) * radius
        pts = [a + p, b + p, b - p, a - p]
        pygame.draw.polygon(surface, color, [(q.x, q.y) for q in pts])
    r = max(1, int(radius))
    pygame.draw.circle(surface, color, (int(a.x), int(a.y)), r)
    pygame.draw.circle(surface, color, (int(b.x), int(b.y)), r)


def rot_rect(center, w, h, angle):
    hw, hh = w * 0.5, h * 0.5
    return [center + rot((x, y), angle) for x, y in ((-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh))]


def poly(surface, color, pts):
    pygame.draw.polygon(surface, color, [(p.x, p.y) for p in pts])


class CachedFont:
    """A pygame font that keeps the surfaces it has already rendered. Re-rendering
    the same HUD and menu text 60 times a second is most of the browser's work."""

    def __init__(self, font, limit=1200):
        self._font = font
        self._cache = {}
        self._limit = limit

    def render(self, text, antialias=True, color=(255, 255, 255), *rest):
        if rest:                                   # background colour: rare, don't cache
            return self._font.render(text, antialias, color, *rest)
        key = (text, tuple(color)[:4], bool(antialias))
        img = self._cache.get(key)
        if img is None:
            if len(self._cache) >= self._limit:
                self._cache.clear()
            img = self._font.render(text, antialias, color)
            self._cache[key] = img
        return img

    def __getattr__(self, name):                   # size(), get_height(), metrics()...
        return getattr(self._font, name)


def _budget(cache, size, mpx):
    """Keep a surface cache under a pixel budget - memory matters more than hit rate here."""
    total = getattr(cache, "px", 0) + int(size[0]) * int(size[1])
    if total > mpx * 1000000:
        cache.clear()
        total = int(size[0]) * int(size[1])
    try:
        cache.px = total
    except AttributeError:
        pass


class _Cache(dict):
    px = 0


_TINT_CACHE = _Cache()


def tint(size, colour):
    """A reusable translucent rectangle (veils, HUD pads). Never drawn on, only blitted."""
    key = (int(size[0]), int(size[1]), tuple(colour))
    surf = _TINT_CACHE.get(key)
    if surf is None:
        _budget(_TINT_CACHE, size, 8)
        surf = pygame.Surface((int(size[0]), int(size[1])), pygame.SRCALPHA)
        surf.fill(colour)
        _TINT_CACHE[key] = surf
    return surf


# ---------------------------------------------------------------- frame budget
# Everything below exists for one reason: a browser frame can't afford to allocate
# megapixels of surface 60 times a second. Anything that used to be built per frame
# is either cached by shape, or drawn into a surface we keep and reuse.

_SCRATCH = _Cache()


def scratch(size, slot=0):
    """A transparent surface to draw one frame's effect into, kept and reused.

    Two effects alive at the same time need different slots."""
    size = (max(1, int(size[0])), max(1, int(size[1])))
    key = (size, slot)
    surf = _SCRATCH.get(key)
    if surf is None:
        _budget(_SCRATCH, size, 10)
        surf = pygame.Surface(size, pygame.SRCALPHA)
        _SCRATCH[key] = surf
    else:
        surf.fill((0, 0, 0, 0))
    return surf


def wash(target, colour, rect=None, slot=0):
    """A flat translucent wash over the target - no new surface, whatever the alpha."""
    r = rect if rect is not None else target.get_rect()
    surf = scratch((r.w, r.h), slot)
    surf.fill(colour)
    target.blit(surf, (r.x, r.y))


_GLOW_CACHE = _Cache()


def glow_blob(size, colour, alpha=60):
    """The soft ellipse behind cards and packs, cached by shape (sizes and alpha
    are rounded, so a pulsing aura reuses a handful of surfaces instead of one a frame)."""
    w = max(8, int(size[0]) // 16 * 16)
    h = max(8, int(size[1]) // 16 * 16)
    a = max(0, min(255, int(alpha) // 10 * 10))
    key = (w, h, tuple(colour)[:3], a)
    surf = _GLOW_CACHE.get(key)
    if surf is None:
        _budget(_GLOW_CACHE, (w, h), 4)
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, tuple(colour)[:3] + (a,), surf.get_rect())
        _GLOW_CACHE[key] = surf
    return surf


_SHINE_CACHE = _Cache()


def shine_sweep(size):
    """The diagonal gloss across a card face - same shape for every card of that size."""
    w, h = max(1, int(size[0])), max(1, int(size[1]))
    surf = _SHINE_CACHE.get((w, h))
    if surf is None:
        _budget(_SHINE_CACHE, (w, h), 3)
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.polygon(surf, (255, 255, 255, 34),
                            [(w * 0.55, 0), (w * 0.78, 0), (w * 0.25, h), (0, h)])
        _SHINE_CACHE[(w, h)] = surf
    return surf


_SCALE_BUF = {}


_SCALE_DEST_OK = None           # does this pygame take a destination surface? asked once


def scale_into(img, size, key):
    """pygame.transform.scale that writes into a surface we keep, instead of making one."""
    global _SCALE_DEST_OK
    size = (max(1, int(size[0])), max(1, int(size[1])))
    if _SCALE_DEST_OK is False:
        return pygame.transform.scale(img, size)
    dest = _SCALE_BUF.get(key)
    if dest is None or dest.get_size() != size:
        dest = pygame.Surface(size)
        _SCALE_BUF[key] = dest
    try:
        pygame.transform.scale(img, size, dest)
        _SCALE_DEST_OK = True
        return dest
    except Exception:                       # older pygame: no destination argument
        _SCALE_DEST_OK = False
        _SCALE_BUF.clear()
        return pygame.transform.scale(img, size)


_FIT_CACHE = _Cache()


def scaled(img, size):
    """pygame.transform.scale, cached per (image, size) - for art that is rescaled every frame."""
    size = (max(1, int(size[0])), max(1, int(size[1])))
    key = (id(img), size)
    out = _FIT_CACHE.get(key)
    if out is None:
        _budget(_FIT_CACHE, size, 6)
        out = pygame.transform.scale(img, size)
        _FIT_CACHE[key] = out
    return out


_ROT_CACHE = {}


def rotated(img, degrees):
    """pygame.transform.rotate, cached in 2-degree steps (the browser can't
    afford to re-rotate every sprite 60 times a second)."""
    try:
        step = round(degrees / ROT_STEP) * ROT_STEP % 360.0
        key = (id(img), step)
        out = _ROT_CACHE.get(key)
        if out is None:
            if len(_ROT_CACHE) > 4000:
                _ROT_CACHE.clear()
            out = pygame.transform.rotate(img, step)
            _ROT_CACHE[key] = out
        return out
    except Exception:
        return pygame.transform.rotate(img, degrees)


def blit_rot(surface, img, center, angle):
    r = rotated(img, -math.degrees(angle))
    surface.blit(r, r.get_rect(center=(int(center.x), int(center.y))))


# ==========================================================
# SOUND (synthesised at boot, no files needed)
# ==========================================================
class SFX:
    def __init__(self):
        self.enabled = False
        self.muted = False
        self.has_music = False
        self.bank = {}
        try:
            if pygame.mixer.get_init() is None:
                pygame.mixer.init(44100, -16, 2, MIXER_BUFFER)
            try:
                pygame.mixer.set_num_channels(8 if WEB_BUILD else 16)
            except Exception:
                pass
            self.bank["kick"] = self._tone(200, 0.10, vol=0.55, sweep=0.30, noise=0.45)
            self.bank["tap"] = self._tone(420, 0.06, vol=0.28, sweep=0.55, noise=0.30)
            kick = self._load("ballkick1", "ballkick", "kick")
            if kick is not None:
                self.bank["kick"] = kick
                self.bank["tap"] = kick
            self.bank["whistle"] = self._tone(1850, 0.30, vol=0.30, sweep=1.04, wave="square")
            self.bank["shock"] = self._load("shock") or self._tone(90, 0.35, vol=0.6, sweep=0.5, noise=0.6)
            self.bank["whoosh"] = self._tone(900, 0.22, vol=0.25, sweep=0.35, noise=0.85)
            self.bank["buff"] = self._tone(520, 0.4, vol=0.3, sweep=1.6, wave="square")
            cheer = self._load("cheering", "cheer")
            if cheer is not None:
                self.bank["cheer"] = cheer
            self.enabled = True
        except Exception:
            self.enabled = False

    @staticmethod
    def _load(*names):
        path = find_file(names, (".ogg", ".mp3", ".wav"))
        if path is None:
            return None
        try:
            return pygame.mixer.Sound(path)
        except Exception:
            return None

    # music slots: drop menumusic1.mp3 / playingmusic1.mp3 / creditsmusic1.mp3 next to the script
    TRACKS = {"menu": ("menu1", "menumusic1", "menumusic", "menu_music"),
              "match": ("playingmusic1", "playingmusic", "matchmusic1", "music"),
              "match2": ("playingmusic2",),
              "credits": ("creditsmusic1", "creditsmusic", "credits_music"),
              "impossible": ("impossiblemodeselect", "impossible"),
              "pack": ("openingpack", "packopening")}
    ONCE = ("pack",)                        # played once, not looped
    VOLUME = {"pack": 0.55, "impossible": 0.3}

    def track_path(self, slot):
        path = find_file(self.TRACKS[slot], (".ogg", ".mp3", ".wav"))
        if path is None and slot in ("menu", "credits", "match2", "impossible"):
            path = find_file(self.TRACKS["match"], (".ogg", ".mp3", ".wav"))
        return path

    def has_track(self, slot):
        return find_file(self.TRACKS[slot], (".ogg", ".mp3", ".wav")) is not None

    def play_track(self, slot, start=0.0, force=False):
        """Swap the background track. No-op if that file is already playing."""
        if not self.enabled or self.muted:
            self.want = slot
            return
        path = self.track_path(slot)
        if path is None or (path == getattr(self, "now_playing", None) and not force):
            return
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(self.VOLUME.get(slot, 0.20))
            loops = 0 if slot in self.ONCE else -1
            try:
                pygame.mixer.music.play(loops, start)
            except Exception:
                pygame.mixer.music.play(loops)
            self.now_playing = path
            self.want = slot
            self.has_music = True
        except Exception:
            pass

    def start_music(self):
        self.now_playing = None
        self.want = "menu"
        self.play_track("menu")

    def toggle_mute(self):
        self.muted = not self.muted
        if not self.muted:
            self.play_track(getattr(self, "want", "menu"))
        if self.has_music:
            try:
                if self.muted:
                    pygame.mixer.music.pause()
                else:
                    pygame.mixer.music.unpause()
            except Exception:
                pass

    @staticmethod
    def _tone(freq, dur, vol=0.35, sweep=1.0, noise=0.0, wave="sine"):
        rate = 44100
        n = max(2, int(rate * dur))
        buf = array.array("h")
        phase = 0.0
        for i in range(n):
            frac = i / n
            f = freq * (sweep ** frac)
            phase += 2.0 * math.pi * f / rate
            s = math.sin(phase)
            if wave == "square":
                s = 1.0 if s >= 0.0 else -1.0
            if noise > 0.0:
                s = s * (1.0 - noise) + random.uniform(-1.0, 1.0) * noise
            env = (1.0 - frac) ** 1.5
            val = int(clamp(s * env * vol, -1.0, 1.0) * 31000)
            buf.append(val)
            buf.append(val)
        return pygame.mixer.Sound(buffer=buf.tobytes())

    def play(self, name, volume=1.0):
        if not self.enabled or self.muted or name not in SOUNDS_ON:
            return
        snd = self.bank.get(name)
        if snd is None:
            return
        try:
            snd.set_volume(clamp(volume, 0.0, 1.0))
            snd.play()
        except Exception:
            pass


# ==========================================================
# PARTICLES
# ==========================================================
class Particles:
    def __init__(self):
        self.items = []

    def burst(self, pos, count, kind="dust", direction=None, spread=1.0, speed=300.0,
              color=(220, 220, 220)):
        if not PARTICLES_ON:
            return
        for _ in range(count):
            if direction is None:
                ang = random.uniform(0, math.tau)
                vel = Vector2(math.cos(ang), math.sin(ang)) * random.uniform(0.3, 1.0) * speed
            else:
                base = math.atan2(direction.y, direction.x)
                ang = base + random.uniform(-spread, spread)
                vel = Vector2(math.cos(ang), math.sin(ang)) * random.uniform(0.4, 1.0) * speed
            self.items.append({
                "pos": Vector2(pos), "vel": vel, "kind": kind,
                "life": random.uniform(0.28, 0.7), "age": 0.0,
                "size": random.uniform(3.0, 8.0), "color": color,
                "spin": random.uniform(-14.0, 14.0), "rot": random.uniform(0, math.tau),
            })
        cap = 240 if WEB_BUILD else 900
        if len(self.items) > cap:
            del self.items[:len(self.items) - cap]

    def update(self, dt):
        alive = []
        for p in self.items:
            p["age"] += dt
            if p["age"] >= p["life"]:
                continue
            if p["kind"] == "dust":
                p["vel"] *= (1.0 - 3.2 * dt)
                p["vel"].y -= 40.0 * dt
            elif p["kind"] == "spark":
                p["vel"].y += 1400.0 * dt
                p["vel"] *= (1.0 - 1.5 * dt)
            else:  # confetti
                p["vel"].y += 700.0 * dt
                p["vel"].x += math.sin(p["age"] * 7.0 + p["rot"]) * 240.0 * dt
                p["vel"] *= (1.0 - 0.8 * dt)
            p["pos"] += p["vel"] * dt
            p["rot"] += p["spin"] * dt
            alive.append(p)
        self.items = alive

    def draw(self, surface):
        for p in self.items:
            t = 1.0 - p["age"] / p["life"]
            if p["kind"] == "confetti":
                s = p["size"] * 1.6
                c = math.cos(p["rot"]) * s
                pts = [(p["pos"].x - s, p["pos"].y - c), (p["pos"].x + s, p["pos"].y - c * 0.4),
                       (p["pos"].x + s, p["pos"].y + c), (p["pos"].x - s, p["pos"].y + c * 0.4)]
                pygame.draw.polygon(surface, p["color"], pts)
            else:
                r = max(1, int(p["size"] * t))
                pygame.draw.circle(surface, p["color"], (int(p["pos"].x), int(p["pos"].y)), r)


# ==========================================================
# BALL
# ==========================================================
class Ball:
    def __init__(self):
        self.pos = Vector2(WIDTH * 0.5, 240)
        self.vel = Vector2()
        self.radius = BALL_RADIUS
        self.spin = 0.0
        self.angle = 0.0
        self.squash = 0.0
        self.squash_dir = Vector2(0, -1)
        self.frozen = True
        self.trail = []
        self.extra_g = 0.0         # Perfect Shot: extra pull so it dips sharply
        self.extra_g_t = 0.0
        self.ghost_t = 0.0
        self.home_ghost_t = 0.0         # while > 0 the CPU can't touch it (it's over his head)
        self.home_ghost_t = 0.0    # while > 0 the player's own body doesn't knock it (flicks)
        self.art = self._build_art()

    def _build_art(self):
        raw = load_raw("ball", "football")
        if raw is not None:                       # pixel art: scale hard, never smooth it
            d = self.radius * 2
            k = min(d / raw.get_width(), d / raw.get_height())
            return pygame.transform.scale(raw, (max(2, int(raw.get_width() * k)),
                                                max(2, int(raw.get_height() * k))))
        d = self.radius * 2
        surf = pygame.Surface((d, d), pygame.SRCALPHA)
        c = self.radius
        pygame.draw.circle(surf, INK, (c, c), self.radius)
        pygame.draw.circle(surf, WHITE, (c, c), self.radius - 4)
        pygame.draw.circle(surf, (40, 44, 60), (c, c), int(self.radius * 0.30))
        for i in range(5):
            a = math.tau * i / 5.0 - math.pi / 2.0
            px = c + math.cos(a) * self.radius * 0.66
            py = c + math.sin(a) * self.radius * 0.66
            pygame.draw.circle(surf, (40, 44, 60), (int(px), int(py)), int(self.radius * 0.17))
        return surf

    def reset(self, x, y, frozen=True):
        self.pos.update(x, y)
        self.vel.update(0, 0)
        self.spin = 0.0
        self.squash = 0.0
        self.frozen = frozen
        self.trail.clear()
        self.extra_g_t = 0.0
        self.ghost_t = 0.0

    def step(self, h, segments, sfx, particles):
        if self.frozen:
            return
        h *= BALL_TIME                       # everything about the ball happens 40% slower
        self.vel.y += BALL_GRAVITY * h
        if self.extra_g_t > 0.0:
            self.vel.y += self.extra_g * h
            self.extra_g_t -= h
        self.ghost_t = max(0.0, self.ghost_t - h)
        self.home_ghost_t = max(0.0, self.home_ghost_t - h)
        self.vel *= (1.0 - BALL_AIR_DRAG * h)
        if self.pos.y < GROUND_Y - self.radius - 2 and self.vel.length_squared() > 1.0 and self.extra_g_t <= 0.0:
            # slight curve from spin (Magnus effect)
            side = Vector2(-self.vel.y, self.vel.x).normalize()
            self.vel += side * clamp(self.spin * BALL_CURVE, -BALL_CURVE_MAX, BALL_CURVE_MAX) * h
        if self.vel.length() > BALL_SPEED_CAP:
            self.vel.scale_to_length(BALL_SPEED_CAP)
        self.pos += self.vel * h

        floor = GROUND_Y - self.radius
        if self.pos.y > floor:
            impact = abs(self.vel.y)
            self.pos.y = floor
            if impact > 60.0:
                self.vel.y = -impact * BALL_RESTITUTION
                self.impact(Vector2(0, -1), impact)
                if impact > 300.0:
                    sfx.play("bounce", clamp(impact / 1600.0, 0.15, 0.8))
                    particles.burst(Vector2(self.pos.x, GROUND_Y), 6, "dust",
                                    Vector2(0, -1), 1.1, impact * 0.35, (176, 200, 168))
            else:
                self.vel.y = 0.0
            self.vel.x -= self.vel.x * BALL_GROUND_FRICTION * h
            self.spin = approach(self.spin, math.degrees(self.vel.x / self.radius), 14.0, h)

        if self.pos.y < self.radius:
            self.pos.y = self.radius
            self.vel.y = abs(self.vel.y) * BALL_RESTITUTION
        if self.pos.x < self.radius:
            self.pos.x = self.radius
            self.vel.x = abs(self.vel.x) * BALL_RESTITUTION
        elif self.pos.x > WIDTH - self.radius:
            self.pos.x = WIDTH - self.radius
            self.vel.x = -abs(self.vel.x) * BALL_RESTITUTION

        for a, b, thick in segments:
            self._collide_segment(a, b, thick, sfx, particles)

        self.angle -= self.spin * h
        self.spin *= (1.0 - 0.5 * h)
        self.squash = max(0.0, self.squash - h * 4.5)

    def _collide_segment(self, a, b, thick, sfx, particles):
        cp = closest_on_segment(self.pos, a, b)
        d = self.pos - cp
        dist = d.length()
        min_dist = self.radius + thick * 0.5
        if dist >= min_dist:
            return
        n = d / dist if dist > 1e-6 else Vector2(0, -1)
        self.pos = cp + n * min_dist
        vn = self.vel.dot(n)
        if vn < 0:
            self.vel -= n * vn * (1.0 + BALL_RESTITUTION)
            self.spin += self.vel.dot(Vector2(-n.y, n.x)) * 0.02
            self.impact(n, abs(vn))
            if abs(vn) > 200.0:
                sfx.play("post", clamp(abs(vn) / 1400.0, 0.2, 0.9))
                particles.burst(cp, 8, "spark", n, 0.9, abs(vn) * 0.5, YELLOW)

    def impact(self, normal, strength):
        self.squash = min(1.0, self.squash + clamp(strength / 1600.0, 0.0, 0.85))
        self.squash_dir = Vector2(normal)

    def push_trail(self):
        if self.vel.length() > 420.0 and not self.frozen:
            self.trail.append(Vector2(self.pos))
            if len(self.trail) > 14:
                self.trail.pop(0)
        elif self.trail:
            self.trail.pop(0)

    def draw(self, surface):
        for i, p in enumerate(self.trail if BALL_TRAIL_ON else ()):
            t = (i + 1) / (len(self.trail) + 1)
            r = int(self.radius * t * 0.8)
            if r > 1:
                ghost = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
                pygame.draw.circle(ghost, (255, 255, 255, int(70 * t)), (r, r), r)
                surface.blit(ghost, (int(p.x - r), int(p.y - r)))

        img = self.art
        if self.squash > 0.01:
            sx = 1.0 + 0.30 * self.squash
            sy = 1.0 - 0.26 * self.squash
            ang = math.degrees(math.atan2(-self.squash_dir.y, self.squash_dir.x)) - 90.0
            try:
                img = pygame.transform.rotate(img, -ang)
                img = pygame.transform.smoothscale(
                    img, (max(2, int(img.get_width() * sx)), max(2, int(img.get_height() * sy))))
                img = pygame.transform.rotate(img, ang)
            except Exception:
                img = self.art
        try:
            r = rotated(img, self.angle % 360.0) if img is self.art else \
                pygame.transform.rotate(img, self.angle % 360.0)
        except Exception:
            r = img
        surface.blit(r, r.get_rect(center=(int(self.pos.x), int(self.pos.y))))


# ==========================================================
# PLAYER: a tumbling rigid body (torso + head) with gravity-hung limbs
# ==========================================================
class Spring:
    """Small damped spring - only used for the head's slight lag."""
    __slots__ = ("a", "av", "stiff", "damp", "limit")

    def __init__(self, stiff, damp, limit):
        self.a = 0.0
        self.av = 0.0
        self.stiff = stiff
        self.damp = damp
        self.limit = limit

    def step(self, target, h):
        self.av += (self.stiff * (target - self.a) - self.damp * self.av) * h
        self.a += self.av * h
        if abs(self.a) > self.limit:
            self.a = math.copysign(self.limit, self.a)
            self.av *= -0.25

    def reset(self):
        self.a = 0.0
        self.av = 0.0


def wrap(a):
    return (a + math.pi) % math.tau - math.pi


def cross(a, b):
    return a.x * b.y - a.y * b.x


def pendulum_acc(theta, force, length):
    """Angular acceleration of a hanging piece (theta 0 = pointing straight
    down, positive = tip swings left) under a force per unit mass."""
    return (-math.cos(theta) * force.x - math.sin(theta) * force.y) / length


class Limb:
    """One rigid arm or leg pinned to the torso.

    Its angle is a WORLD angle, so gravity always pulls it toward the floor
    no matter how the torso is turned: if the body falls over to the right,
    the upper (left) arm swings round to hang down, and the lower (right)
    arm ends up tucked under the torso, out of sight. It can't pass through
    the floor - it lies flat on it instead. Legs have a wide joint range,
    so they drop into the splits when the hips reach the ground.
    """

    def __init__(self, side, pivot, length, radius, limit, joint_damp):
        self.side = side                  # -1 = left piece, +1 = right piece
        self.local = Vector2(pivot)
        self.length = length
        self.radius = radius
        self.limit = limit                # max angle vs torso (None = free)
        self.joint_damp = joint_damp
        self.a = 0.0
        self.av = 0.0
        self.on_floor = False

    def reset(self, body_angle):
        self.a = body_angle - self.side * 0.08
        self.av = 0.0

    def pivot(self, body):
        return body.pos + rot(self.local, body.angle)

    def step(self, body, force, h, segments=()):
        acc = pendulum_acc(self.a, force, self.length * 0.6)
        acc -= self.joint_damp * (self.av - body.av) + LIMB_ABS_DAMP * self.av
        self.av += acc * h
        self.a = wrap(self.a + self.av * h)

        if self.limit is not None:
            rel = wrap(self.a - body.angle)
            if abs(rel) > self.limit:
                self.a = wrap(body.angle + math.copysign(self.limit, rel))
                self.av = body.av + (self.av - body.av) * -0.2

        # the floor: the limb lies on it instead of poking through
        self.on_floor = False
        piv = self.pivot(body)
        floor = GROUND_Y - self.radius
        if piv.y + self.length * math.cos(self.a) > floor:
            c = clamp((floor - piv.y) / self.length, -1.0, 1.0)
            base = math.acos(c)
            s = math.sin(self.a)
            prefer = math.copysign(1.0, s) if abs(s) > 0.02 else -self.side

            def cost(cand):
                over = 0.0
                if self.limit is not None:       # never fold past the joint
                    over = max(0.0, abs(wrap(cand - body.angle)) - self.limit)
                return (over, abs(wrap(cand - self.a)), 0 if cand * prefer > 0 else 1)

            self.a = min((base, -base), key=cost)
            self.av *= 0.35
            self.on_floor = True

        # the goal frame: rotate the limb out of the crossbar/roof
        for a, b, thick in segments:
            min_d = self.radius + thick * 0.5
            tip = piv + rot((0, self.length), self.a)
            if (tip - closest_on_segment(tip, a, b)).length() >= min_d:
                continue
            for _ in range(8):
                best = None
                for da in (0.07, -0.07):
                    t2 = piv + rot((0, self.length), self.a + da)
                    dd = (t2 - closest_on_segment(t2, a, b)).length()
                    if best is None or dd > best[0]:
                        best = (dd, da)
                self.a = wrap(self.a + best[1])
                if best[0] >= min_d:
                    break
            self.av *= 0.3


class Player:
    # collision circles in torso space: head, two top corners, rounded hips.
    # The rounded bottom means it can never balance - it always falls over.
    HEAD_LOCAL = Vector2(0, -(TORSO_H / 2 + NECK_GAP + HEAD_R))
    HIP_LOCAL = Vector2(0, TORSO_H / 2 - HIP_ROUND)
    SHAPE = (
        (HEAD_LOCAL, float(HEAD_R)),
        (Vector2(-(TORSO_W / 2 - 5), -TORSO_H / 2 + 5), 5.0),
        (Vector2(TORSO_W / 2 - 5, -TORSO_H / 2 + 5), 5.0),
        (HIP_LOCAL, float(HIP_ROUND)),
    )

    def __init__(self, x, facing, kit):
        self.facing = facing
        self.kit = kit
        self.pos = Vector2()
        self.vel = Vector2()
        self.last_vel = Vector2()
        self.angle = 0.0          # torso rotation, positive = clockwise
        self.av = 0.0

        self.head = Spring(150.0, 13.0, 0.30)
        arm_len = ARM_L - ARM_W / 2
        self.arm_l = Limb(-1, (-SHOULDER_X, SHOULDER_Y), arm_len, ARM_W / 2, None, ARM_JOINT_DAMP)
        self.arm_r = Limb(1, (SHOULDER_X, SHOULDER_Y), arm_len, ARM_W / 2, None, ARM_JOINT_DAMP)
        self.leg_l = Limb(-1, (-HIP_X, HIP_Y), LEG_L, BOOT_R, LEG_LIMIT, LEG_JOINT_DAMP)
        self.leg_r = Limb(1, (HIP_X, HIP_Y), LEG_L, BOOT_R, LEG_LIMIT, LEG_JOINT_DAMP)
        self.limbs = (self.leg_l, self.leg_r, self.arm_l, self.arm_r)

        self.throw_timer = 0.0
        self.grounded = True
        self._segments = ()
        self.rating = 100          # card overall: hit power
        self.sho = 100             # shooting: steady aim + steers ball hits
        self.str = 100             # strength: longer drag, more power, heavier bumps
        self.range_mult = self.power_mult = self.hit_mult = 1.0   # ability boosts
        self.control = self.aim_bonus = 0.0
        self.abilities = ()        # [(ability, tier)] from the card
        self.ab = {}               # ability effects rolled up: key -> size
        self.ctx = {}              # match context the abilities look at
        self.bump_t = 0.0          # a moment after being clattered (ESCAPE)
        self.ghost = False         # passes through the other player (dribble moves)
        self.default_sprites = {
            "head": load_fit((HEAD_R * 2, HEAD_R * 2), "head"),
            "torso": load_exact((TORSO_W, TORSO_H), "torso"),
            "arm": load_exact((ARM_W, ARM_L), "arm", "arms"),
            "leg": load_exact((LEG_W, LEG_L), "leg", "legs"),
        }
        self.sprites = self.default_sprites
        self.reset_to(x)

    def set_look(self, sprites=None):
        """Swap in a team kit / head (any missing piece uses the default)."""
        look = dict(self.default_sprites)
        for k, v in (sprites or {}).items():
            if v is not None:
                look[k] = v
        self.sprites = look

    def reset_to(self, x):
        # dropped in upright on its hips; it slumps over on its own
        self.pos.update(x, GROUND_Y - TORSO_H / 2 - 2)
        self.vel.update(0, 0)
        self.last_vel.update(0, 0)
        self.angle = random.uniform(-0.05, 0.05)
        self.av = 0.0
        self.head.reset()
        for limb in self.limbs:
            limb.reset(self.angle)
        self.throw_timer = 0.0
        self.grounded = True

    @property
    def on_ground(self):
        return self.grounded

    def set_stats(self, card):
        self.rating = card["rating"] if card else 100
        self.sho = card["sho"] if card else 100
        self.str = card["str"] if card else 100
        self.set_abilities(ability_list(card) if card and card.get("id") else ())

    def set_abilities(self, pairs):
        """pairs = [(ability, tier index)] - the effects are added up by tier."""
        self.abilities = tuple(pairs)
        self.ab = {}
        for ab, tier in self.abilities:
            k = ABILITY_TIERS[tier][2]
            for key, v in ab["fx"].items():
                self.ab[key] = self.ab.get(key, 0.0) + v * k

    def a(self, key):
        return self.ab.get(key, 0.0)

    def body_r(self):
        """WALL / INTERCEPTOR make the body a wider obstacle."""
        own = 1.0 if self.ctx.get("own_half") else 0.0
        return BODY_R * (1.0 + self.a("body") + self.a("body_own") * own)

    def power_bonus(self):
        c = self.ctx
        return (self.a("power") + self.a("press") * (1.0 if c.get("near_opp") else 0.0)
                + self.a("sweep") * (1.0 if c.get("own_third") else 0.0)
                + self.a("burst") * (1.0 if self.bump_t > 0.0 else 0.0)
                + self.a("clutch") * (1.0 if c.get("clutch") else 0.0))

    def strength01(self):
        return clamp((self.str - 70) / 80.0, 0.0, 1.0)

    def drag_range(self):
        """Stronger players can pull the arrow further..."""
        sweep = self.a("sweep") if self.ctx.get("own_third") else 0.0
        return THROW_DRAG_RANGE * (0.85 + 0.35 * self.strength01()) * self.range_mult * (1.0 + self.a("range") + sweep)

    def max_power(self):
        """...for a harder fling."""
        return THROW_MAX * (0.92 + 0.20 * self.strength01()) * self.power_mult * (1.0 + self.power_bonus())

    def aim_wobble(self, t):
        """Low shooting = shaky aim (radians); 130+ shooting is rock steady."""
        amp = clamp((130 - self.sho) / 90.0, 0.0, 1.0) * 0.16 * clamp(1.0 - self.aim_bonus * 4 - self.a("aim") * 2.2,
                                                                       0.0, 1.0)
        return amp * (0.7 * math.sin(t * 7.0) + 0.3 * math.sin(t * 13.3 + 1.7))

    # ---- rigid body helpers --------------------------------
    def to_world(self, local):
        return self.pos + rot(local, self.angle)

    def point_vel(self, p):
        return self.vel + perp(p - self.pos) * self.av

    def inv_eff(self, p, n):
        rn = cross(p - self.pos, n)
        return 1.0 / PLAYER_MASS + rn * rn / PLAYER_INERTIA

    def apply_impulse(self, p, j):
        self.vel += j / PLAYER_MASS
        self.av += cross(p - self.pos, j) / PLAYER_INERTIA

    # ---- control ------------------------------------------
    def can_throw(self):
        return self.throw_timer <= 0.0

    def throw(self, direction, power, sfx=None, particles=None):
        if direction.length_squared() < 1e-6 or not self.can_throw():
            return False
        n = direction.normalize()
        was_grounded = self.grounded
        self.vel = self.vel * THROW_KEEP + n * power
        if was_grounded and n.y > -0.25:
            self.vel.y = min(self.vel.y, -THROW_GROUND_HOP)
        # a flick of spin so the body tumbles: flung right, it tips back left
        self.av = self.av * 0.3 - n.x * power * THROW_SPIN
        self.grounded = False
        self.throw_timer = THROW_COOLDOWN * clamp(1.0 - self.a("quick"), 0.2, 1.0)
        if sfx:
            sfx.play("throw", clamp(power / THROW_MAX, 0.2, 0.6))
        if particles and was_grounded:
            particles.burst(Vector2(self.pos.x, GROUND_Y), 9, "dust",
                            -n, 0.8, power * 0.25, (186, 208, 178))
        return True

    # ---- simulation ---------------------------------------
    def _contacts(self, segments):
        """(contact point, normal, penetration) for every touching circle."""
        out = []
        for local, r in self.SHAPE:
            c = self.to_world(local)
            pen = c.y + r - GROUND_Y
            if pen > 0.0:
                out.append((c + Vector2(0, r), Vector2(0, -1), pen))
            pen = r - c.x
            if pen > 0.0:
                out.append((c - Vector2(r, 0), Vector2(1, 0), pen))
            pen = c.x + r - WIDTH
            if pen > 0.0:
                out.append((c + Vector2(r, 0), Vector2(-1, 0), pen))
            pen = r - c.y
            if pen > 0.0:
                out.append((c - Vector2(0, r), Vector2(0, 1), pen))
            for a, b, thick in segments:
                cp = closest_on_segment(c, a, b)
                d = c - cp
                dist = d.length()
                pen = r + thick * 0.5 - dist
                if pen > 0.0:
                    n = d / dist if dist > 1e-6 else Vector2(0, -1)
                    out.append((c - n * r, n, pen))
        return out

    def step(self, h, segments, sfx, particles):
        self._segments = segments
        self.throw_timer = max(0.0, self.throw_timer - h)
        self.bump_t = max(0.0, self.bump_t - h)
        was_grounded = self.grounded

        self.vel.y += PLAYER_GRAVITY * clamp(1.0 - self.a("float"), 0.5, 1.0) * h          # FEATHER
        self.vel *= (1.0 - PLAYER_AIR_DRAG * clamp(1.0 - self.a("glide"), 0.3, 1.0) * h)   # GLIDE
        if self.vel.length() > PLAYER_SPEED_CAP:
            self.vel.scale_to_length(PLAYER_SPEED_CAP)
        self.av = clamp(self.av * (1.0 - AIR_ANGULAR_DAMP * h), -22.0, 22.0)
        self.pos += self.vel * h
        self.angle = wrap(self.angle + self.av * h)

        contacts = self._contacts(segments)
        self.grounded = any(n.y < -0.5 for _, n, _ in contacts)
        impact = 0.0
        for it in range(4):
            for p, n, _ in contacts:
                vn = self.point_vel(p).dot(n)
                if vn >= 0.0:
                    continue
                impact = max(impact, -vn)
                e = GROUND_RESTITUTION * (1.0 + self.a("spring")) if (it == 0 and vn < -250.0) else 0.0
                jn = -(1.0 + e) * vn / self.inv_eff(p, n)
                self.apply_impulse(p, n * jn)
                t = perp(n)
                vt = self.point_vel(p).dot(t)
                jt = clamp(-vt / self.inv_eff(p, t), -GROUND_MU * jn, GROUND_MU * jn)
                self.apply_impulse(p, t * jt)

        for _ in range(3):                         # push out of the floor/walls
            for _, n, pen in self._contacts(segments):
                self.pos += n * (pen * 0.8)

        if self.grounded:
            self.vel.x *= math.exp(-GROUND_DRAG * h)
            upright = abs(self.angle) < 0.9
            if upright:
                # it can't stand: tip over toward whichever side it leans
                lean = self.angle if abs(self.angle) > 1e-3 else -self.facing * 1e-3
                self.av += math.copysign(TOPPLE_PUSH, lean) * h
            else:
                self.av *= math.exp(-GROUND_ANGULAR_DAMP * (1.0 + self.a("settle")) * h)
                if self.vel.length() < 14.0 and abs(self.av) < 0.25:
                    self.vel.update(0, 0)          # lying still stays still
                    self.av = 0.0
            if not was_grounded and impact > 350.0:
                self._on_land(impact, sfx, particles)

        self._animate(h)

    def _on_land(self, impact, sfx, particles):
        if impact > 800.0:
            if sfx:
                sfx.play("land", clamp(impact / 2600.0, 0.15, 0.6))
            if particles:
                particles.burst(Vector2(self.pos.x, GROUND_Y), int(clamp(impact / 240.0, 4, 14)),
                                "dust", Vector2(0, -1), 1.3, impact * 0.22, (192, 212, 184))

    def _animate(self, h):
        dv = self.vel - self.last_vel
        self.last_vel.update(self.vel)
        # acceleration from anything other than gravity (throws, floor, hits)
        push = dv / h - Vector2(0, PLAYER_GRAVITY)
        # limbs always feel gravity, plus a little lag from being shoved
        force = Vector2(0, PLAYER_GRAVITY) - push * LIMB_LAG
        if force.length() > LIMB_FORCE_CAP:
            force.scale_to_length(LIMB_FORCE_CAP)
        for limb in self.limbs:
            limb.step(self, force, h, self._segments)
        self.head.av -= clamp(dv.x, -2200.0, 2200.0) * 0.0018
        self.head.step(0.0, h)

    # ---- geometry -----------------------------------------
    def frame(self):
        f = {"ta": self.angle}
        f["neck"] = self.to_world((0, -TORSO_H / 2))
        f["head_a"] = self.angle + self.head.a
        f["head"] = f["neck"] + rot((0, -(NECK_GAP + HEAD_R)), f["head_a"])
        f["arms"] = []
        for limb in (self.arm_l, self.arm_r):
            piv = limb.pivot(self)
            f["arms"].append((piv, piv + rot((0, limb.length), limb.a), limb.a))
        f["legs"] = []
        for limb in (self.leg_l, self.leg_r):
            piv = limb.pivot(self)
            f["legs"].append((piv, piv + rot((0, limb.length), limb.a), limb.a))
        return f

    def body_segment(self):
        """The body collides with ball/opponent as one capsule (head to hips)."""
        return self.to_world(self.HEAD_LOCAL), self.to_world(self.HIP_LOCAL)

    def lowest_y(self):
        return max(self.to_world(l).y + r for l, r in self.SHAPE)

    # ---- rendering ----------------------------------------
    def draw(self, surface, debug=False):
        kit = self.kit
        s = self.sprites
        f = self.frame()
        ta = f["ta"]

        # legs and arms are all drawn behind the torso, so a limb tucked
        # under the body disappears behind it
        for piv, end, ang in f["legs"]:
            if s["leg"] is not None:
                blit_rot(surface, s["leg"], piv + rot((0, LEG_L / 2), ang), ang)
                continue
            knee = piv + rot((0, LEG_L * 0.45), ang)
            toe = end + rot((self.facing * 9, 1), ang)
            capsule(surface, kit["skin"], knee, end, LEG_W / 2 - 1)
            capsule(surface, kit["shorts"], piv, knee, LEG_W / 2)
            capsule(surface, kit["boot"], end, toe, BOOT_R)

        for piv, end, ang in f["arms"]:
            if s["arm"] is not None:
                blit_rot(surface, s["arm"], piv + rot((0, ARM_L / 2), ang), ang)
                continue
            elbow = piv + rot((0, ARM_L * 0.48), ang)
            capsule(surface, kit["skin"], elbow, end, ARM_W / 2 - 1)
            capsule(surface, kit["shirt_dark"], piv, elbow, ARM_W / 2)

        # torso: one rigid piece with a rounded bottom
        if s["torso"] is not None:
            blit_rot(surface, s["torso"], self.pos, ta)
        else:
            hip = self.to_world(self.HIP_LOCAL)
            upper_h = TORSO_H - HIP_ROUND
            upper_c = self.to_world((0, -TORSO_H / 2 + upper_h / 2))
            hr = TORSO_W / 2
            poly(surface, kit["shirt"], rot_rect(upper_c, TORSO_W, upper_h, ta))
            pygame.draw.circle(surface, kit["shorts"], (int(hip.x), int(hip.y)), int(hr))
            poly(surface, kit["shorts"], rot_rect(self.to_world((0, TORSO_H / 2 - HIP_ROUND - 4)),
                                                  TORSO_W, 8, ta))
            poly(surface, kit["shirt_dark"],
                 rot_rect(self.to_world((0, -TORSO_H / 2 + 4)), TORSO_W, 8, ta))

        # head
        hp, ha = f["head"], f["head_a"]
        if s["head"] is not None:
            blit_rot(surface, s["head"], hp, ha)
        else:
            pygame.draw.circle(surface, kit["skin"], (int(hp.x), int(hp.y)), HEAD_R)

        if debug:
            for local, r in self.SHAPE:
                c = self.to_world(local)
                pygame.draw.circle(surface, (255, 0, 160), (int(c.x), int(c.y)), int(r), 1)
            top, bot = self.body_segment()
            pygame.draw.line(surface, (255, 0, 160), top, bot, 1)


# ==========================================================
# CONTACTS
# ==========================================================
def closest_between_segments(p1, q1, p2, q2):
    """Closest points between segments p1-q1 and p2-q2."""
    d1, d2, r = q1 - p1, q2 - p2, p1 - p2
    a, e, f = d1.dot(d1), d2.dot(d2), d2.dot(r)
    if a < 1e-9 and e < 1e-9:
        return Vector2(p1), Vector2(p2)
    if a < 1e-9:
        s, t = 0.0, clamp(f / e, 0.0, 1.0)
    else:
        c = d1.dot(r)
        if e < 1e-9:
            s, t = clamp(-c / a, 0.0, 1.0), 0.0
        else:
            b = d1.dot(d2)
            denom = a * e - b * b
            s = clamp((b * f - c * e) / denom, 0.0, 1.0) if denom > 1e-9 else 0.0
            t = (b * s + f) / e
            if t < 0.0:
                t, s = 0.0, clamp(-c / a, 0.0, 1.0)
            elif t > 1.0:
                t, s = 1.0, clamp((b - c) / a, 0.0, 1.0)
    return p1 + d1 * s, p2 + d2 * t


def ability_hit(doll, ball, vn):
    """How much harder this particular hit is, from the doll's attacking abilities."""
    if not getattr(doll, "ab", None):
        return 1.0
    facing = getattr(doll, "facing", 1)
    goal_x = WIDTH - GOAL_DEPTH * 0.5 if facing > 0 else GOAL_DEPTH * 0.5
    dist = abs(ball.pos.x - goal_x)
    their_half = (ball.pos.x > WIDTH * 0.5) if facing > 0 else (ball.pos.x < WIDTH * 0.5)
    m = 1.0 + _ab(doll, "hit")
    m += _ab(doll, "hit_att") if their_half else _ab(doll, "hit_own")
    if dist < 560.0:
        m += _ab(doll, "hit_box")
    if dist > 1000.0:
        m += _ab(doll, "hit_far")
    if ball.pos.y < doll.pos.y - 30.0:
        m += _ab(doll, "hit_high")
    if abs(vn) > 700.0:
        m += _ab(doll, "hit_fast")
    if getattr(doll, "ctx", {}).get("clutch"):
        m += _ab(doll, "clutch")
    return m


def ball_vs_player(ball, doll, sfx, particles, on_hit):
    """Ball against the body capsule and the four limb tips (hands + feet).
    Only the deepest contact is resolved each step."""
    if ball.frozen:
        return False
    best = None
    top, bot = doll.body_segment()
    cp = closest_on_segment(ball.pos, top, bot)
    d = ball.pos - cp
    body_r = doll.body_r() if hasattr(doll, "body_r") else BODY_R
    pen = ball.radius + body_r - d.length()
    if pen > 0.0:
        best = (pen, cp, body_r, None)
    for limb in doll.limbs:
        piv = limb.pivot(doll)
        tip = piv + rot((0, limb.length), limb.a)
        r = limb.radius + 2.0
        pen = ball.radius + r - (ball.pos - tip).length()
        if pen > 0.0 and (best is None or pen > best[0]):
            best = (pen, tip, r, (limb, piv))
    if best is None:
        return False

    pen, centre, r, limb_hit = best
    d = ball.pos - centre
    dist = d.length()
    n = d / dist if dist > 1e-6 else Vector2(0, -1)
    ball.pos += n * pen
    contact = centre + n * r
    if limb_hit is None:
        pv = doll.point_vel(contact)
        inv = doll.inv_eff(contact, n)
    else:
        limb, piv = limb_hit
        # a swinging limb adds its own speed to the hit
        pv = doll.point_vel(piv) + perp(contact - piv) * clamp(limb.av, -20.0, 20.0)
        inv = doll.inv_eff(piv, n) + LIMB_HIT_SOFTNESS
    rel = ball.vel - pv
    vn = rel.dot(n)
    if vn >= 0.0:
        return True

    # momentum exchange: a fast player hits hard, a still one barely nudges it
    rest = BALL_PLAYER_RESTITUTION * (1.0 + _ab(doll, "rebound"))          # BLOCKER
    j = -(1.0 + rest) * vn / (1.0 / BALL_MASS + inv)
    # card overall: 70 hits at 85% power, 150 at 110%
    j *= 0.85 + clamp((getattr(doll, "rating", 100) - 70) / 80.0, 0.0, 1.0) * 0.25
    j *= getattr(doll, "hit_mult", 1.0) * ability_hit(doll, ball, vn)
    ball.vel += n * (j / BALL_MASS)
    # the ball goes where the body part is going: it takes on the sideways sweep of the
    # torso / arm / leg that touched it instead of only bouncing off along the normal
    vt_ball = ball.vel - n * ball.vel.dot(n)
    vt_body = pv - n * pv.dot(n)
    ball.vel += (vt_body - vt_ball) * BALL_CARRY
    control = getattr(doll, "control", 0.0) + _ab(doll, "control")         # FIRST TOUCH / SILKY
    if control > 0 and abs(vn) < 700.0:           # soft touches stay glued to his feet
        ball.vel = ball.vel * (1.0 - control * 0.5) + doll.vel * (control * 0.5)
    cushion = _ab(doll, "cushion") + (_ab(doll, "cushion_own") if getattr(doll, "ctx", {}).get("own_half") else 0.0)
    if cushion > 0.0 and abs(vn) < 950.0:         # GUARDIAN / SILKY: the ball dies on you
        ball.vel *= clamp(1.0 - cushion, 0.3, 1.0)
    # ...and better players steer the ball toward the goal they attack
    speed = ball.vel.length()
    if speed > 300.0:
        goal = Vector2(WIDTH - GOAL_DEPTH * 0.5 if doll.facing > 0 else GOAL_DEPTH * 0.5,
                       GROUND_Y - GOAL_HEIGHT * 0.5)
        want = goal - ball.pos
        if want.length_squared() > 1.0 and ball.vel.dot(want) > 0.0:
            accuracy = clamp((getattr(doll, "sho", 100) - 60) / 90.0, 0.0, 1.0) * 0.22 \
                + getattr(doll, "aim_bonus", 0.0) + _ab(doll, "aim")       # SNIPER
            cur = math.atan2(ball.vel.y, ball.vel.x)
            tgt = math.atan2(want.y, want.x)
            diff = (tgt - cur + math.pi) % math.tau - math.pi
            turn = clamp(diff, -accuracy, accuracy)
            ball.vel = Vector2(math.cos(cur + turn), math.sin(cur + turn)) * speed
    strength = abs(vn)
    if n.y > -0.35 and strength > 500.0:
        ball.vel.y -= strength * (0.12 + _ab(doll, "lift") * 0.45)   # LOB lifts it more
    ball.spin += rel.dot(perp(n)) * 0.035 * (1.0 + _ab(doll, "curve"))    # SPIN
    ball.impact(n, strength)
    if limb_hit is None:
        doll.apply_impulse(contact, -n * j)
    else:
        limb, piv = limb_hit
        doll.apply_impulse(piv, -n * j * 0.6)
        limb.av = clamp(limb.av - cross(contact - piv, n * j) * 0.004, -20.0, 20.0)

    if strength > 900.0:
        sfx.play("kick", clamp(strength / 2200.0, 0.45, 1.0))
        on_hit(strength)
    elif strength > 200.0:
        sfx.play("tap", clamp(strength / 1200.0, 0.15, 0.5))
    return True


def player_vs_player(a, b, sfx):
    if getattr(a, "ghost", False) or getattr(b, "ghost", False):
        return
    pa, pb = closest_between_segments(*a.body_segment(), *b.body_segment())
    d = pa - pb
    dist = d.length()
    ra = a.body_r() if hasattr(a, "body_r") else BODY_R
    rb = b.body_r() if hasattr(b, "body_r") else BODY_R
    pen = ra + rb - dist
    if pen <= 0.0:
        return
    n = d / dist if dist > 1e-6 else Vector2(1 if a.pos.x >= b.pos.x else -1, 0)
    a.pos += n * (pen * 0.5)
    b.pos -= n * (pen * 0.5)
    c = (pa + pb) * 0.5
    vn = (a.point_vel(c) - b.point_vel(c)).dot(n)
    if vn >= 0.0:
        return
    j = -(1.0 + 0.35) * vn / (a.inv_eff(c, n) + b.inv_eff(c, n))
    # the stronger player barely moves, the weaker one gets knocked further
    sa, sb = max(40.0, getattr(a, "str", 100)), max(40.0, getattr(b, "str", 100))
    # TANK throws people further, ANCHOR keeps you standing
    ka = (1.0 + _ab(b, "mass")) * clamp(1.0 - _ab(a, "anchor"), 0.4, 1.0)
    kb = (1.0 + _ab(a, "mass")) * clamp(1.0 - _ab(b, "anchor"), 0.4, 1.0)
    a.apply_impulse(c, n * j * (2.0 * sb / (sa + sb)) * ka)
    b.apply_impulse(c, -n * j * (2.0 * sa / (sa + sb)) * kb)
    if abs(vn) > 300.0:                           # ESCAPE: a burst of power after contact
        a.bump_t = b.bump_t = 0.9
    if abs(vn) > 500.0:
        sfx.play("bump", clamp(abs(vn) / 2000.0, 0.2, 0.7))


# ==========================================================
# CPU BRAIN - uses exactly the same throw the human gets
# ==========================================================
class Brain:
    """CPU player. Uses exactly the same throw the human gets."""

    def __init__(self, doll, attack_dir, skill=0.75, opponent=None):
        self.doll = doll
        self.attack_dir = attack_dir          # -1 = attacks the left goal
        self.skill = skill
        self.opponent = opponent
        self.bonus = 0.0                      # set by the game when the CPU is losing
        self.impossible = False               # no hesitation, twice as quick
        self.slow = 1.0                       # > 1: everything around Ren slows down
        self.think_timer = 0.0
        self.was_grounded = True

    def update(self, dt, ball):
        doll = self.doll
        # sometimes it lies there a moment after landing, "thinking"
        landed = doll.on_ground and not self.was_grounded
        self.was_grounded = doll.on_ground
        if landed and not self.impossible and random.random() < CPU_THINK_CHANCE:
            self.think_timer = max(self.think_timer, random.uniform(0.4, 0.9))

        self.think_timer -= dt
        if self.think_timer > 0.0 or not doll.can_throw():
            return
        self.think_timer = CPU_REACTION * random.uniform(0.8, 1.25)   # human-like
        if self.impossible:
            self.think_timer *= 0.45
        self.think_timer *= self.slow
        skill = min(1.0 if self.impossible else 0.98, self.skill + self.bonus)

        horizon = clamp(doll.pos.distance_to(ball.pos) / 1500.0, 0.10, 0.45)
        bt = horizon * BALL_TIME                       # the ball moves in its own, slower time
        pred = Vector2(ball.pos.x + ball.vel.x * bt,
                       ball.pos.y + ball.vel.y * bt + 0.5 * BALL_GRAVITY * bt ** 2)
        pred.y = min(pred.y, GROUND_Y - BALL_RADIUS)
        pred.x = clamp(pred.x, 60, WIDTH - 60)

        goal = Vector2(GOAL_DEPTH * 0.5 if self.attack_dir < 0 else WIDTH - GOAL_DEPTH * 0.5,
                       GROUND_Y - GOAL_HEIGHT * 0.45)
        to_goal = goal - pred
        to_goal = to_goal.normalize() if to_goal.length_squared() > 1.0 else Vector2(self.attack_dir, 0)
        strike = pred - to_goal * (BALL_RADIUS + 40)   # line up behind the ball

        here = doll.pos
        dist = here.distance_to(pred)
        own_goal_x = WIDTH - GOAL_DEPTH if self.attack_dir < 0 else GOAL_DEPTH
        threat = abs(ball.pos.x - own_goal_x) < 480
        err = lerp(150.0, 36.0, skill)
        noise = Vector2(random.uniform(-err, err), random.uniform(-err * 0.6, err * 0.4))

        if not doll.on_ground:
            if dist < 260.0 and random.random() < skill * 0.7:
                self._go(pred + noise * 0.5, 0.95, skill)
            return

        # sometimes body-check the human if they're closer to the ball
        opp = self.opponent
        if (opp is not None and random.random() < CPU_TACKLE_CHANCE
                and opp.pos.distance_to(ball.pos) < dist and here.distance_to(opp.pos) < 450.0):
            self._go(opp.pos + opp.vel * 0.15 + Vector2(0, -60), 0.85, skill)
            return

        if dist < 620.0 or threat:
            # on the wrong side of the ball: a normal hit would send it toward
            # our own goal, so pop it up into the air instead (or hop over it)
            wrong_side = (here.x - ball.pos.x) * self.attack_dir > 0.0
            if wrong_side:
                if pred.y < GROUND_Y - BALL_RADIUS - 60.0:
                    self._go(pred + Vector2(0, BALL_RADIUS + 12) + noise * 0.3, 0.9, skill)
                else:
                    over = Vector2(ball.pos.x - self.attack_dir * 150.0, here.y - 300.0)
                    self._go(over + noise * 0.3, 0.8, skill)
                return
            arc = min(240.0, dist * 0.4)
            self._go(strike + noise + Vector2(0, -arc), clamp(dist / 620.0, 0.45, 1.0), skill)
            return

        guard = clamp(pred.x - self.attack_dir * 340, 220, WIDTH - 220)
        dx = guard - here.x
        if abs(dx) > 120.0:
            self._go(Vector2(here.x + math.copysign(min(abs(dx), 380.0), dx), here.y - 180), 0.5, skill)

    def _go(self, target, power_scale, skill):
        d = target - self.doll.pos
        if d.length_squared() < 4.0:
            return
        power = lerp(THROW_MIN, self.doll.max_power(), clamp(power_scale, 0.0, 1.0)) * lerp(0.8, 1.0, skill)
        if self.impossible:
            power *= 1.08
        self.doll.throw(d, power)


# ==========================================================
# GAME
# ==========================================================
KICKOFF, PLAY, GOAL, FULLTIME, SELECT, TITLE, CLUB, TABLE, PACKS, PACK_OPEN, MYCLUB, LINEUP, PACK_VIEW, VERSUS, EVENT, \
    STORE, STARS, EXCHANGE, FREE_SELECT, PACK_MULTI, ROOKIE_PICK = range(21)
MENU_STATES = (SELECT, TITLE, CLUB, TABLE, PACKS, PACK_OPEN, MYCLUB, LINEUP, PACK_VIEW, EVENT,
               STORE, STARS, EXCHANGE, FREE_SELECT, PACK_MULTI, ROOKIE_PICK)
# the 12 teams, in select-screen order. Each one is <CODE>.png sitting in the
# same folder as this script (ARG.png, BRA.png, ...).
TEAMS = ["ARG", "BRA", "CRO", "ENG", "FRA", "MOR",
         "JPN", "POL", "NET", "AUS", "SPA", "POR"]
ROULETTE_START = 0.05       # seconds between hops when the draw starts...
ROULETTE_SLOWDOWN = 1.13    # ...each hop is this much slower...
ROULETTE_STOP = 0.38        # ...and it lands once hops are this slow
ROULETTE_BLINK = 0.8        # drawn flag blinks this long, then waits for a click
ROUNDS = ("DAY1", "DAY2", "DAY3", "R 16", "QRTR", "SEMI", "FINL")
SELECT_BG = (30, 58, 32)
SELECT_GREEN = (46, 140, 58)
DIFFICULTY = (("EASY", 0.40), ("MEDIUM", 0.72), ("HARD", 0.95), ("IMPOSSIBLE", 1.0))
IMPOSSIBLE = 3                 # World Cup only, unlocked at level 5
IMPOSSIBLE_LEVEL = 5
IMPOSSIBLE_BOOST = 20          # opponents get +20 rating / shooting / strength
IMPOSSIBLE_COINS = 3           # every Impossible match pays 3x coins

# ---- levels / XP
XP_REWARD = {"win": 100, "draw": 50, "loss": 20}
XP_PER_GOAL = 10
XP_TROPHY = 300                # World Cup won or league champions
def xp_to_next(level):
    """XP needed to go from `level` to `level + 1` (300, 400, 500, ...)."""
    return 200 + 100 * level

def level_from_xp(total):
    level, need = 1, xp_to_next(1)
    while total >= need:
        total -= need
        level += 1
        need = xp_to_next(level)
    return level, total, need       # level, xp into this level, xp for the next

# ---- pre-match intro (round title, TEAM1 / VS / TEAM2)
VS_TITLE_END = 1.3             # the grey title card
VS_SLAMS = (2.0, 2.9, 3.8)     # TEAM1, VS, TEAM2 - a shock sound on each
VS_FADE = 5.4                  # fade into the match
VS_LENGTH = 6.2
PVP_VS_LENGTH = 3.0            # online: the rival is sitting there waiting, keep it short
FORFEIT_SCORE = (0, 3)

# ---- pack opening, timed to openingpack.mp3
PACK_BEATS = (2.0, 3.5, 5.0)   # flag, position, club
PACK_CARD_AT = 7.0             # the player lands
# ---- PRACTICE: robot CPUs you can spawn
ROBOT_MAX = 4
ROBOT_MODES = ("EASY", "MEDIUM", "HARD", "DUMMY")
ROBOT_STATS = {"EASY": (85, 0.40), "MEDIUM": (105, 0.72), "HARD": (125, 0.95), "DUMMY": (100, 0.0)}   # OVR, CPU skill
ROBOT_LIGHT = {"EASY": (90, 230, 120), "MEDIUM": (255, 210, 60), "HARD": (250, 70, 70), "DUMMY": (130, 134, 146)}
PRACTICE_RESET = 1.3           # seconds after a practice goal before the ball comes back
# ---- FREEPLAY: any player you own vs any player you own
FREE_REWARD = (5, 50)          # random coins after every freeplay match (no XP, no stamina)
FREE_PER_PAGE = 21
# ---- open 10 packs at once
MULTI_PACKS = 10
# ---- first-launch tutorial
TUTORIAL_ON_FIRST_RUN = True
TUTORIAL_COINS = 900           # given once, spent on 3 packs
TUTORIAL_PACKS = 3
TUTORIAL_STEPS = ("welcome", "drag", "air", "ball", "goal", "match", "menu", "packs", "pick", "done")
# ---- Neymar Jr signature Game Box: first draw free, then 12 dearer draws up to 12,000
NEYMAR_CARD = "SIG_BRA_neymar"
NEYMAR_PRICES = (0, 60, 100, 160, 250, 400, 650, 1000, 1700, 2800, 4500, 7500, 12000)
# 8 weak fillers (bad -> alright -> good), 4 jackpots, and Neymar. Each reward drops once.
NEYMAR_REWARDS = (("coins", 50), ("training", 50), ("coins", 100), ("player", 0),
                  ("puzzle", 5), ("coins", 200), ("player", 1), ("player", 2),
                  ("jackpot_coins", 8000), ("jackpot_player", 3), ("jackpot_coins", 12000), ("jackpot_player", 4),
                  ("neymar", 0))                  # 12 tiles + the signature card = 13 draws
NEYMAR_ODDS = 0.0005           # 0.05% a draw - in practice he only comes from pity (the last draw)
JACKPOT_ODDS = 0.01            # 1% each while fillers are left
BOX_VERSION = 2
CLUB_COUNTRY = {"BAR": "SPA", "INT": "USA", "ALN": "KSA"}   # everyone else plays in England
# Players per team: (bad = EASY, alright = MEDIUM, good = HARD).
# Their sprites live in the "sprites" folder next to the script, named
# <TEAM>_<player>_<head|torso|arm|leg>.png  (e.g. sprites/ARG_messi_head.png).
TEAM_PLAYERS = {
    "ARG": ("simeone", "lautaro", "messi"),
    "BRA": ("igor", "bruno", "vinicius"),
    "CRO": ("majer", "kovacic", "modric"),
    "ENG": ("henderson", "foden", "bellingham"),
    "FRA": ("thuram", "dembele", "mbappe"),
    "MOR": ("elkhannouss", "amrabat", "hakimi"),
    "JPN": ("ueda", "kubo", "minamino"),
    "POL": ("kaminski", "zielinski", "lewandowski"),
    "NET": ("weghorst", "gakpo", "vandijk"),
    "AUS": ("yengi", "irvine", "ryan"),
    "SPA": ("baena", "olmo", "yamal"),
    "POR": ("palhinha", "bernardo", "ronaldo"),
}
# sprite files use the FIFA-style codes for these two
SPRITE_CODE = {"NET": "NED", "SPA": "ESP"}
# Team kits: each piece is one file name, or three (easy, medium, hard).
TEAM_LOOKS = {
    team: {piece: tuple("%s_%s_%s" % (SPRITE_CODE.get(team, team), p, piece) for p in players)
           for piece in ("head", "torso", "arm", "leg")}
    for team, players in TEAM_PLAYERS.items()
}
PIECE_SIZE = {"torso": ((TORSO_W, TORSO_H), False), "arm": ((ARM_W, ARM_L), False),
              "leg": ((LEG_W, LEG_L), False), "head": ((HEAD_R * 2, HEAD_R * 2), True)}
# ---- Club Football -------------------------------------
# (code, name, real-life strength 0-100, 5 players: Bad, Bad, Alright, Alright, Good)
# Strength follows the recent real Premier League table; it decides simulated
# results and makes the CPU a little sharper against big clubs.
CLUBS = [
    ("ARS", "Arsenal", 91, ("kepa", "trossard", "odegaard", "saka", "gyokeres")),
    ("AST", "Aston Villa", 79, ("cash", "digne", "rogers", "watkins", "martinez")),
    ("BOU", "Bournemouth", 75, ("christie", "kerkez", "semenyo", "evanilson", "kluivert")),
    ("BRE", "Brentford", 74, ("janelt", "potter", "schade", "mbeumo", "wissa")),
    ("BRI", "Brighton", 76, ("lamptey", "igor", "rutter", "mitoma", "joaopedro")),
    ("CHE", "Chelsea", 85, ("disasi", "cucurella", "enzo", "palmer", "caicedo")),
    ("CRY", "Crystal Palace", 74, ("ward", "lerma", "mateta", "eze", "guehi")),
    ("EVE", "Everton", 71, ("young", "tarkowski", "pickford", "ndiaye", "beto")),
    ("FUL", "Fulham", 73, ("reed", "robinson", "iwobi", "pereira", "jimenez")),
    ("LIV", "Liverpool", 90, ("gomez", "tsimikas", "macallister", "szoboszlai", "salah")),
    ("MCI", "Man City", 88, ("ake", "akanji", "foden", "rodri", "haaland")),
    ("MUN", "Man United", 72, ("lindelof", "malacia", "garnacho", "bruno", "mainoo")),
    ("NEW", "Newcastle", 81, ("burn", "targett", "gordon", "brunog", "isak")),
    ("NOT", "Nottingham Forest", 77, ("yates", "toffolo", "elanga", "gibbswhite", "hudsonodoi")),
    ("TOT", "Tottenham", 71, ("davies", "dragusin", "maddison", "romero", "son")),
    ("WES", "West Ham", 69, ("coufal", "cresswell", "bowen", "paqueta", "kudus")),
    ("WOL", "Wolves", 65, ("doherty", "lemina", "cunha", "aitnouri", "sarabia")),
    ("SUN", "Sunderland", 64, ("onien", "ballard", "clarke", "lefee", "bellingham")),
    ("INT", "Inter Miami", 70, ("aviles", "redondo", "suarez", "depaul", "messi")),
    ("ALN", "Al Nassr", 72, ("alghannam", "alkhaibari", "mane", "joaofelix", "ronaldo")),
    ("BAR", "Barcelona", 88, ("ferran", "fermin", "pedri", "raphinha", "yamal")),
]
# (id, name, kind, team code, slot, tier, rating, position, number, pack 0=World Cup 1-3=club,
#  shooting, strength, design: club/wc/icon, description)
CARD_DB = [
    ('WC_ARG_simeone', 'Giuliano Simeone', 'wc', 'ARG', 0, 'bad', 73, 'RW', 17, 0, 83, 71, 'wc', 'Tricky right winger who loves cutting inside.'),
    ('WC_ARG_lautaro', 'Lautaro Martinez', 'wc', 'ARG', 1, 'alright', 94, 'ST', 22, 0, 101, 97, 'wc', 'Striker who lives in the box and hunts every rebound.'),
    ('WC_ARG_messi', 'Messi', 'wc', 'ARG', 2, 'good', 143, 'RW', 10, 0, 141, 124, 'icon', 'The GOAT. Glides past everyone and never misses the target.'),
    ('WC_BRA_igor', 'Igor Thiago', 'wc', 'BRA', 0, 'bad', 79, 'ST', 25, 0, 86, 84, 'wc', 'Striker who lives in the box and hunts every rebound.'),
    ('WC_BRA_bruno', 'Bruno Guimaraes', 'wc', 'BRA', 1, 'alright', 97, 'CM', 8, 0, 93, 96, 'wc', 'Engine-room midfielder who covers every blade of grass.'),
    ('WC_BRA_vinicius', 'Vinicius Jr', 'wc', 'BRA', 2, 'good', 127, 'LW', 7, 0, 134, 122, 'wc', 'Electric dribbler who loves a big stage.'),
    ('WC_CRO_majer', 'Lovro Majer', 'wc', 'CRO', 0, 'bad', 75, 'CAM', 7, 0, 80, 71, 'wc', 'Creative playmaker with an eye for a killer pass.'),
    ('WC_CRO_kovacic', 'Mateo Kovacic', 'wc', 'CRO', 1, 'alright', 94, 'CM', 8, 0, 96, 91, 'wc', 'Engine-room midfielder who covers every blade of grass.'),
    ('WC_CRO_modric', 'Modric', 'wc', 'CRO', 2, 'good', 141, 'CM', 10, 0, 139, 134, 'icon', 'Maestro in midfield. Tiny but untouchable.'),
    ('WC_ENG_henderson', 'Jordan Henderson', 'wc', 'ENG', 0, 'bad', 70, 'CM', 14, 0, 67, 72, 'wc', 'Engine-room midfielder who covers every blade of grass.'),
    ('WC_ENG_foden', 'Phil Foden', 'wc', 'ENG', 1, 'alright', 93, 'CAM', 11, 0, 97, 84, 'wc', 'Creative playmaker with an eye for a killer pass.'),
    ('WC_ENG_bellingham', 'Bellingham', 'wc', 'ENG', 2, 'good', 127, 'CAM', 10, 0, 129, 122, 'wc', 'Box-to-box star who always turns up for the big goal.'),
    ('WC_FRA_thuram', 'Marcus Thuram', 'wc', 'FRA', 0, 'bad', 82, 'ST', 9, 0, 89, 81, 'wc', 'Striker who lives in the box and hunts every rebound.'),
    ('WC_FRA_dembele', 'Ousmane Dembele', 'wc', 'FRA', 1, 'alright', 104, 'RW', 7, 0, 109, 100, 'wc', 'Tricky right winger who loves cutting inside.'),
    ('WC_FRA_mbappe', 'Mbappe', 'wc', 'FRA', 2, 'good', 147, 'ST', 10, 0, 150, 147, 'icon', 'Pure pace and a finish like a cannon.'),
    ('WC_MOR_elkhannouss', 'Bilal El Khannouss', 'wc', 'MOR', 0, 'bad', 72, 'CAM', 23, 0, 73, 62, 'wc', 'Creative playmaker with an eye for a killer pass.'),
    ('WC_MOR_amrabat', 'Sofyan Amrabat', 'wc', 'MOR', 1, 'alright', 98, 'CDM', 4, 0, 89, 107, 'wc', 'Holding midfielder who breaks up play.'),
    ('WC_MOR_hakimi', 'Hakimi', 'wc', 'MOR', 2, 'good', 124, 'RB', 2, 0, 110, 125, 'wc', 'Rocket full-back who bombs forward all game.'),
    ('WC_JPN_ueda', 'Ayase Ueda', 'wc', 'JPN', 0, 'bad', 88, 'ST', 18, 0, 96, 90, 'wc', 'Striker who lives in the box and hunts every rebound.'),
    ('WC_JPN_kubo', 'Takefusa Kubo', 'wc', 'JPN', 1, 'alright', 97, 'RW', 8, 0, 103, 87, 'wc', 'Tricky right winger who loves cutting inside.'),
    ('WC_JPN_minamino', 'Minamino', 'wc', 'JPN', 2, 'good', 119, 'LW', 10, 0, 126, 109, 'wc', 'Speedy left winger who takes defenders on.'),
    ('WC_POL_kaminski', 'Jakub Kaminski', 'wc', 'POL', 0, 'bad', 76, 'LW', 13, 0, 80, 73, 'wc', 'Speedy left winger who takes defenders on.'),
    ('WC_POL_zielinski', 'Piotr Zielinski', 'wc', 'POL', 1, 'alright', 95, 'CM', 20, 0, 89, 97, 'wc', 'Engine-room midfielder who covers every blade of grass.'),
    ('WC_POL_lewandowski', 'Lewandowski', 'wc', 'POL', 2, 'good', 142, 'ST', 9, 0, 150, 150, 'icon', 'Clinical number nine. Every touch in the box is a goal.'),
    ('WC_NET_weghorst', 'Wout Weghorst', 'wc', 'NET', 0, 'bad', 84, 'ST', 9, 0, 94, 94, 'wc', 'Striker who lives in the box and hunts every rebound.'),
    ('WC_NET_gakpo', 'Cody Gakpo', 'wc', 'NET', 1, 'alright', 106, 'LW', 11, 0, 111, 99, 'wc', 'Speedy left winger who takes defenders on.'),
    ('WC_NET_vandijk', 'Van Dijk', 'wc', 'NET', 2, 'good', 142, 'CB', 4, 0, 121, 150, 'icon', 'A wall at the back. Wins every header, bullies strikers.'),
    ('WC_AUS_yengi', 'Kusini Yengi', 'wc', 'AUS', 0, 'bad', 75, 'ST', 26, 0, 89, 73, 'wc', 'Striker who lives in the box and hunts every rebound.'),
    ('WC_AUS_irvine', 'Jackson Irvine', 'wc', 'AUS', 1, 'alright', 95, 'CM', 22, 0, 95, 93, 'wc', 'Engine-room midfielder who covers every blade of grass.'),
    ('WC_AUS_ryan', 'Mathew Ryan', 'wc', 'AUS', 2, 'good', 114, 'GK', 1, 0, 76, 123, 'wc', 'Shot-stopper with safe hands.'),
    ('WC_SPA_baena', 'Alex Baena', 'wc', 'SPA', 0, 'bad', 89, 'LW', 15, 0, 98, 85, 'wc', 'Speedy left winger who takes defenders on.'),
    ('WC_SPA_olmo', 'Dani Olmo', 'wc', 'SPA', 1, 'alright', 102, 'CAM', 10, 0, 104, 95, 'wc', 'Creative playmaker with an eye for a killer pass.'),
    ('WC_SPA_yamal', 'Lamine Yamal', 'wc', 'SPA', 2, 'good', 139, 'RW', 19, 0, 140, 116, 'icon', 'Wonderkid winger - curls it into the corner from anywhere.'),
    ('WC_POR_palhinha', 'Palhinha', 'wc', 'POR', 0, 'bad', 77, 'CDM', 6, 0, 67, 86, 'wc', 'Holding midfielder who breaks up play.'),
    ('WC_POR_bernardo', 'Bernardo Silva', 'wc', 'POR', 1, 'alright', 106, 'RW', 10, 0, 109, 100, 'wc', 'Tricky right winger who loves cutting inside.'),
    ('WC_POR_ronaldo', 'Cristiano Ronaldo', 'wc', 'POR', 2, 'good', 141, 'ST', 7, 0, 138, 143, 'icon', 'Built like a tank, jumps higher than anyone and smashes it.'),
    ('ARS_kepa', 'Kepa', 'club', 'ARS', 0, 'bad', 72, 'GK', 13, 1, 41, 77, 'club', 'Shot-stopper with safe hands.'),
    ('ARS_trossard', 'Trossard', 'club', 'ARS', 1, 'bad', 85, 'LW', 19, 1, 93, 78, 'club', 'Speedy left winger who takes defenders on.'),
    ('ARS_odegaard', 'Odegaard', 'club', 'ARS', 2, 'alright', 108, 'CAM', 8, 1, 114, 106, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('ARS_saka', 'Saka', 'club', 'ARS', 3, 'alright', 125, 'RW', 7, 1, 135, 119, 'club', 'Star boy on the right wing, cuts in and shoots.'),
    ('ARS_gyokeres', 'Gyokeres', 'club', 'ARS', 4, 'good', 122, 'ST', 14, 1, 136, 136, 'club', 'Powerhouse striker who drags defenders around.'),
    ('AST_cash', 'Cash', 'club', 'AST', 0, 'bad', 76, 'RB', 2, 1, 62, 75, 'club', 'Hard-working right-back who loves a tackle.'),
    ('AST_digne', 'Digne', 'club', 'AST', 1, 'bad', 77, 'LB', 12, 1, 63, 78, 'club', 'Overlapping left-back who never stops running.'),
    ('AST_rogers', 'Rogers', 'club', 'AST', 2, 'alright', 98, 'CAM', 27, 1, 98, 91, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('AST_watkins', 'Watkins', 'club', 'AST', 3, 'alright', 92, 'ST', 11, 1, 100, 97, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('AST_martinez', 'Martinez', 'club', 'AST', 4, 'good', 122, 'GK', 23, 1, 90, 133, 'club', 'Big personality keeper who lives for penalties.'),
    ('BOU_christie', 'Christie', 'club', 'BOU', 0, 'bad', 80, 'CM', 10, 1, 80, 79, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('BOU_kerkez', 'Kerkez', 'club', 'BOU', 1, 'bad', 74, 'LB', 3, 1, 65, 74, 'club', 'Overlapping left-back who never stops running.'),
    ('BOU_semenyo', 'Semenyo', 'club', 'BOU', 2, 'alright', 109, 'RW', 24, 1, 113, 102, 'club', 'Tricky right winger who loves cutting inside.'),
    ('BOU_evanilson', 'Evanilson', 'club', 'BOU', 3, 'alright', 106, 'ST', 9, 1, 114, 105, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('BOU_kluivert', 'Kluivert', 'club', 'BOU', 4, 'good', 112, 'CAM', 19, 1, 112, 103, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('BRE_janelt', 'Janelt', 'club', 'BRE', 0, 'bad', 72, 'CM', 27, 1, 66, 68, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('BRE_potter', 'Lewis Potter', 'club', 'BRE', 1, 'bad', 70, 'LWB', 23, 1, 61, 67, 'club', 'Wing-back who runs the whole left side.'),
    ('BRE_schade', 'Schade', 'club', 'BRE', 2, 'alright', 99, 'LW', 7, 1, 104, 96, 'club', 'Speedy left winger who takes defenders on.'),
    ('BRE_mbeumo', 'Mbeumo', 'club', 'BRE', 3, 'alright', 94, 'RW', 19, 1, 101, 88, 'club', 'Tricky right winger who loves cutting inside.'),
    ('BRE_wissa', 'Wissa', 'club', 'BRE', 4, 'good', 114, 'ST', 11, 1, 121, 119, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('BRI_lamptey', 'Lamptey', 'club', 'BRI', 0, 'bad', 75, 'RB', 2, 1, 62, 75, 'club', 'Hard-working right-back who loves a tackle.'),
    ('BRI_igor', 'Igor', 'club', 'BRI', 1, 'bad', 85, 'CB', 3, 1, 68, 94, 'club', 'Tough centre-back who wins every duel.'),
    ('BRI_rutter', 'Rutter', 'club', 'BRI', 2, 'alright', 95, 'ST', 14, 1, 109, 100, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('BRI_mitoma', 'Mitoma', 'club', 'BRI', 3, 'alright', 97, 'LW', 22, 1, 105, 90, 'club', 'Speedy left winger who takes defenders on.'),
    ('BRI_joaopedro', 'Joao Pedro', 'club', 'BRI', 4, 'good', 118, 'ST', 9, 1, 131, 119, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('CHE_disasi', 'Disasi', 'club', 'CHE', 0, 'bad', 89, 'CB', 2, 1, 70, 98, 'club', 'Tough centre-back who wins every duel.'),
    ('CHE_cucurella', 'Cucurella', 'club', 'CHE', 1, 'bad', 83, 'LB', 3, 1, 76, 81, 'club', 'Overlapping left-back who never stops running.'),
    ('CHE_enzo', 'Enzo', 'club', 'CHE', 2, 'alright', 108, 'CM', 8, 1, 106, 111, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('CHE_palmer', 'Palmer', 'club', 'CHE', 3, 'alright', 125, 'CAM', 10, 1, 130, 117, 'club', 'Ice cold. Scores, then does the shiver celebration.'),
    ('CHE_caicedo', 'Caicedo', 'club', 'CHE', 4, 'good', 123, 'CDM', 25, 1, 109, 139, 'club', 'Tireless ball-winner in midfield.'),
    ('CRY_ward', 'Ward', 'club', 'CRY', 0, 'bad', 82, 'RB', 2, 1, 71, 78, 'club', 'Hard-working right-back who loves a tackle.'),
    ('CRY_lerma', 'Lerma', 'club', 'CRY', 1, 'bad', 79, 'CDM', 8, 1, 69, 91, 'club', 'Holding midfielder who breaks up play.'),
    ('CRY_mateta', 'Mateta', 'club', 'CRY', 2, 'alright', 90, 'ST', 14, 1, 97, 101, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('CRY_eze', 'Eze', 'club', 'CRY', 3, 'alright', 91, 'CAM', 10, 1, 99, 84, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('CRY_guehi', 'Guehi', 'club', 'CRY', 4, 'good', 116, 'CB', 6, 1, 97, 124, 'club', 'Tough centre-back who wins every duel.'),
    ('EVE_young', 'Young', 'club', 'EVE', 0, 'bad', 80, 'RB', 18, 2, 71, 74, 'club', 'Hard-working right-back who loves a tackle.'),
    ('EVE_tarkowski', 'Tarkowski', 'club', 'EVE', 1, 'bad', 75, 'CB', 6, 2, 53, 86, 'club', 'Tough centre-back who wins every duel.'),
    ('EVE_pickford', 'Pickford', 'club', 'EVE', 2, 'alright', 95, 'GK', 1, 2, 63, 103, 'club', 'Shot-stopper with safe hands.'),
    ('EVE_ndiaye', 'Ndiaye', 'club', 'EVE', 3, 'alright', 91, 'LW', 10, 2, 98, 88, 'club', 'Speedy left winger who takes defenders on.'),
    ('EVE_beto', 'Beto', 'club', 'EVE', 4, 'good', 111, 'ST', 9, 2, 123, 117, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('FUL_reed', 'Reed', 'club', 'FUL', 0, 'bad', 89, 'CDM', 6, 2, 75, 98, 'club', 'Holding midfielder who breaks up play.'),
    ('FUL_robinson', 'Robinson', 'club', 'FUL', 1, 'bad', 73, 'LB', 33, 2, 66, 71, 'club', 'Overlapping left-back who never stops running.'),
    ('FUL_iwobi', 'Iwobi', 'club', 'FUL', 2, 'alright', 94, 'RW', 17, 2, 104, 91, 'club', 'Tricky right winger who loves cutting inside.'),
    ('FUL_pereira', 'Pereira', 'club', 'FUL', 3, 'alright', 97, 'CAM', 18, 2, 99, 88, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('FUL_jimenez', 'Jimenez', 'club', 'FUL', 4, 'good', 111, 'ST', 7, 2, 125, 110, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('LIV_gomez', 'Gomez', 'club', 'LIV', 0, 'bad', 80, 'CB', 2, 2, 59, 92, 'club', 'Tough centre-back who wins every duel.'),
    ('LIV_tsimikas', 'Tsimikas', 'club', 'LIV', 1, 'bad', 79, 'LB', 21, 2, 73, 75, 'club', 'Overlapping left-back who never stops running.'),
    ('LIV_macallister', 'Mac Allister', 'club', 'LIV', 2, 'alright', 94, 'CM', 10, 2, 95, 97, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('LIV_szoboszlai', 'Szoboszlai', 'club', 'LIV', 3, 'alright', 106, 'CAM', 8, 2, 111, 103, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('LIV_salah', 'Salah', 'club', 'LIV', 4, 'good', 145, 'RW', 11, 2, 150, 138, 'icon', 'The Egyptian King. Cuts inside and bends it far post.'),
    ('MCI_ake', 'Ake', 'club', 'MCI', 0, 'bad', 83, 'CB', 6, 2, 68, 92, 'club', 'Tough centre-back who wins every duel.'),
    ('MCI_akanji', 'Akanji', 'club', 'MCI', 1, 'bad', 72, 'CB', 25, 2, 54, 85, 'club', 'Tough centre-back who wins every duel.'),
    ('MCI_foden', 'Foden', 'club', 'MCI', 2, 'alright', 100, 'CAM', 47, 2, 101, 95, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('MCI_rodri', 'Rodri', 'club', 'MCI', 3, 'alright', 127, 'CDM', 16, 2, 121, 141, 'club', 'The metronome. Never loses the ball.'),
    ('MCI_haaland', 'Haaland', 'club', 'MCI', 4, 'good', 129, 'ST', 9, 2, 142, 142, 'club', 'A goal machine that runs through defenders.'),
    ('MUN_lindelof', 'Lindelof', 'club', 'MUN', 0, 'bad', 85, 'CB', 2, 2, 68, 96, 'club', 'Tough centre-back who wins every duel.'),
    ('MUN_malacia', 'Malacia', 'club', 'MUN', 1, 'bad', 83, 'LB', 12, 2, 75, 78, 'club', 'Overlapping left-back who never stops running.'),
    ('MUN_garnacho', 'Garnacho', 'club', 'MUN', 2, 'alright', 101, 'LW', 17, 2, 109, 95, 'club', 'Speedy left winger who takes defenders on.'),
    ('MUN_bruno', 'Bruno', 'club', 'MUN', 3, 'alright', 99, 'CAM', 8, 2, 104, 95, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('MUN_mainoo', 'Mainoo', 'club', 'MUN', 4, 'good', 117, 'CM', 37, 2, 111, 121, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('NEW_burn', 'Burn', 'club', 'NEW', 0, 'bad', 77, 'LB', 33, 2, 69, 75, 'club', 'Overlapping left-back who never stops running.'),
    ('NEW_targett', 'Targett', 'club', 'NEW', 1, 'bad', 82, 'LB', 13, 2, 73, 77, 'club', 'Overlapping left-back who never stops running.'),
    ('NEW_gordon', 'Gordon', 'club', 'NEW', 2, 'alright', 97, 'LW', 10, 2, 104, 94, 'club', 'Speedy left winger who takes defenders on.'),
    ('NEW_brunog', 'Bruno G', 'club', 'NEW', 3, 'alright', 93, 'CM', 39, 2, 93, 91, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('NEW_isak', 'Isak', 'club', 'NEW', 4, 'good', 124, 'ST', 14, 2, 138, 130, 'club', 'Silky striker with a killer finish.'),
    ('NOT_yates', 'Yates', 'club', 'NOT', 0, 'bad', 89, 'CDM', 22, 2, 82, 96, 'club', 'Holding midfielder who breaks up play.'),
    ('NOT_toffolo', 'Toffolo', 'club', 'NOT', 1, 'bad', 85, 'LB', 15, 2, 76, 87, 'club', 'Overlapping left-back who never stops running.'),
    ('NOT_elanga', 'Elanga', 'club', 'NOT', 2, 'alright', 107, 'RW', 21, 2, 109, 104, 'club', 'Tricky right winger who loves cutting inside.'),
    ('NOT_gibbswhite', 'Gibbs-White', 'club', 'NOT', 3, 'alright', 105, 'CAM', 10, 2, 111, 103, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('NOT_hudsonodoi', 'Hudson-Odoi', 'club', 'NOT', 4, 'good', 118, 'LW', 14, 2, 122, 111, 'club', 'Speedy left winger who takes defenders on.'),
    ('TOT_davies', 'Davies', 'club', 'TOT', 0, 'bad', 88, 'LB', 33, 3, 79, 88, 'club', 'Overlapping left-back who never stops running.'),
    ('TOT_dragusin', 'Dragusin', 'club', 'TOT', 1, 'bad', 76, 'CB', 6, 3, 60, 87, 'club', 'Tough centre-back who wins every duel.'),
    ('TOT_maddison', 'Maddison', 'club', 'TOT', 2, 'alright', 97, 'CAM', 10, 3, 104, 87, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('TOT_romero', 'Romero', 'club', 'TOT', 3, 'alright', 108, 'CB', 17, 3, 92, 117, 'club', 'Tough centre-back who wins every duel.'),
    ('TOT_son', 'Son', 'club', 'TOT', 4, 'good', 121, 'LW', 7, 3, 126, 115, 'club', 'Two-footed finisher with a huge smile.'),
    ('WES_coufal', 'Coufal', 'club', 'WES', 0, 'bad', 89, 'RB', 5, 3, 83, 87, 'club', 'Hard-working right-back who loves a tackle.'),
    ('WES_cresswell', 'Cresswell', 'club', 'WES', 1, 'bad', 87, 'LB', 3, 3, 77, 88, 'club', 'Overlapping left-back who never stops running.'),
    ('WES_bowen', 'Bowen', 'club', 'WES', 2, 'alright', 101, 'RW', 20, 3, 103, 93, 'club', 'Tricky right winger who loves cutting inside.'),
    ('WES_paqueta', 'Paqueta', 'club', 'WES', 3, 'alright', 109, 'CAM', 10, 3, 114, 103, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('WES_kudus', 'Kudus', 'club', 'WES', 4, 'good', 117, 'RW', 14, 3, 120, 108, 'club', 'Tricky right winger who loves cutting inside.'),
    ('WOL_doherty', 'Doherty', 'club', 'WOL', 0, 'bad', 72, 'RB', 2, 3, 62, 73, 'club', 'Hard-working right-back who loves a tackle.'),
    ('WOL_lemina', 'Lemina', 'club', 'WOL', 1, 'bad', 72, 'CDM', 5, 3, 66, 78, 'club', 'Holding midfielder who breaks up play.'),
    ('WOL_cunha', 'Cunha', 'club', 'WOL', 2, 'alright', 98, 'ST', 10, 3, 109, 103, 'club', 'Striker who lives in the box and hunts every rebound.'),
    ('WOL_aitnouri', 'Ait-Nouri', 'club', 'WOL', 3, 'alright', 109, 'LB', 3, 3, 98, 108, 'club', 'Overlapping left-back who never stops running.'),
    ('WOL_sarabia', 'Sarabia', 'club', 'WOL', 4, 'good', 115, 'LW', 21, 3, 122, 107, 'club', 'Speedy left winger who takes defenders on.'),
    ('SUN_onien', "O'Nien", 'club', 'SUN', 0, 'bad', 71, 'CB', 13, 3, 52, 83, 'club', 'Tough centre-back who wins every duel.'),
    ('SUN_ballard', 'Ballard', 'club', 'SUN', 1, 'bad', 83, 'CB', 5, 3, 66, 97, 'club', 'Tough centre-back who wins every duel.'),
    ('SUN_clarke', 'Clarke', 'club', 'SUN', 2, 'alright', 94, 'LW', 20, 3, 103, 88, 'club', 'Speedy left winger who takes defenders on.'),
    ('SUN_lefee', 'Le Fee', 'club', 'SUN', 3, 'alright', 96, 'CM', 28, 3, 96, 96, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('SUN_bellingham', 'Bellingham', 'club', 'SUN', 4, 'good', 127, 'CM', 7, 3, 123, 128, 'club', 'Box-to-box star who always turns up for the big goal.'),
    ('INT_aviles', 'Aviles', 'club', 'INT', 0, 'bad', 71, 'CB', 17, 3, 51, 82, 'club', 'Tough centre-back who wins every duel.'),
    ('INT_redondo', 'Redondo', 'club', 'INT', 1, 'bad', 84, 'CDM', 55, 3, 76, 88, 'club', 'Holding midfielder who breaks up play.'),
    ('INT_suarez', 'Suarez', 'club', 'INT', 2, 'alright', 140, 'ST', 9, 3, 150, 144, 'icon', 'Sharp, cheeky and deadly in front of goal.'),
    ('INT_depaul', 'De Paul', 'club', 'INT', 3, 'alright', 102, 'CM', 7, 3, 102, 99, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('INT_messi', 'Messi', 'club', 'INT', 4, 'good', 150, 'RW', 10, 3, 150, 137, 'icon', 'The GOAT. Glides past everyone and never misses the target.'),
    ('ALN_alghannam', 'Al Ghannam', 'club', 'ALN', 0, 'bad', 71, 'RB', 2, 3, 60, 65, 'club', 'Hard-working right-back who loves a tackle.'),
    ('ALN_alkhaibari', 'Al Khaibari', 'club', 'ALN', 1, 'bad', 74, 'CDM', 17, 3, 64, 86, 'club', 'Holding midfielder who breaks up play.'),
    ('ALN_mane', 'Mane', 'club', 'ALN', 2, 'alright', 98, 'LW', 10, 3, 106, 93, 'club', 'Speedy left winger who takes defenders on.'),
    ('ALN_joaofelix', 'Joao Felix', 'club', 'ALN', 3, 'alright', 96, 'CF', 79, 3, 105, 95, 'club', 'Clever forward who drifts deep and finishes calmly.'),
    ('ALN_ronaldo', 'Ronaldo', 'club', 'ALN', 4, 'good', 148, 'ST', 7, 3, 150, 150, 'icon', 'Built like a tank, jumps higher than anyone and smashes it.'),
    ('BAR_ferran', 'Ferran Torres', 'club', 'BAR', 0, 'bad', 83, 'LW', 7, 3, 91, 76, 'club', 'Speedy left winger who takes defenders on.'),
    ('BAR_fermin', 'Fermin Lopez', 'club', 'BAR', 1, 'bad', 85, 'CAM', 16, 3, 86, 83, 'club', 'Creative playmaker with an eye for a killer pass.'),
    ('BAR_pedri', 'Pedri', 'club', 'BAR', 2, 'alright', 108, 'CM', 8, 3, 108, 110, 'club', 'Engine-room midfielder who covers every blade of grass.'),
    ('BAR_raphinha', 'Raphinha', 'club', 'BAR', 3, 'alright', 108, 'RW', 11, 3, 113, 98, 'club', 'Tricky right winger who loves cutting inside.'),
    ('BAR_yamal', 'Lamine Yamal', 'club', 'BAR', 4, 'good', 146, 'RW', 10, 3, 149, 124, 'icon', 'Wonderkid winger - curls it into the corner from anywhere.'),
    ('SIG_JPN_aoyagi', 'Ren Aoyagi', 'sig', 'JPN', 0, 'good', 187, 'CAM', 7, None, 187, 160, 'prodigy',
     'Sees the whole pitch before anyone moves. Precision, control and a cold stare - a different level.'),
    ('SIG_BRA_neymar', 'Neymar Jr', 'sig', 'BRA', 0, 'good', 150, 'LW', 10, None, 149, 131, 'signature',
     'Samba skills and no-look flicks - dances past defenders and finishes with a smile.'),
]
CLUB_PACKS = {1: ('ARS', 'AST', 'BOU', 'BRE', 'BRI', 'CHE', 'CRY'), 2: ('EVE', 'FUL', 'LIV', 'MCI', 'MUN', 'NEW', 'NOT'), 3: ('TOT', 'WES', 'WOL', 'SUN', 'INT', 'ALN', 'BAR')}

# ---- Star Signing (STORE) -------------------------------------------------------------------------
# Elite cards, bought once each with Star Points. Star Points come from exchanging players
# you don't use. They can't be exchanged back, and they play in your Club Football squad.
# (slug, name, position, OVR, price in Star Points, nation, club, shirt number, description)
# price None = not for sale: the website admin hands this one out
STAR_SIGNINGS = (
    ("neto", "Pedro Neto", "RW", 150, None, "POR", "CHE", 7,
     "Chelsea's flying winger - beats his man on either side and crosses at full speed."),
    ("pele", "Pele", "ST", 150, 100000, "BRA", "SAN", 10,
     "Three-time world champion. Scores every kind of goal there is."),
    ("r9", "R9 Ronaldo", "ST", 150, 100000, "BRA", "RMA", 9,
     "O Fenomeno. Step-overs at full speed and a finish that never misses."),
    ("maradona", "Maradona", "CAM", 149, 95000, "ARG", "NAP", 10,
     "Magic left foot and a low centre of gravity - dribbles through whole teams."),
    ("zidane", "Zidane", "CAM", 149, 92000, "FRA", "RMA", 5,
     "Silky first touch and big-game volleys. Makes the hardest things look calm."),
    ("ronaldinho", "Ronaldinho", "LW", 149, 90000, "BRA", "BAR", 10,
     "Always smiling, always inventing - elasticos, flicks and no-look passes."),
    ("mbappe", "Mbappe", "ST", 148, 85000, "FRA", "RMA", 9,
     "Blistering pace in behind and ice-cold in front of goal."),
    ("neymar", "Neymar", "LW", 148, 82000, "BRA", "SAN", 11,
     "The Santos prodigy - skill moves, flair and fearless dribbling."),
    ("cruyff", "Cruyff", "CAM", 148, 80000, "NET", "BAR", 14,
     "Total football. Sees the game two moves ahead and turns on a coin."),
    ("gullit", "Gullit", "CM", 147, 73000, "NET", "MIL", 10,
     "Power, height and skill in one - dominates every part of the pitch."),
    ("hazard", "Eden Hazard", "LW", 147, 70000, "BEL", "CHE", 10,
     "Low, quick and slippery - loves to dribble in from the left."),
    ("iniesta", "Iniesta", "CM", 147, 70000, "SPA", "BAR", 8,
     "Glides past pressure and always finds the right pass."),
    ("xavi", "Xavi", "CM", 146, 68000, "SPA", "BAR", 6,
     "The metronome of midfield. Never gives the ball away."),
    ("kaka", "Kaka", "CAM", 146, 65000, "BRA", "MIL", 22,
     "Long, elegant strides - carries the ball from box to box."),
    ("henry", "Henry", "ST", 146, 64000, "FRA", "ARS", 14,
     "Pace, poise and side-foot finishes into the far corner."),
    ("vanbasten", "Van Basten", "ST", 145, 62000, "NET", "MIL", 9,
     "Elegant striker with a flair for the impossible volley."),
    ("eusebio", "Eusebio", "ST", 145, 60000, "POR", "BEN", 10,
     "The Black Panther - explosive speed and a thunderous right foot."),
    ("maldini", "Maldini", "CB", 145, 60000, "ITA", "MIL", 3,
     "Defending as an art form. Reads everything and never needs to rush."),
    ("beckenbauer", "Beckenbauer", "CB", 145, 58000, "GER", "BAY", 5,
     "Der Kaiser. A sweeper who brings the ball out like a playmaker."),
    ("ramos", "Sergio Ramos", "CB", 144, 55000, "SPA", "RMA", 4,
     "Leader at the back - fierce tackles and last-minute headers."),
    ("vandijk", "Van Dijk", "CB", 144, 54000, "NET", "LIV", 4,
     "Calm, dominant and unbeatable in the air."),
    ("cafu", "Cafu", "RB", 143, 50000, "BRA", "MIL", 2,
     "Tireless right-back who bombs forward all game long."),
    ("rcarlos", "Roberto Carlos", "LB", 143, 50000, "BRA", "RMA", 3,
     "Rocket left foot - free kicks that bend the laws of physics."),
    ("yashin", "Yashin", "GK", 143, 48000, "RUS", "DYN", 1,
     "The Black Spider. Stops everything that comes near him."),
    ("neuer", "Neuer", "GK", 142, 45000, "GER", "BAY", 1,
     "Sweeper-keeper who rushes out and plays like an outfielder."),
    ("buffon", "Buffon", "GK", 142, 44000, "ITA", "JUV", 1,
     "Legendary reflexes - a wall between the posts."),
    ("modric", "Modric", "CM", 142, 42000, "CRO", "RMA", 10,
     "Outside-of-the-boot passes and endless energy."),
    ("debruyne", "De Bruyne", "CAM", 141, 40000, "BEL", "MCI", 17,
     "Pinpoint crosses and rockets from the edge of the box."),
    ("salah", "Salah", "RW", 141, 38000, "EGY", "LIV", 11,
     "Cuts in from the right and curls it into the far corner."),
    ("vinicius", "Vinicius Jr", "LW", 141, 37000, "BRA", "RMA", 7,
     "Explosive dribbler who lives for the one-on-one."),
    ("haaland", "Haaland", "ST", 140, 35000, "NOR", "MCI", 9,
     "A goal machine - power, pace and a ruthless finish."),
    ("bellingham", "Bellingham", "CM", 140, 34000, "ENG", "RMA", 5,
     "Box-to-box midfielder with a striker's instinct."),
    ("rodri", "Rodri", "CDM", 139, 32000, "SPA", "MCI", 16,
     "Controls the tempo and shields the defence."),
    ("saka", "Saka", "RW", 139, 30000, "ENG", "ARS", 7,
     "Direct winger who takes on his man every single time."),
    ("musiala", "Musiala", "CAM", 138, 28000, "GER", "BAY", 10,
     "Slaloms through crowds with the ball glued to his feet."),
    ("pedri", "Pedri", "CM", 138, 27000, "SPA", "BAR", 8,
     "Clever, composed and always two steps ahead."),
    ("wirtz", "Wirtz", "CAM", 137, 25000, "GER", "LIV", 7,
     "Creative spark - slips passes through the tiniest gaps."),
    ("yamal", "Yamal", "RW", 137, 25000, "SPA", "BAR", 10,
     "Wonderkid winger - curls it into the corner from anywhere."),
    ("kane", "Kane", "ST", 136, 23000, "ENG", "BAY", 9,
     "Complete forward - drops deep to create, then finishes clinically."),
    ("suarez", "Suarez", "ST", 136, 22000, "URU", "BAR", 9,
     "Sharp, cheeky and deadly in front of goal."),
    ("pirlo", "Pirlo", "CM", 135, 20000, "ITA", "MIL", 21,
     "The Architect. Long passes and free kicks with total calm."),
)
# ---- ABILITIES: 10 defending, 10 dribbling, 10 attacking -------------------------------------------
# Only cards over 100 get them. Every effect is passive - it quietly bends the physics.
# Tier scales the size of the effect: bronze -> silver -> gold -> platinum -> diamond.
ABILITY_TIERS = (("BRONZE", (206, 132, 70), 1.0), ("SILVER", (208, 216, 230), 1.45),
                 ("GOLD", (246, 200, 70), 2.0), ("PLATINUM", (140, 232, 226), 2.6),
                 ("DIAMOND", (176, 196, 255), 3.3))
ABILITY_CATS = {"def": ("DEFENDING", (120, 190, 255)), "drb": ("DRIBBLING", (150, 240, 170)),
                "att": ("ATTACKING", (255, 150, 120))}
ABILITIES = (
    # ---- defending
    ("wall", "WALL", "def", {"body_own": 0.16}, "A wider body to block with inside your own half."),
    ("anchor", "ANCHOR", "def", {"anchor": 0.13}, "Shrugs off contact - you get knocked back far less."),
    ("tank", "TANK", "def", {"mass": 0.15}, "Everyone you hit gets launched further."),
    ("sweeper", "SWEEPER", "def", {"sweep": 0.12}, "More throw power and range while the ball is in your third."),
    ("intercept", "INTERCEPTOR", "def", {"body": 0.07}, "A bigger reach on the ball wherever you are."),
    ("lastman", "LAST MAN", "def", {"hit_own": 0.20}, "Huge clearances when the ball is in your own half."),
    ("steel", "STEEL", "def", {"settle": 0.18}, "Lands, settles and gets back up faster."),
    ("blocker", "BLOCKER", "def", {"rebound": 0.16}, "The ball pings off you harder."),
    ("guardian", "GUARDIAN", "def", {"anchor": 0.07, "cushion_own": 0.12},
     "The ball dies on you in your own half, and shoves barely move you."),
    ("press", "PRESSURE", "def", {"press": 0.10}, "Extra throw power while you're right on top of the opponent."),
    # ---- dribbling
    ("first_touch", "FIRST TOUCH", "drb", {"control": 0.11}, "Soft touches stick to your feet."),
    ("quick", "QUICK FEET", "drb", {"settle": 0.12, "quick": 0.30}, "Back on your feet and throwing again sooner."),
    ("glide", "GLIDE", "drb", {"glide": 0.14}, "Less air drag - you carry your momentum further."),
    ("feather", "FEATHER", "drb", {"float": 0.07}, "Lighter in the air: you hang up there longer."),
    ("spring", "SPRING", "drb", {"spring": 0.22}, "Bounces off the ground instead of flopping."),
    ("agile", "AGILE", "drb", {"range": 0.09}, "You can drag the aim arrow further before it maxes out."),
    ("spin", "SPIN", "drb", {"curve": 0.30}, "Puts real curve on the ball when you hit it."),
    ("silky", "SILKY", "drb", {"control": 0.07, "cushion": 0.08}, "Cushions the ball and keeps it close."),
    ("escape", "ESCAPE", "drb", {"burst": 0.14}, "A burst of power for a moment after someone clatters you."),
    ("low", "LOW CENTRE", "drb", {"settle": 0.11, "anchor": 0.06}, "Stays upright through contact and landings."),
    # ---- attacking
    ("rocket", "ROCKET", "att", {"hit": 0.11}, "Every hit on the ball is harder."),
    ("finisher", "FINISHER", "att", {"hit_att": 0.15}, "Extra power on anything you hit in their half."),
    ("poacher", "POACHER", "att", {"hit_box": 0.24}, "Ruthless from inside their box."),
    ("header", "HEADER", "att", {"hit_high": 0.20}, "Smashes anything above your head."),
    ("sniper", "SNIPER", "att", {"aim": 0.13}, "Steadier aim, and your hits bend towards goal."),
    ("cannon", "CANNON", "att", {"power": 0.09}, "You throw yourself harder."),
    ("volley", "VOLLEY", "att", {"hit_fast": 0.18}, "Meets a fast-moving ball on the volley."),
    ("longshot", "LONG SHOT", "att", {"hit_far": 0.18}, "More power from outside the box."),
    ("lob", "LOB", "att", {"lift": 0.14}, "Lifts the ball over people instead of driving it."),
    ("clutch", "CLUTCH", "att", {"clutch": 0.14}, "Turns it up when you're behind or the clock is nearly gone."),
)
ABILITY_BY_KEY = {a[0]: {"key": a[0], "name": a[1], "cat": a[2], "fx": a[3], "text": a[4]} for a in ABILITIES}
ABILITY_POOLS = {cat: [a[0] for a in ABILITIES if a[2] == cat] for cat in ("def", "drb", "att")}
# which category a position pulls from first, second, third...
ABILITY_POS = {"GK": ("def", "def", "def", "drb"), "CB": ("def", "def", "drb", "att"),
               "LB": ("def", "drb", "def", "att"), "RB": ("def", "drb", "def", "att"),
               "CDM": ("def", "drb", "att", "def"), "CM": ("drb", "def", "att", "drb"),
               "CAM": ("drb", "att", "drb", "def"), "LW": ("drb", "att", "drb", "att"),
               "RW": ("drb", "att", "drb", "att"), "ST": ("att", "att", "drb", "att"),
               "CF": ("att", "drb", "att", "drb")}
# hand-picked kits for the big names (strongest first, topped up from the position pools)
ABILITY_SIGNATURE = {
    "SIG_JPN_aoyagi": ("sniper", "first_touch", "rocket", "quick"),
    "SIG_BRA_neymar": ("spin", "silky", "escape", "first_touch"),
    "WC_ARG_messi": ("silky", "sniper", "first_touch", "spin"),
    "INT_messi": ("silky", "sniper", "first_touch", "spin"),
    "WC_POR_ronaldo": ("header", "rocket", "cannon", "volley"),
    "ALN_ronaldo": ("header", "rocket", "cannon", "volley"),
    "WC_SPA_yamal": ("spin", "quick", "escape", "sniper"),
    "BAR_yamal": ("spin", "quick", "escape", "sniper"),
    "STAR_pele": ("poacher", "rocket", "header", "clutch"),
    "STAR_r9": ("quick", "escape", "finisher", "rocket"),
    "STAR_maradona": ("silky", "first_touch", "spin", "sniper"),
    "STAR_zidane": ("first_touch", "silky", "sniper", "cannon"),
    "STAR_ronaldinho": ("spin", "silky", "escape", "lob"),
    "STAR_mbappe": ("quick", "glide", "finisher", "rocket"),
    "STAR_neymar": ("spin", "silky", "escape", "sniper"),
    "STAR_cruyff": ("first_touch", "sniper", "agile", "silky"),
    "STAR_gullit": ("tank", "rocket", "header", "press"),
    "STAR_hazard": ("silky", "quick", "escape", "first_touch"),
    "STAR_iniesta": ("first_touch", "silky", "agile", "sniper"),
    "STAR_xavi": ("sniper", "first_touch", "agile", "silky"),
    "STAR_kaka": ("glide", "quick", "finisher", "rocket"),
    "STAR_henry": ("finisher", "sniper", "quick", "glide"),
    "STAR_vanbasten": ("volley", "poacher", "header", "rocket"),
    "STAR_eusebio": ("rocket", "cannon", "longshot", "quick"),
    "STAR_maldini": ("wall", "anchor", "intercept", "steel"),
    "STAR_beckenbauer": ("sweeper", "intercept", "first_touch", "steel"),
    "STAR_ramos": ("tank", "header", "wall", "lastman"),
    "STAR_vandijk": ("wall", "anchor", "tank", "intercept"),
    "STAR_cafu": ("glide", "press", "intercept", "agile"),
    "STAR_rcarlos": ("cannon", "longshot", "rocket", "spin"),
    "STAR_yashin": ("wall", "blocker", "guardian", "anchor"),
    "STAR_neuer": ("sweeper", "guardian", "blocker", "wall"),
    "STAR_buffon": ("blocker", "guardian", "wall", "steel"),
    "STAR_modric": ("agile", "first_touch", "sniper", "silky"),
    "STAR_debruyne": ("sniper", "cannon", "longshot", "first_touch"),
    "STAR_salah": ("quick", "finisher", "glide", "spin"),
    "STAR_vinicius": ("quick", "escape", "glide", "spin"),
    "STAR_haaland": ("poacher", "rocket", "header", "tank"),
    "STAR_bellingham": ("press", "escape", "finisher", "header"),
    "STAR_rodri": ("intercept", "wall", "first_touch", "sniper"),
    "STAR_saka": ("quick", "spin", "escape", "finisher"),
    "STAR_musiala": ("silky", "quick", "escape", "first_touch"),
    "STAR_pedri": ("first_touch", "agile", "silky", "sniper"),
    "STAR_wirtz": ("first_touch", "sniper", "silky", "quick"),
    "STAR_yamal": ("spin", "quick", "escape", "sniper"),
    "STAR_kane": ("longshot", "rocket", "poacher", "sniper"),
    "STAR_suarez": ("poacher", "finisher", "clutch", "rocket"),
    "STAR_pirlo": ("sniper", "cannon", "lob", "first_touch"),
    "NO10_bellingham": ("press", "header", "finisher", "escape"),
    "NO10_wirtz": ("first_touch", "sniper", "silky", "quick"),
    "NO10_bruno": ("sniper", "longshot", "cannon", "first_touch"),
    "NO10_olmo": ("first_touch", "silky", "finisher", "agile"),
    "NO10_eze": ("escape", "spin", "longshot", "silky"),
    "NO10_guler": ("spin", "sniper", "lob", "first_touch"),
    "NO10_stanciu": ("longshot", "sniper", "cannon", "spin"),
    "NO10_ihagi": ("spin", "first_touch", "finisher", "agile"),
    "NO10_olaru": ("press", "first_touch", "longshot", "escape"),
    "ROOKIE_palmer": ("sniper", "first_touch", "silky", "clutch"),
    "INT_suarez": ("poacher", "finisher", "clutch", "rocket"),
    "LIV_salah": ("quick", "finisher", "glide", "spin"),
    "MCI_haaland": ("poacher", "rocket", "header", "tank"),
    "NET_vandijk": ("wall", "anchor", "tank", "intercept"),
    "POL_lewandowski": ("poacher", "volley", "header", "finisher"),
    "CRO_modric": ("agile", "first_touch", "sniper", "silky"),
    "WC_ENG_bellingham": ("press", "escape", "finisher", "header"),
    "WC_FRA_mbappe": ("quick", "glide", "finisher", "rocket"),
    "WC_BRA_vinicius": ("quick", "escape", "glide", "spin"),
}
ABILITY_MIN = 100              # you need to be OVER this to have any abilities


def ability_tiers(rating):
    """Tier indexes by rating: 101-110 bronze, 111-120 silver, 121-130 gold + bronze,
    131-140 platinum + silver + bronze, 141+ diamond + gold + silver + bronze."""
    if rating <= ABILITY_MIN:
        return ()
    if rating <= 110:
        return (0,)
    if rating <= 120:
        return (1,)
    if rating <= 130:
        return (2, 0)
    if rating <= 140:
        return (3, 1, 0)
    return (4, 2, 1, 0)


def card_ability_keys(card):
    """A card's abilities, strongest first. Hand-picked for the big names, otherwise
    drawn from its position's categories - fixed per card, never random."""
    tiers = ability_tiers(card["rating"])
    if not tiers:
        return ()
    keys = [k for k in ABILITY_SIGNATURE.get(card["id"], ()) if k in ABILITY_BY_KEY][:len(tiers)]
    order = ABILITY_POS.get(card["pos"], ("drb", "att", "def", "drb"))
    rng = random.Random("ability:" + card["id"])
    i = 0
    while len(keys) < len(tiers):
        pool = [k for k in ABILITY_POOLS[order[i % len(order)]] if k not in keys]
        if not pool:
            pool = [k for k in ABILITY_BY_KEY if k not in keys]
        keys.append(pool[rng.randrange(len(pool))])
        i += 1
    return tuple(keys)


def ability_list(card):
    """[(ability, tier index)] for a card."""
    return tuple(zip((ABILITY_BY_KEY[k] for k in card_ability_keys(card)), ability_tiers(card["rating"])))


def _ab(doll, key):
    return getattr(doll, "ab", {}).get(key, 0.0)

# ---- NO. 10 PACK (pack 4): playmakers, three pools that feel different
# (slug, name, pos, OVR, nation, number, description)
NO10_POOL_A = (
    ("bellingham", "Jude Bellingham", "CM", 136, "ENG", 5,
     "Arrives in the box like a striker and runs the game like a 10."),
    ("wirtz", "Florian Wirtz", "CAM", 134, "GER", 10,
     "Slips the pass nobody else sees, then turns up on the end of the next one."),
    ("bruno", "Bruno Fernandes", "CAM", 131, "POR", 8,
     "Through balls, long shots and set pieces - everything goes through him."),
)
NO10_POOL_B = (
    ("olmo", "Dani Olmo", "CAM", 118, "SPA", 10, "Silky between the lines, always facing forward."),
    ("eze", "Eberechi Eze", "CAM", 115, "ENG", 10, "Dances out of trouble and shoots from anywhere."),
    ("guler", "Arda Guler", "CAM", 113, "TUR", 10, "Left foot like a wand - whips it into the far corner."),
    ("stanciu", "Nicolae Stanciu", "CAM", 112, "ROU", 10, "Romania's number 10: free kicks and long-range rockets."),
    ("ihagi", "Ianis Hagi", "CAM", 109, "ROU", 10, "Carries the family number and loves cutting inside."),
    ("olaru", "Darius Olaru", "CAM", 107, "ROU", 10, "Runs the midfield and gets into the box late."),
)
NO10_POOL_C = (
    ("macallister", "Alexis Mac Allister", "CM", 99, "ARG", 10, "Neat, tidy and always in the right spot."),
    ("mount", "Mason Mount", "CAM", 97, "ENG", 7, "Tireless runner with a decent shot on him."),
    ("eriksen", "Christian Eriksen", "CM", 96, "DEN", 10, "Set-piece specialist who slows the game down."),
    ("ziyech", "Hakim Ziyech", "RW", 95, "MOR", 22, "That left foot from the right wing."),
    ("wardprowse", "James Ward-Prowse", "CM", 94, "ENG", 8, "Free kicks: the best thing about him by a mile."),
    ("oscar", "Oscar", "CAM", 93, "BRA", 8, "Clever little playmaker with a quick first touch."),
    ("locelso", "Giovani Lo Celso", "CAM", 92, "ARG", 18, "Left-footed, tidy, occasionally brilliant."),
    ("forsberg", "Emil Forsberg", "CAM", 90, "SWE", 10, "Dependable creator who picks a pass."),
)
NO10_CARDS = NO10_POOL_A + NO10_POOL_B + NO10_POOL_C
NO10_PACK = 4                  # pack index

# Beginner cards: the tutorial lets you pick one of these three (slug, name, pos, OVR, nation, club, number, text)
ROOKIE_CARDS = (
    ("palmer", "Cole Palmer", "CAM", 101, "ENG", "CHE", 10,
     "Cold-blooded playmaker who glides between the lines and never panics."),
    ("bellingham", "Jude Bellingham", "CM", 100, "ENG", "RMA", 5,
     "Box-to-box midfielder who turns up in the box at exactly the right moment."),
    ("vandijk", "Virgil van Dijk", "CB", 99, "NET", "LIV", 4,
     "Calm, strong and quick to recover - a rock at the back."),
)
STAR_CLUB_NAMES = {"SAN": "Santos", "RMA": "Real Madrid", "NAP": "Napoli", "MIL": "AC Milan", "BEN": "Benfica",
                   "BAY": "Bayern", "DYN": "Dynamo Moscow", "JUV": "Juventus", "BAR": "Barcelona",
                   "CHE": "Chelsea", "ARS": "Arsenal", "LIV": "Liverpool", "MCI": "Manchester City"}
STAR_CLUB_COUNTRY = {"SAN": "BRA", "RMA": "SPA", "NAP": "ITA", "MIL": "ITA", "BEN": "POR", "BAY": "GER",
                     "DYN": "RUS", "JUV": "ITA", "BAR": "SPA", "CHE": "ENG", "ARS": "ENG", "LIV": "ENG",
                     "MCI": "ENG"}
EXTRA_FLAGS = ("USA", "KSA", "BEL", "ITA", "GER", "RUS", "EGY", "NOR", "URU",
               "ROU", "TUR", "DEN", "SWE")                                    # drawn by make_art.py
STAR_PURPLE = (150, 70, 235)
STAR_LILAC = (214, 182, 255)
ROOKIE_MINT = (186, 255, 214)
# Star Points for exchanging one copy of a card, by OVR (straight lines between the points)
SP_CURVE = ((60, 150), (70, 200), (90, 600), (100, 1250), (110, 2500), (120, 4500), (130, 7500),
            (150, 20000), (190, 50000))
NO_EXCHANGE = ("SIG_JPN_aoyagi", "SIG_BRA_neymar")    # Ren Aoyagi + Neymar Jr (Star Signings can't be sold either)
STARS_PER_PAGE = 21                                    # 7 x 3 in the Star Signing shop
EXCHANGE_PER_PAGE = 24                                 # 8 x 3 on the exchange screen


def star_stats(pos, ovr):
    """(shooting, strength) for a Star Signing from his position."""
    if pos == "GK":
        return ovr - 55, ovr + 4
    if pos in ("CB", "LB", "RB"):
        return ovr - 26, ovr + 4
    if pos == "CDM":
        return ovr - 10, ovr + 2
    if pos in ("CM", "CAM"):
        return ovr - 1, ovr - 8
    return min(155, ovr + 3), ovr - 14


def star_points_for(rating):
    """Star Points for one copy of a card with this OVR."""
    pts = SP_CURVE
    if rating <= pts[0][0]:
        return pts[0][1]
    for (r0, v0), (r1, v1) in zip(pts, pts[1:]):
        if rating <= r1:
            v = v0 + (v1 - v0) * (rating - r0) / float(r1 - r0)
            return int(round(v / 10.0)) * 10
    return pts[-1][1]

# ---- cards, packs, coins, stamina ------------------------
PACK_PRICE = 300
PACK_NAMES = ("WORLD CUP", "CLUB PACK 1", "CLUB PACK 2", "CLUB PACK 3", "NO. 10 PACK")
PACK_TAGS = ("NATIONS", "CLUBS", "CLUBS", "CLUBS", "PLAYMAKERS")
STARTER_TIERS = ("bad", "bad", "bad", "alright", "alright")   # free starter pack
REWARD = {"win": 50, "draw": 25, "loss": 10}     # halved: the grind is the point
REWARD_PER_GOAL = 2
LEVEL_UP_COINS = 50                              # per level gained (was 100)
HALF_SECONDS = 30.0
STAMINA_PER_HALF = 50
STAMINA_REST = 50           # recovered by sitting out a match
STAMINA_RECOVER = 25        # recovered after every match by the players who played
SQUAD_SIZE = 5
SAVE_PATH = os.path.join(SCRIPT_DIR, "save.json")
# In the browser (pygbag) there is no writable disk: the save lives in the page's localStorage,
# and the page hands it on to Firebase so it follows the player's Google account around.
SAVE_KEY = "aswc_save"


def js_window():
    """The browser window object, or None when this isn't the web build."""
    if not WEB_BUILD:
        return None
    try:
        from platform import window
        return window
    except Exception:
        return None


# ==========================================================
# ONLINE PLAY + CHAT: the page (play.html) owns the connection; the game just
# posts messages to it and reads what comes back. All no-ops on the desktop.
# ==========================================================
NET_SNAP_HZ = 18.0                # host snapshots a second
NET_LERP = 0.25                   # how hard the guest is pulled onto each snapshot
CHAT_LINES = 4                    # messages shown in the corner
CHAT_SECONDS = 9.0                # how long each one hangs about
CHAT_PRESETS = ("GOOD LUCK", "NICE GOAL", "UNLUCKY", "GOOD GAME", "SORRY", "CLOSE ONE")


class NetLink:
    """Talks to the page through window.aswc* hooks."""

    def __init__(self):
        self.on = False
        self.w = js_window()
        if self.w is not None:
            try:
                self.w.aswcNetPoll                     # does the page provide the hooks?
                self.on = True
            except Exception:
                self.on = False

    def poll(self):
        if not self.on:
            return []
        try:
            raw = self.w.aswcNetPoll()
            return json.loads(raw) if raw else []
        except Exception:
            return []

    def send(self, msg):
        if not self.on:
            return
        try:
            self.w.aswcNetSend(json.dumps(msg))
        except Exception:
            pass

    def chat(self, text):
        if not self.on:
            return
        try:
            self.w.aswcChatSend(text)
        except Exception:
            pass

    def result(self, home, away):
        if not self.on:
            return
        try:
            self.w.aswcMatchResult(json.dumps({"home": home, "away": away}))
        except Exception:
            pass

    def connected_hint(self):
        """False only when the page says the peer connection has dropped."""
        if not self.on:
            return True
        try:
            return bool(self.w.aswcNetUp())
        except Exception:
            return True


def read_save_text():
    if WEB_BUILD:
        w = js_window()
        try:
            return w.localStorage.getItem(SAVE_KEY)
        except Exception:
            return None
    try:
        with open(SAVE_PATH, "r", encoding="utf-8") as fh:
            return fh.read()
    except Exception:
        return None


def write_save_text(text):
    if WEB_BUILD:
        w = js_window()
        try:
            w.localStorage.setItem(SAVE_KEY, text)
        except Exception:
            pass
        try:
            w.aswcSave(text)               # the page pushes it to the player's cloud save
        except Exception:
            pass                           # signed out / offline: localStorage still has it
        return
    tmp = SAVE_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    os.replace(tmp, SAVE_PATH)
DOUBLE_CLICK = 0.32         # seconds: double-click a card to see its stats
NATION_NAMES = {"ARG": "ARGENTINA", "BRA": "BRAZIL", "CRO": "CROATIA", "ENG": "ENGLAND", "FRA": "FRANCE",
                "MOR": "MOROCCO", "JPN": "JAPAN", "POL": "POLAND", "NET": "NETHERLANDS", "AUS": "AUSTRALIA",
                "SPA": "SPAIN", "POR": "PORTUGAL", "BEL": "BELGIUM", "ITA": "ITALY", "GER": "GERMANY",
                "RUS": "RUSSIA", "EGY": "EGYPT", "NOR": "NORWAY", "URU": "URUGUAY", "ROU": "ROMANIA",
                "TUR": "TURKEY", "DEN": "DENMARK", "SWE": "SWEDEN"}
PACK_TIER_A = 120           # icons and 120+ get the big walkout
PACK_TIER_B = 100           # 100-119 get the short cutscene
PITY_A = 60                 # pool A guaranteed within 60 packs (per pack type)
PITY_B = 10                 # pool B or better guaranteed within 10 packs
POOL_ODDS = {"A": 0.01, "B": 0.05, "C": 0.94}
TIER_COLOURS = {            # card frame: light, dark
    "bad": ((214, 142, 84), (120, 70, 36)),
    "alright": ((214, 220, 230), (120, 128, 146)),
    "good": ((248, 212, 90), (168, 118, 26)),
}
TEAM_PALETTE = [(220, 30, 40), (250, 120, 30), (250, 210, 40), (40, 160, 70), (20, 110, 60),
                (110, 190, 240), (30, 80, 190), (20, 30, 80), (120, 40, 150), (245, 170, 200),
                (250, 250, 250), (30, 30, 34), (122, 36, 58), (150, 150, 160)]
PATTERNS = ("PLAIN", "STRIPES", "HOOPS", "SLEEVES")

# 3x5 pixel font for the custom badge
FONT3 = {
    "A": "010101111101101", "B": "110101110101110", "C": "011100100100011", "D": "110101101101110",
    "E": "111100110100111", "F": "111100110100100", "G": "011100101101011", "H": "101101111101101",
    "I": "111010010010111", "J": "001001001101010", "K": "101101110101101", "L": "100100100100111",
    "M": "101111111101101", "N": "110101101101101", "O": "010101101101010", "P": "110101110100100",
    "Q": "010101101110011", "R": "110101110101101", "S": "011100010001110", "T": "111010010010010",
    "U": "101101101101111", "V": "101101101101010", "W": "101101111111101", "X": "101101010101101",
    "Y": "101101010010010", "Z": "111001010100111", "0": "111101101101111", "1": "010110010010111",
    "2": "111001111100111", "3": "111001111001111", "4": "101101111001001", "5": "111100111001111",
    "6": "111100111101111", "7": "111001010010010", "8": "111101111101111", "9": "111101111001111",
}


def _shade(c, k):
    if k < 1:
        return tuple(max(0, int(v * k)) for v in c)
    return tuple(min(255, int(v + (255 - v) * (k - 1))) for v in c)


def _grid_surface(w, h, fn, size):
    """Paint a w x h pixel grid with fn(x, y) -> colour or None, scaled to size."""
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(h):
        for x in range(w):
            c = fn(x, y)
            if c is not None:
                s.set_at((x, y), c)
    return pygame.transform.scale(s, (int(size[0]), int(size[1])))


def _kit_colour(c1, c2, pattern, x, y):
    if pattern == "STRIPES":
        return c2 if (x // 2) % 2 == 1 else c1
    if pattern == "HOOPS":
        return c2 if (y // 2) % 2 == 1 else c1
    return c1


def paint_torso(c1, c2, pattern, number, size):
    num = str(number)
    width = len(num) * 3 + (len(num) - 1)
    x0 = (16 - width) // 2
    cells = set()
    for i, ch in enumerate(num):
        bits = FONT3.get(ch, "")
        for k, b in enumerate(bits):
            if b == "1":
                cells.add((x0 + i * 4 + k % 3, 8 + k // 3))
    ink = (250, 250, 250) if sum(c1) < 380 else (24, 24, 30)
    busy = pattern in ("STRIPES", "HOOPS")

    def fn(x, y):
        if (x, y) in cells:
            return ink
        if busy and x0 - 1 <= x <= x0 + width and 7 <= y <= 13:
            return c1                                        # solid patch behind the number
        if pattern == "SLEEVES" and (x <= 1 or x >= 14) and y <= 4:
            return c2
        if y <= 1 and 4 <= x <= 11:                          # collar
            return _shade(c1, 0.55) if 6 <= x <= 9 and y == 0 else c2
        if 10 <= x <= 12 and 4 <= y <= 6:                    # badge
            return c2 if (x, y) != (11, 5) else c1
        col = _kit_colour(c1, c2, pattern, x, y)
        if x == 15 or y == 15:
            col = _shade(col, 0.84)
        return col
    return _grid_surface(16, 16, fn, size)


def paint_arm(c1, c2, pattern, skin, size):
    def fn(x, y):
        if y <= 5:
            col = c2 if pattern == "SLEEVES" else _kit_colour(c1, c2, pattern, x, y)
        elif y == 6:
            col = c2 if pattern != "SLEEVES" else c1
        else:
            col = skin if y < 15 else _shade(skin, 0.9)
        return _shade(col, 0.84) if x == 5 else col
    return _grid_surface(6, 16, fn, size)


def paint_leg(c1, c2, skin, boots, size):
    shorts = c2 if c2 != c1 else _shade(c1, 0.7)

    def fn(x, y):
        if y <= 5:
            col = shorts
        elif y == 6:
            col = c1
        elif y <= 9:
            col = skin
        elif y <= 13:
            col = c2 if y == 11 else c1
        else:
            col = boots if y == 14 else _shade(boots, 0.6)
        return _shade(col, 0.84) if x == 5 else col
    return _grid_surface(6, 16, fn, size)


def paint_badge(name, c1, c2, size):
    """Shield in the team colours with the first 3 letters of the name."""
    code = "".join(ch for ch in name.upper() if ch in FONT3)[:3] or "YOU"
    edge = c2 if c2 != c1 else (24, 24, 30)
    ink = (250, 250, 250) if sum(c1) < 380 else (24, 24, 30)
    letters = set()
    for i, ch in enumerate(code):
        for k, b in enumerate(FONT3[ch]):
            if b == "1":
                letters.add((4 + i * 4 + k % 3, 9 + k // 3))

    def fn(x, y):
        x0, x1 = (1, 18) if y < 16 else (1 + (y - 15), 18 - (y - 15))
        if x < x0 or x > x1:
            return None
        if x in (x0, x1) or y in (0, 23) or (y >= 16 and x in (x0, x1)):
            return edge
        if (x, y) in letters:
            return ink
        if 1 <= y <= 5:
            return edge
        return c1
    return _grid_surface(20, 24, fn, size)

CLUB_ROUNDS = 12
CLUB_NO_REPEAT = 3          # can't face the same club within 3 rounds
RELEGATION_ZONE = 3         # bottom 3...
RELEGATION_STRIKES = 2      # ...for 2 rounds in a row = removed from the league
MIN_CLUBS_LEFT = 4          # never shrink the league below this
# which of the 5 players each difficulty uses (EASY: a Bad one, MEDIUM: an Alright one)
CLUB_SLOTS = ((0, 1), (2, 3), (4,))

CPU_REACTION = 0.3          # seconds between CPU decisions
CPU_THINK_CHANCE = 0.4      # chance it pauses to "think" after landing
CPU_TACKLE_CHANCE = 0.15    # chance per decision to body-check you
CPU_LOSING_BONUS = 0.08     # extra skill per goal it's behind


# ==========================================================
# REN AOYAGI - an original prodigy with a full ability kit,
# an earned Awakening meter and two 30 fps cutscenes
# ==========================================================
REN_CARD = "SIG_JPN_aoyagi"
# Ren is retired: his card never loads, so he can't be owned or played. His stats, portrait,
# sprites, ability kit and cutscenes all stay in the files - flip this to True to put him back.
REN_IN_GAME = False
# When he is in the game he is the one card you can't buy or pack: win the World Cup with Japan
# on IMPOSSIBLE.
REN_UNLOCK_TEAM = "JPN"
REN_UNLOCK_HOW = "WIN THE WORLD CUP WITH JAPAN ON IMPOSSIBLE"
REN_UNLOCK_HINT = REN_UNLOCK_HOW + " TO UNLOCK REN AOYAGI (187)"
REN_LINES = ("...Enough. Warm-up's over.",
             "All of you are just chasing the ball.",
             "I'm the one who tells it where to go.")
CUT_FPS = 30                      # cutscenes step at 30 frames a second
CYAN = (70, 240, 255)
REN_PINK = (246, 142, 194)
REN_GREEN = (90, 255, 140)
REN_COOLDOWN = {"shot": 7.0, "dribble": 9.0, "buff": 18.0}
REN_BUFF_TIME = 7.0
REN_DRAIN = 3.0                   # awakening energy lost per second
REN_COST = {"dribble2": 15.0, "ultimate": 55.0}
REN_GAIN = {"goal": 35, "dribble": 20, "shot": 12, "beat": 6, "intercept": 6, "chance": 8, "strike": 3,
            "move": 1.5}
AWAKEN_LEN = 10.4                 # awakening cutscene length (s)
ULTI_LEN = 7.8                    # "Untouchable" cutscene length (s)
PUPPET_POSES = {
    "stand": dict(lean=0.0, head=0.0, arm_f=0.15, arm_b=-0.15, leg_f=0.08, leg_b=-0.08, lift=0),
    "down": dict(lean=0.12, head=0.45, arm_f=0.1, arm_b=-0.1, leg_f=0.06, leg_b=-0.06, lift=0),
    "touch": dict(lean=0.1, head=0.25, arm_f=0.5, arm_b=-0.4, leg_f=0.75, leg_b=-0.2, lift=0),
    "feint": dict(lean=-0.38, head=-0.2, arm_f=-0.9, arm_b=0.6, leg_f=-0.35, leg_b=0.45, lift=0),
    "cut": dict(lean=0.42, head=0.1, arm_f=0.9, arm_b=-0.8, leg_f=0.9, leg_b=-0.7, lift=14),
    "nutmeg": dict(lean=0.2, head=0.3, arm_f=0.6, arm_b=-0.6, leg_f=1.05, leg_b=-0.3, lift=0),
    "burst": dict(lean=0.6, head=0.15, arm_f=1.2, arm_b=-1.1, leg_f=1.1, leg_b=-0.9, lift=22),
    "strike": dict(lean=-0.15, head=0.05, arm_f=-1.0, arm_b=1.0, leg_f=1.35, leg_b=-0.25, lift=6),
    "lunge": dict(lean=-0.45, head=-0.1, arm_f=-1.1, arm_b=0.4, leg_f=-0.8, leg_b=0.5, lift=0),
    "spread": dict(lean=0.0, head=0.2, arm_f=0.7, arm_b=-0.7, leg_f=0.55, leg_b=-0.55, lift=0),
    "turn": dict(lean=0.3, head=-0.4, arm_f=0.9, arm_b=-0.2, leg_f=0.4, leg_b=-0.5, lift=0),
}


def _lerp_pose(a, b, t):
    return {k: lerp(a[k], b[k], t) for k in a}


def _ease(t):
    t = clamp(t, 0.0, 1.0)
    return t * t * (3 - 2 * t)


class RenKit:
    """Everything Ren can do: abilities, the Awakening meter, effects, UI and cutscenes."""
    BUTTONS = (("Q", "shot"), ("E", "dribble"), ("R", "buff"), ("F", "awaken"))

    def __init__(self, game):
        self.g = game
        self.cut_img = {n: load_pixel("cut_%s" % n, (192, 192), fit=True, quiet=True)
                        for n in ("ren_open", "ren_closed", "ren_glow", "ren_glowgreen", "blue")}
        self.blue_look = {p: load_pixel("BLUEGUY_%s" % p, PIECE_SIZE[p][0], fit=PIECE_SIZE[p][1], quiet=True)
                          for p in ("head", "torso", "arm", "leg")}
        self._scaled = {}
        self.reset_match()

    # ------------------------------------------------------------ state
    def reset_match(self):
        self.meter = 0.0              # earned during the match
        self.awake = False
        self.energy = 0.0
        self.cd = {"shot": 0.0, "dribble": 0.0, "buff": 0.0, "dribble2": 0.0}
        self.buff = 0.0
        self.charge = None            # Perfect Shot / Perfect Finish wind-up
        self.mouse_charge = False
        self.dribble = None
        self.shot = None
        self.cutscene = None
        self.zoom = None              # (focus, strength, t, length)
        self.flash = 0.0
        self.flash_col = WHITE
        self.dark = 0.0
        self.trail = []
        self.after = []
        self.after_t = 0.0
        self.orbit = []
        self.popups = []
        self.preview = None
        self.beat_cd = 0.0
        self.chance_cd = 0.0
        self.side = None
        self.last_throw = -9.0
        self.was_grounded = True
        self.glow = None              # ("cyan"/"green", seconds)
        self.pulse = None
        self.muted = False
        self.apply_stats()

    def on_kickoff(self):
        self.charge = None
        self.mouse_charge = False
        self.dribble = None
        self.shot = None
        self.zoom = None
        self.trail = []
        self.preview = None
        self.side = None
        p = self.g.player
        p.ghost = False
        self.g.ball.ghost_t = 0.0
        self.g.ball.extra_g_t = 0.0
        if self.g.state != GOAL:
            self.g.slowmo = 1.0
        self.unmute()

    def active(self):
        card = getattr(self.g, "my_card", None)
        return card is not None and card.get("id") == REN_CARD and \
            getattr(self.g, "state", None) in (KICKOFF, PLAY, GOAL, FULLTIME)

    def can_act(self):
        return self.active() and self.g.state == PLAY and self.cutscene is None

    def mute(self):
        if not self.muted:
            try:
                pygame.mixer.music.pause()
            except Exception:
                pass
            self.muted = True

    def unmute(self):
        if self.muted:
            try:
                if not self.g.sfx.muted:
                    pygame.mixer.music.unpause()
            except Exception:
                pass
            self.muted = False

    # ------------------------------------------------------------ stats
    def apply_stats(self):
        p = self.g.player
        range_m = power_m = hit_m = 1.0
        control = aim = 0.0
        if self.active():
            if self.awake:
                fade = clamp(self.energy / 25.0, 0.35, 1.0)        # weaker as it runs out
                range_m, power_m, hit_m = 1 + 0.35 * fade, 1 + 0.3 * fade, 1 + 0.3 * fade
                control, aim = 0.7 * fade, 0.25 * fade
            elif self.buff > 0:
                range_m, power_m, hit_m, control, aim = 1.2, 1.15, 1.12, 0.4, 0.1
        p.range_mult, p.power_mult, p.hit_mult = range_m, power_m, hit_m
        p.control, p.aim_bonus = control, aim
        self.g.brain.slow = 1.6 if (self.active() and self.awake) else 1.0

    # ------------------------------------------------------------ meter
    def gain(self, key, amount=None, where=None):
        if self.awake or not self.active():
            return
        amt = REN_GAIN[key] if amount is None else amount
        before = self.meter
        self.meter = min(100.0, self.meter + amt)
        if amt >= 3 and where is not None:
            self.popup("+%d AWAKENING" % amt, where, CYAN)
        if before < 100 <= self.meter:
            self.popup("AWAKENING READY - PRESS F", self.g.player.pos + Vector2(0, -150), YELLOW, 2.2)
            self.g.sfx.play("buff", 0.8)

    def popup(self, text, pos, col, life=1.4):
        pos = Vector2(pos)
        near = sum(1 for p in self.popups if abs(p[1].x - pos.x) < 260 and abs(p[1].y - pos.y) < 90)
        pos.y -= 48 * near
        self.popups.append([text, pos, col, life, life])

    def on_goal(self, team):
        if not self.active():
            return
        if team == "home" and self.g.last_touch == "home":
            self.gain("goal", where=self.g.ball.pos)
            if self.shot is not None:
                self.gain("shot", where=self.g.ball.pos + Vector2(0, -60))

    def on_touch(self, strength, prev):
        if not self.active():
            return
        b = self.g.ball
        if prev == "away" and b.pos.x < WIDTH * 0.5:
            self.gain("intercept", where=b.pos)
        if strength > 1200 and b.vel.x > 600:
            self.gain("strike")
        if pygame.time.get_ticks() / 1000.0 - self.last_throw < 0.8:
            self.gain("move")
            self.last_throw = -9.0

    def on_throw(self):
        self.last_throw = pygame.time.get_ticks() / 1000.0

    # ------------------------------------------------------------ input
    def button_rects(self):
        return [pygame.Rect(WIDTH // 2 - 280 + i * 140, 938, 124, 108) for i in range(4)]

    def handle_event(self, event):
        if self.cutscene is not None:
            if event.type == pygame.MOUSEBUTTONDOWN or (event.type == pygame.KEYDOWN
                                                        and event.key == pygame.K_SPACE):
                self.cutscene["skip"] = True
            return event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.KEYDOWN)
        if not self.active():
            return False
        keys = {getattr(pygame, "K_q", -1): "Q", getattr(pygame, "K_e", -2): "E",
                getattr(pygame, "K_r", -3): "R", getattr(pygame, "K_f", -4): "F"}
        if event.type == pygame.KEYDOWN and event.key in keys:
            self.press(keys[event.key])
            return True
        if event.type == pygame.KEYUP and event.key in keys and keys[event.key] == "Q":
            self.release()
            return True
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for (k, _), r in zip(self.BUTTONS, self.button_rects()):
                if r.collidepoint(event.pos):
                    self.press(k)
                    self.mouse_charge = k == "Q"
                    return True
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.mouse_charge:
            self.mouse_charge = False
            self.release()
            return True
        return False

    def press(self, key):
        if not self.can_act():
            return
        p, b = self.g.player, self.g.ball
        near = p.pos.distance_to(b.pos) < 280
        if not self.awake:
            if key == "Q":
                if self.cd["shot"] > 0 or self.charge:
                    return
                if not near:
                    return self.popup("GET TO THE BALL", p.pos + Vector2(0, -120), WHITE, 0.9)
                self.charge = {"t": 0.0, "finish": False}
                self.glow = ("cyan", 1.5)
            elif key == "E":
                if self.cd["dribble"] <= 0:
                    self.start_dribble(False)
            elif key == "R":
                if self.cd["buff"] <= 0:
                    self.buff = REN_BUFF_TIME
                    self.cd["buff"] = REN_COOLDOWN["buff"]
                    self.glow = ("green", REN_BUFF_TIME)
                    self.apply_stats()
                    self.g.sfx.play("buff", 0.9)
                    self.popup("LOCKED IN", p.pos + Vector2(0, -130), REN_GREEN)
            elif key == "F":
                if self.meter >= 100:
                    self.start_cutscene("awaken")
        else:
            if key == "Q":
                if not near:
                    return self.popup("GET TO THE BALL", p.pos + Vector2(0, -120), WHITE, 0.9)
                if not self.charge:
                    self.charge = {"t": 0.0, "finish": True}
                    self.glow = ("cyan", 2.0)
                    self.mute()
            elif key == "E":
                if self.cd["dribble2"] <= 0 and self.energy >= REN_COST["dribble2"]:
                    if self.start_dribble(True):
                        self.energy -= REN_COST["dribble2"]
            elif key == "R":
                c = self.g.cpu
                if self.energy < REN_COST["ultimate"]:
                    return self.popup("NOT ENOUGH ENERGY", p.pos + Vector2(0, -120), WHITE, 0.9)
                if not near or p.pos.distance_to(c.pos) > 900:
                    return self.popup("BALL + DEFENDER NEEDED", p.pos + Vector2(0, -120), WHITE, 0.9)
                self.energy -= REN_COST["ultimate"]
                self.start_cutscene("untouchable")

    def release(self):
        ch = self.charge
        if not ch:
            return
        self.charge = None
        self.g.slowmo = 1.0
        if ch["finish"]:
            power = clamp(self.energy / 100.0, 0.05, 1.0)
            self.fire_shot(1.0, finish=power)
            self.energy = 0.0
            self.end_awakening(quiet=True)
        else:
            self.fire_shot(clamp(ch["t"] / 1.2, 0.0, 1.0))
            self.cd["shot"] = REN_COOLDOWN["shot"]
        self.unmute()

    # ------------------------------------------------------------ abilities
    def fire_shot(self, charge01, finish=None):
        """Rises, bends over the keeper and drops sharply into the far corner."""
        g, p, b = self.g, self.g.player, self.g.ball
        self.dribble = None                                    # a shot cancels any flick in progress
        p.ghost = False
        tx = WIDTH - GOAL_DEPTH - 12
        ty = g.crossbar_y + 64
        dist = Vector2(tx, ty).distance_to(b.pos)
        behind = p.pos.x < b.pos.x + 40                      # attacking the right goal
        quality = clamp(1.25 - dist / 1400.0, 0.25, 1.0) * (1.0 if behind else 0.55)
        if finish is not None:
            precision = 0.65 + 0.35 * finish
            quality = max(quality, 0.5 + 0.5 * finish)
        else:
            precision = (0.35 + 0.65 * charge01) * quality
        miss = (1.0 - precision)
        tx += random.uniform(-1, 1) * miss * 160
        ty += random.uniform(-1, 1) * miss * 150
        extra = BALL_GRAVITY * (0.7 if finish is None else 0.8 + 0.6 * finish)
        g_tot = BALL_GRAVITY + extra
        T = clamp(dist / 1700.0 + 0.35, 0.5, 1.2)
        if finish is not None:
            T *= 1.0 - 0.25 * finish                         # the finisher is violent
        for _ in range(8):
            vx = (tx - b.pos.x) / T
            vy = (ty - b.pos.y - 0.5 * g_tot * T * T) / T
            v = Vector2(vx, vy) * (1.0 + BALL_AIR_DRAG * T * 0.5)
            if v.length() < BALL_SPEED_CAP * 0.97:
                break
            T *= 1.12
        b.frozen = False
        b.vel = v
        b.spin = 0.0
        b.extra_g, b.extra_g_t = extra, T * 1.25
        b.home_ghost_t = 0.3                                   # it leaves his foot cleanly
        b.ghost_t = T * (0.55 if quality > 0.5 else 0.0) if finish is None else T * (0.9 if finish > 0.4 else 0.4)
        g.last_touch = "home"
        g.brain.think_timer = max(g.brain.think_timer, 0.55)     # the keeper reacts late
        pts, pos, vel = [], Vector2(b.pos), Vector2(v)
        for i in range(24):
            tt = T * i / 23.0
            pts.append(Vector2(b.pos.x + v.x * tt, b.pos.y + v.y * tt + 0.5 * g_tot * tt * tt))
        self.preview = [pts, 0.3]
        self.shot = {"t": 0.0, "T": T, "finish": finish}
        self.trail = []
        self.zoom = (Vector2(p.pos), 0.35 if finish is None else 0.6, 0.0, 0.5 if finish is None else 0.8)
        self.flash, self.flash_col = (0.35, CYAN) if finish is None else (0.8, WHITE)
        g.shake = min(SHAKE_CAP, g.shake + (3 if finish is None else 3 + 5 * finish))
        g.sfx.play("kick", 1.0)
        name = "PERFECT SHOT" if finish is None else "PERFECT FINISH %d%%" % int(finish * 100)
        self.popup(name, p.pos + Vector2(0, -150), CYAN if finish is None else WHITE, 1.6)

    def start_dribble(self, evolved):
        g, p, c, b = self.g, self.g.player, self.g.cpu, self.g.ball
        if p.pos.distance_to(b.pos) > 260:
            self.popup("GET TO THE BALL", p.pos + Vector2(0, -120), WHITE, 0.9)
            return False
        if not (c.pos.x > p.pos.x - 60 and abs(c.pos.x - p.pos.x) < 560):
            self.popup("NO DEFENDER IN FRONT", p.pos + Vector2(0, -120), WHITE, 0.9)
            return False
        land = Vector2(clamp(c.pos.x + (300 if evolved else 250), 300, WIDTH - GOAL_DEPTH - 90),
                       GROUND_Y - BALL_RADIUS - 40)
        # a high, soft flick: the apex clears a standing defender's head
        apex_y = GROUND_Y - (360 if not evolved else 300)
        up = math.sqrt(2 * BALL_GRAVITY * max(40.0, b.pos.y - apex_y))
        t_up = up / BALL_GRAVITY
        T = t_up + math.sqrt(2 * max(10.0, land.y - apex_y) / BALL_GRAVITY)
        b.frozen = False
        b.vel = Vector2((land.x - b.pos.x) / T, -up) * (1.0 + BALL_AIR_DRAG * T * 0.5)
        b.spin = 900.0
        b.extra_g_t = 0.0
        b.ghost_t = T * 0.6 if evolved else 0.0             # the evolved flick is much harder to read
        b.home_ghost_t = T * 0.7                             # his own dash doesn't knock it on
        # Ren bursts through the space underneath and arrives just before the ball
        Tr = min(T * 0.8, 0.55)
        rt = Vector2(land.x - 40, GROUND_Y - TORSO_H / 2 - 30)
        p.vel = Vector2((rt.x - p.pos.x) / Tr, (rt.y - p.pos.y - 0.5 * PLAYER_GRAVITY * Tr * Tr) / Tr)
        p.grounded = False
        p.throw_timer = 0.25
        p.ghost = True
        g.last_touch = "home"
        g.brain.think_timer = max(g.brain.think_timer, 0.7)     # turns around too late
        self.dribble = {"t": 0.0, "gt": 0.0, "T": T, "evolved": evolved, "passed": False, "ok": False,
                        "start_side": 1 if p.pos.x < c.pos.x else -1}
        self.cd["dribble"] = REN_COOLDOWN["dribble"]
        self.cd["dribble2"] = 0.45
        self.trail = []
        self.zoom = (Vector2((p.pos + c.pos) * 0.5), 0.25 if not evolved else 0.4, 0.0, 0.9)
        g.sfx.play("whoosh", 0.9)
        self.popup("CELESTIAL DESTRUCTION" + (" II" if evolved else ""), p.pos + Vector2(0, -150), CYAN, 1.2)
        return True

    # ------------------------------------------------------------ awakening
    def start_awakening(self):
        self.awake = True
        self.energy = 100.0
        self.meter = 0.0
        self.glow = ("cyan", 9999)
        self.apply_stats()
        self.pulse = 0.0                                        # a massive pulse spreads across the pitch
        self.popup("ONE SHOT MATCH", self.g.player.pos + Vector2(0, -160), CYAN, 2.0)

    def end_awakening(self, quiet=False):
        self.awake = False
        self.energy = 0.0
        self.glow = None
        self.apply_stats()
        if not quiet:
            self.popup("AWAKENING OVER", self.g.player.pos + Vector2(0, -140), (180, 190, 210), 1.6)

    # ------------------------------------------------------------ per-frame update
    def update(self, dt):
        g = self.g
        for k in self.cd:
            self.cd[k] = max(0.0, self.cd[k] - dt)
        self.beat_cd = max(0.0, self.beat_cd - dt)
        self.chance_cd = max(0.0, self.chance_cd - dt)
        self.flash = max(0.0, self.flash - dt * 2.2)
        for pp in self.popups:
            pp[3] -= dt
            pp[1].y -= 40 * dt
        self.popups = [pp for pp in self.popups if pp[3] > 0]
        if self.preview:
            self.preview[1] -= dt
            if self.preview[1] <= 0:
                self.preview = None
        if not self.active():
            self.apply_stats()
            return
        p, c, b = g.player, g.cpu, g.ball
        if self.buff > 0:
            self.buff = max(0.0, self.buff - dt)
            if self.buff == 0 and self.glow and self.glow[0] == "green":
                self.glow = None
        if self.glow and self.glow[1] < 9000:
            self.glow = (self.glow[0], self.glow[1] - dt) if self.glow[1] - dt > 0 else None
        # wind-up for Perfect Shot / Perfect Finish: the world slows while you aim
        if self.charge:
            self.charge["t"] += dt
            g.slowmo = 0.12 if self.charge["finish"] else 0.3
            b.spin = 1400.0
            if self.charge["t"] > (0.8 if self.charge["finish"] else 2.0):
                self.release()
        # Celestial Destruction
        d = self.dribble
        if d:
            d["t"] += dt
            d["gt"] += dt * (0.35 if d["t"] < 0.35 else 1.0)    # game time (the flick starts in slow-mo)
            t = d["gt"]
            g.slowmo = 0.35 if d["t"] < 0.35 else 1.0
            self.dark = max(self.dark, 0.55)
            side = 1 if p.pos.x < c.pos.x else -1
            if not d["passed"] and side != d["start_side"]:
                d["passed"] = True
                self.flash, self.flash_col = 0.4, WHITE
                g.sfx.play("whoosh", 0.7)
            # the ball drops perfectly into his path
            if d["T"] * 0.6 < t < d["T"] + 0.8:
                feet = Vector2(p.pos.x + 34, GROUND_Y - BALL_RADIUS - 8)
                gap = feet - b.pos
                if gap.length() < 190 and g.last_touch == "home":
                    # the ball runs in its own slower time, so ask for more velocity to cover the gap
                    want = (gap * 7.0 + p.vel * 0.5) / BALL_TIME
                    b.vel = b.vel.lerp(want, 0.3) if hasattr(b.vel, "lerp") else b.vel * 0.7 + want * 0.3
                    if gap.length() < 90 and d["passed"] and not d["ok"]:
                        d["ok"] = True
                        self.gain("dribble", where=p.pos + Vector2(0, -90))
                        self.popup("DEFENDER DESTROYED", p.pos + Vector2(0, -170), CYAN, 1.4)
                        if d["evolved"]:
                            self.flash, self.flash_col = 0.6, CYAN
                            g.shake = SHAKE_CAP
                            g.particles.burst(Vector2(p.pos.x, GROUND_Y), 24, "spark", Vector2(0, -1), 1.4,
                                              700, CYAN)
            if t > d["T"] + 0.9:
                p.ghost = False
                self.dribble = None
                g.slowmo = 1.0
        # the shot in flight
        if self.shot:
            self.shot["t"] += dt
            if self.shot["t"] > self.shot["T"] + 1.2:
                self.shot = None
        # awakening
        if self.awake:
            self.energy = max(0.0, self.energy - REN_DRAIN * dt)
            if self.energy <= 0 and not self.charge:
                self.end_awakening()
        target_dark = 0.45 * clamp(self.energy / 25.0, 0.3, 1.0) if self.awake else 0.0
        self.dark = approach(self.dark, target_dark if not self.dribble else self.dark, 1.8, dt)
        # beating the defender with the ball, creating a big chance
        if g.state == PLAY:
            side = 1 if p.pos.x < c.pos.x else -1
            if self.side is not None and side != self.side and side < 0 and \
                    p.pos.distance_to(b.pos) < 220 and self.beat_cd <= 0:
                self.gain("beat", where=p.pos + Vector2(0, -90))
                self.beat_cd = 2.5
            self.side = side
            if g.last_touch == "home" and b.vel.length() > 900 and b.pos.x > WIDTH - GOAL_DEPTH - 520 \
                    and self.chance_cd <= 0:
                self.gain("chance", where=b.pos + Vector2(0, -70))
                self.chance_cd = 4.0
        # afterimages, trails, footsteps
        self.after_t += dt
        fast = p.vel.length() > 900
        if (self.awake or getattr(p, "ghost", False) or (self.buff > 0 and fast)) and self.after_t > 0.035:
            self.after_t = 0.0
            self.after.append([Vector2(p.pos), p.angle, 0.35])
        for a in self.after:
            a[2] -= dt
        self.after = [a for a in self.after if a[2] > 0][-14:]
        if self.shot or self.dribble or (self.awake and b.vel.length() > 700):
            self.trail.append(Vector2(b.pos))
            self.trail = self.trail[-26:]
        elif self.trail:
            self.trail.pop(0)
        if self.awake and p.grounded and not self.was_grounded:
            g.particles.burst(Vector2(p.pos.x, GROUND_Y), 14, "spark", Vector2(0, -1), 1.5, 420, CYAN)
        self.was_grounded = p.grounded
        if self.buff > 0 or self.awake:
            if random.random() < 0.5:
                ang = random.uniform(0, math.tau)
                self.orbit.append([ang, random.uniform(50, 80), 0.6, REN_GREEN if not self.awake else CYAN])
        for o in self.orbit:
            o[0] += dt * 3.0
            o[2] -= dt
        self.orbit = [o for o in self.orbit if o[2] > 0][-40:]
        if self.zoom:
            f, s, t, ln = self.zoom
            self.zoom = (f, s, t + dt, ln) if t + dt < ln else None
        if self.pulse is not None:
            self.pulse = self.pulse + dt if self.pulse + dt < 1.0 else None
        self.apply_stats()

    # ------------------------------------------------------------ in-match drawing
    def draw_under(self, w):
        """Darken the pitch (Ren and the ball stay bright) + afterimages."""
        if not self.active():
            return
        if self.dark > 0.02:
            wash(w, (4, 8, 20, int(170 * self.dark)))
        if self.after:
            layer = scratch((WIDTH, HEIGHT), 2)
            for pos, ang, life in self.after:
                a = int(150 * life / 0.35)
                col = (CYAN if self.awake or self.dribble else REN_GREEN) + (a,)
                top = pos + rot((0, -TORSO_H / 2 - HEAD_R), ang)
                bot = pos + rot((0, TORSO_H / 2), ang)
                pygame.draw.line(layer, col, top, bot, int(TORSO_W * 0.9))
                pygame.draw.circle(layer, col, (int(top.x), int(top.y)), HEAD_R)
            w.blit(layer, (0, 0))

    def draw_player(self, w):
        p = self.g.player
        if self.active() and getattr(p, "ghost", False):
            layer = scratch((WIDTH, HEIGHT), 3)
            p.draw(layer, self.g.debug)
            layer.set_alpha(95)                                # almost transparent mid-dribble
            w.blit(layer, (0, 0))
        else:
            p.draw(w, self.g.debug)

    def draw_over_player(self, w):
        if not self.active():
            return
        p = self.g.player
        f = p.frame()
        hp, ha = f["head"], f["head_a"]
        if self.awake or self.buff > 0:                        # aura
            fade = clamp(self.energy / 25.0, 0.25, 1.0) if self.awake else 0.6
            aura = pygame.Surface((260, 320), pygame.SRCALPHA)
            col = CYAN if self.awake else REN_GREEN
            pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() * 0.012)
            for k in range(4):
                pygame.draw.ellipse(aura, col + (int((22 + 10 * pulse) * fade),),
                                    pygame.Rect(k * 18, k * 22, 260 - k * 36, 320 - k * 44))
            w.blit(aura, aura.get_rect(center=(int(p.pos.x), int(p.pos.y - 20))))
        if self.pulse is not None:
            k = self.pulse
            for ring in range(3):
                rad = int((k * 1.3 - ring * 0.12) * 2200)
                if rad > 10:
                    pygame.draw.ellipse(w, CYAN, pygame.Rect(int(p.pos.x) - rad, int(p.pos.y) - rad // 3,
                                                             rad * 2, rad * 2 // 3), max(2, int(10 * (1 - k))))
        for ang, r, life, col in self.orbit:
            q = p.pos + Vector2(math.cos(ang) * r, math.sin(ang) * r * 1.3 - 10)
            pygame.draw.rect(w, col, (int(q.x), int(q.y), 5, 5))
        glow = self.glow
        if glow:
            col = CYAN if glow[0] == "cyan" else REN_GREEN
            strength = clamp(self.energy / 25.0, 0.2, 1.0) if (self.awake and glow[0] == "cyan") else 1.0
            for sx in (-9, 9):
                e = hp + rot((sx, 2), ha)
                bloom = pygame.Surface((40, 24), pygame.SRCALPHA)
                pygame.draw.ellipse(bloom, col + (int(110 * strength),), bloom.get_rect())
                w.blit(bloom, (int(e.x - 20), int(e.y - 12)))
                pygame.draw.rect(w, (230, 255, 255), (int(e.x - 3), int(e.y - 2), 7, 4))

    def draw_ball_fx(self, w):
        if not self.active():
            return
        b = self.g.ball
        if len(self.trail) > 1:
            n = len(self.trail)
            for i in range(1, n):
                t = i / n
                col = (int(lerp(20, CYAN[0], t)), int(lerp(40, CYAN[1], t)), int(lerp(60, CYAN[2], t)))
                pygame.draw.line(w, col, self.trail[i - 1], self.trail[i], max(1, int(1 + 5 * t)))
        if self.preview:
            pts, life = self.preview
            for i in range(0, len(pts) - 1, 2):
                pygame.draw.line(w, (200, 250, 255), pts[i], pts[i + 1], 3)
        if self.charge:                                        # the ball spinning at his foot
            t = pygame.time.get_ticks() * 0.02
            for k in range(3):
                a0 = t + k * math.tau / 3
                pygame.draw.arc(w, CYAN, pygame.Rect(int(b.pos.x - 46), int(b.pos.y - 46), 92, 92),
                                a0, a0 + 1.2, 4)
            if not self.charge["finish"]:
                k = clamp(self.charge["t"] / 1.2, 0, 1)
                bar = pygame.Rect(int(b.pos.x - 60), int(b.pos.y - 80), 120, 12)
                pygame.draw.rect(w, (10, 20, 30), bar)
                pygame.draw.rect(w, CYAN, (bar.x, bar.y, int(bar.w * k), bar.h))
                pygame.draw.rect(w, WHITE, bar, 2)

    def apply_camera(self, w):
        z = 0.0
        focus = None
        if self.zoom:
            f, s, t, ln = self.zoom
            z = s * math.sin(math.pi * clamp(t / ln, 0, 1))
            focus = f
        if self.charge and self.charge["finish"]:
            z = max(z, 0.55)
            focus = self.g.player.pos
        if z > 0.01 and focus is not None:
            k = 1.0 + z
            cw, ch = int(WIDTH / k), int(HEIGHT / k)
            cx = clamp(int(focus.x) - cw // 2, 0, WIDTH - cw)
            cy = clamp(int(focus.y) - ch // 2, 0, HEIGHT - ch)
            part = w.subsurface(pygame.Rect(cx, cy, cw, ch)).copy()
            w.blit(pygame.transform.scale(part, (WIDTH, HEIGHT)), (0, 0))
        if self.flash > 0:
            wash(w, self.flash_col + (int(200 * clamp(self.flash, 0, 1)),))
        if self.active() and self.buff > 0 and not self.awake:
            wash(w, (40, 255, 120, 22))

    def draw_ui(self, w):
        if not self.active():
            return
        mouse = pygame.mouse.get_pos()
        for text, pos, col, life, total in self.popups:
            img = self.g.fit_text(text, self.g.font_m, col, 700, 44).copy()
            img.set_alpha(int(255 * clamp(life / total * 2, 0, 1)))
            w.blit(img, img.get_rect(center=(int(pos.x), int(pos.y))))
        # meter / energy
        bar = pygame.Rect(70, 986, 560, 34)
        if self.awake:
            label = "ONE SHOT MATCH" if self.energy >= 25 else "AWAKENING FADING - PERFECT FINISH (Q)"
            val, col = self.energy / 100.0, CYAN
        else:
            label = "AWAKENING" if self.meter < 100 else "AWAKENING READY - PRESS F"
            val, col = self.meter / 100.0, (120, 220, 255) if self.meter < 100 else YELLOW
        lab = self.g.fit_text(label, self.g.font_s, WHITE if self.meter < 100 or self.awake else YELLOW, 560, 30)
        w.blit(lab, (bar.x, bar.y - 36))
        pygame.draw.rect(w, (10, 14, 24), bar, border_radius=8)
        pygame.draw.rect(w, col, (bar.x, bar.y, int(bar.w * val), bar.h), border_radius=8)
        if self.meter >= 100 and not self.awake:
            pulse = int(80 + 80 * math.sin(pygame.time.get_ticks() * 0.01))
            glow = pygame.Surface((bar.w + 20, bar.h + 20), pygame.SRCALPHA)
            glow.fill((255, 230, 120, pulse))
            w.blit(glow, (bar.x - 10, bar.y - 10))
        for k in range(1, 4):
            x = bar.x + bar.w * k // 4
            pygame.draw.line(w, (40, 50, 70), (x, bar.y + 4), (x, bar.bottom - 4), 2)
        pygame.draw.rect(w, WHITE, bar, 3, border_radius=8)
        # the four buttons
        if self.awake:
            names = ("PERFECT FINISH", "CELESTIAL II", "UNTOUCHABLE", "ONE SHOT MATCH")
            costs = ("ALL", "%d" % REN_COST["dribble2"], "%d" % REN_COST["ultimate"], "")
        else:
            names = ("PERFECT SHOT", "CELESTIAL DESTR.", "LOCKED IN", "AWAKENING")
            costs = ("", "", "", "")
        cds = (self.cd["shot"], self.cd["dribble"], self.cd["buff"], 0.0) if not self.awake else \
            (0.0, self.cd["dribble2"], 0.0, 0.0)
        for i, ((key, _), r) in enumerate(zip(self.BUTTONS, self.button_rects())):
            ready = cds[i] <= 0
            if i == 3:
                ready = self.meter >= 100 or self.awake
            if self.awake and i == 1:
                ready = ready and self.energy >= REN_COST["dribble2"]
            if self.awake and i == 2:
                ready = self.energy >= REN_COST["ultimate"]
            hover = r.collidepoint(mouse)
            base = (16, 22, 40) if not self.awake else (10, 30, 44)
            pygame.draw.rect(w, base, r, border_radius=16)
            self.draw_icon(w, i, r, ready)
            if not ready and cds[i] > 0:                     # cooldown sweep
                total = REN_COOLDOWN.get(("shot", "dribble", "buff", "")[i], 1.0) if not self.awake else 0.45
                frac = clamp(cds[i] / total, 0, 1)
                veil = pygame.Surface(r.size, pygame.SRCALPHA)
                c0 = (r.w / 2, r.h / 2)
                pts = [c0] + [(c0[0] + math.cos(-math.pi / 2 + a * 0.1) * 120,
                               c0[1] + math.sin(-math.pi / 2 + a * 0.1) * 120)
                              for a in range(int(frac * 63) + 1)]
                if len(pts) > 2:
                    pygame.draw.polygon(veil, (0, 0, 0, 160), pts)
                w.blit(veil, r.topleft)
                sec = self.g.fit_text("%d" % math.ceil(cds[i]), self.g.font_m, WHITE, 60, 40)
                w.blit(sec, sec.get_rect(center=r.center))
            if self.charge and i == 0:
                k = clamp(self.charge["t"] / (0.8 if self.charge["finish"] else 1.2), 0, 1)
                pygame.draw.rect(w, CYAN, (r.x + 6, r.bottom - 12, int((r.w - 12) * k), 6))
            border = YELLOW if hover and ready else (CYAN if ready else (70, 80, 100))
            pygame.draw.rect(w, border, r, 4, border_radius=16)
            kimg = self.g.fit_text(key, self.g.font_s, WHITE, 30, 26)
            w.blit(kimg, (r.x + 8, r.y + 6))
            if costs[i]:
                cimg = self.g.fit_text(costs[i], self.g.font_s, CYAN, 50, 22)
                w.blit(cimg, cimg.get_rect(topright=(r.right - 8, r.y + 8)))
            nimg = self.g.fit_text(names[i], self.g.font_s, WHITE if ready else (130, 140, 160), r.w + 10, 20)
            w.blit(nimg, nimg.get_rect(midtop=(r.centerx, r.bottom + 2)))
        if self.buff > 0 and not self.awake:
            t = self.g.fit_text("LOCKED IN  %.1fs" % self.buff, self.g.font_s, REN_GREEN, 300, 30)
            w.blit(t, (WIDTH // 2 + 300, 1000))

    def draw_icon(self, w, i, r, ready):
        c = CYAN if ready else (80, 100, 120)
        cx, cy = r.center
        cy -= 4
        if i == 0:                                             # curved shot
            pts = [(cx - 34 + k * 7, cy + 14 - int(28 * math.sin(k / 9.0 * math.pi)) + (k > 6) * (k - 6) * 6)
                   for k in range(10)]
            pygame.draw.lines(w, c, False, pts, 4)
            pygame.draw.circle(w, WHITE if ready else c, pts[-1], 8)
        elif i == 1:                                           # flick over a defender
            pygame.draw.rect(w, (60, 90, 200) if ready else c, (cx - 6, cy - 6, 14, 34))
            pygame.draw.arc(w, c, pygame.Rect(cx - 36, cy - 34, 72, 60), 0.2, 2.9, 4)
            pygame.draw.circle(w, WHITE if ready else c, (cx + 30, cy + 10), 7)
        elif i == 2:                                           # eye (buff / ultimate)
            col = REN_GREEN if (ready and not self.awake) else c
            pygame.draw.ellipse(w, col, (cx - 34, cy - 16, 68, 32), 4)
            pygame.draw.circle(w, col, (cx, cy), 10)
        else:                                                  # awakening star
            col = YELLOW if (ready and not self.awake) else c
            pts = []
            for k in range(10):
                a = -math.pi / 2 + k * math.pi / 5
                rr = 30 if k % 2 == 0 else 13
                pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
            pygame.draw.polygon(w, col, pts, 0 if ready else 3)

    # ------------------------------------------------------------ cutscenes
    def start_cutscene(self, kind):
        g = self.g
        self.cutscene = {"kind": kind, "t": 0.0, "snap": g.world.copy(), "skip": False, "done": False,
                         "shatter": [], "applied": False}
        self.charge = None
        self.dribble = None
        g.player.ghost = False
        g.slowmo = 1.0
        g.dragging = False
        self.mute()
        g.sfx.play("shock", 0.9)

    def update_cutscene(self, dt):
        cs = self.cutscene
        length = AWAKEN_LEN if cs["kind"] == "awaken" else ULTI_LEN
        prev = cs["t"]
        cs["t"] += dt
        if cs["skip"]:
            cs["t"] = max(cs["t"], length - 0.6)
            cs["skip"] = False
        t = cs["t"]

        def crossed(m):
            return prev < m <= t
        snd = self.g.sfx
        if cs["kind"] == "awaken":
            for m in (3.9, 9.0):
                if crossed(m):
                    snd.play("shock", 1.0)
            for m in (4.6, 6.2, 7.6):
                if crossed(m):
                    snd.play("whoosh", 0.5)
            if crossed(9.0):
                self._make_shards(cs)
        else:
            for m in (1.8, 2.1, 2.35, 2.6, 2.85):
                if crossed(m):
                    snd.play("whoosh", 0.6)
            for k in range(6):
                if crossed(3.1 + k * 0.55):
                    snd.play("shock" if k == 5 else "whoosh", 0.9 if k == 5 else 0.6)
            if t >= 6.9 and not cs["applied"]:
                self._apply_untouchable()
                cs["applied"] = True
        for s in cs["shatter"]:
            s[0] += s[1] * dt
            s[1].y += 900 * dt
            s[2] += s[3] * dt
        if t >= length:
            if cs["kind"] == "awaken":
                self.start_awakening()
            elif not cs["applied"]:
                self._apply_untouchable()
            self.cutscene = None
            self.unmute()
            self.flash, self.flash_col = 0.5, CYAN

    def _make_shards(self, cs):
        bar = pygame.Rect(WIDTH // 2 - 420, HEIGHT // 2 - 30, 840, 60)
        for _ in range(46):
            x = random.uniform(bar.x, bar.right)
            y = random.uniform(bar.y, bar.bottom)
            v = Vector2(x - WIDTH / 2, y - HEIGHT / 2)
            v = v.normalize() * random.uniform(500, 1400) if v.length() > 1 else Vector2(0, -900)
            cs["shatter"].append([Vector2(x, y), v, random.uniform(0, 6), random.uniform(-9, 9),
                                  random.uniform(10, 34)])

    def _apply_untouchable(self):
        """After the cutscene: Ren is past the defender with the ball into space."""
        g, p, c, b = self.g, self.g.player, self.g.cpu, self.g.ball
        x = clamp(max(c.pos.x, p.pos.x) + 220, 260, WIDTH - GOAL_DEPTH - 200)
        p.reset_to(x)
        p.vel = Vector2(300, -200)
        p.grounded = False
        b.frozen = False
        b.pos.update(x + 110, GROUND_Y - BALL_RADIUS - 10)
        b.vel.update(420, -160)
        b.ghost_t = 0.4
        c.vel = Vector2(-500, -300)
        c.av = -6.0
        c.grounded = False
        g.brain.think_timer = max(g.brain.think_timer, 1.3)
        g.last_touch = "home"
        self.flash, self.flash_col = 0.9, CYAN
        self.popup("UNTOUCHABLE", p.pos + Vector2(0, -170), CYAN, 1.8)
        g.particles.burst(Vector2(x, GROUND_Y - 60), 40, "spark", None, 1.0, 900, CYAN)

    # ---- cutscene drawing helpers
    def _scaled_img(self, name, size):
        size = int(size) // 8 * 8                               # fewer sizes -> the cache stays small
        key = (name, size)
        if key not in self._scaled:
            if len(self._scaled) > 80:
                self._scaled.clear()
            img = self.cut_img.get(name)
            self._scaled[key] = pygame.transform.scale(img, (size, size)) if img is not None else None
        return self._scaled[key]

    def _letterbox(self, w, k=1.0):
        h = int(110 * k)
        pygame.draw.rect(w, (0, 0, 0), (0, 0, WIDTH, h))
        pygame.draw.rect(w, (0, 0, 0), (0, HEIGHT - h, WIDTH, h))

    def _subtitle(self, w, text, t_in):
        n = int(len(text) * clamp(t_in / 0.7, 0, 1))          # typed on
        img = self.g.outlined(text[:max(1, n)], self.g.font_m, WHITE, 0.9, (0, 0, 0), 4)
        w.blit(img, img.get_rect(center=(WIDTH // 2, HEIGHT - 175)))

    def _closeup(self, w, name, size, centre, dark=0.0, tint=None):
        img = self._scaled_img(name, size)
        if img is None:
            return
        w.blit(img, img.get_rect(center=centre))
        if tint or dark:
            wash(w, (tint or (0, 0, 0)) + (int(255 * dark),))

    def _eye_band(self, w, name, size, centre, alpha=255):
        """Only the eyes of a close-up, on black (rows 24-33 of the 64 px portrait)."""
        img = self._scaled_img(name, size)
        if img is None:
            return
        top, bot = int(size * 24 / 64), int(size * 33 / 64)
        x0, x1 = int(size * 18 / 64), int(size * 46 / 64)
        band = img.subsurface(pygame.Rect(x0, top, x1 - x0, bot - top)).copy()
        band.set_alpha(alpha)
        r = band.get_rect(center=centre)
        w.blit(band, r)

    def _motes(self, w, t, col, n=40, rise=60, seed=3):
        rnd = random.Random(seed)
        for _ in range(n):
            x = rnd.uniform(0, WIDTH)
            y = (rnd.uniform(0, HEIGHT) - t * rise * rnd.uniform(0.5, 1.5)) % HEIGHT
            s = rnd.choice((3, 4, 6))
            pygame.draw.rect(w, col, (int(x), int(y), s, s))

    def _vignette(self, w, strength=200):
        v = scratch((WIDTH, HEIGHT), 5)
        for k in range(8):
            a = int(strength * (k + 1) / 8 / 8)
            pygame.draw.rect(v, (0, 0, 0, a), (0, 0, WIDTH, HEIGHT), 60 + k * 40)
        w.blit(v, (0, 0))

    def draw_cutscene(self, w):
        cs = self.cutscene
        t = int(cs["t"] * CUT_FPS) / float(CUT_FPS)             # 30 fps stepping
        if cs["kind"] == "awaken":
            self._draw_awaken(w, t, cs)
        else:
            self._draw_untouchable(w, t, cs)

    def _draw_awaken(self, w, t, cs):
        snap = cs["snap"]
        p = self.g.player
        CX, CY = WIDTH // 2, HEIGHT // 2
        if t < 1.8:
            # 1) the match freezes, sound dies, the camera creeps toward Ren
            z = 1.0 + 1.6 * _ease((t - 0.4) / 1.4) if t > 0.4 else 1.0
            cw, ch = int(WIDTH / z), int(HEIGHT / z)
            cx = clamp(int(p.pos.x) - cw // 2, 0, WIDTH - cw)
            cy = clamp(int(p.pos.y) - ch // 2, 0, HEIGHT - ch)
            part = snap.subsurface(pygame.Rect(cx, cy, cw, ch)).copy()
            w.blit(pygame.transform.scale(part, (WIDTH, HEIGHT)), (0, 0))
            wash(w, (10, 14, 30, int(150 * clamp(t / 0.4, 0, 1))))
            if t < 0.12:
                wash(w, (255, 255, 255, 180))
            self._letterbox(w, clamp(t / 0.6, 0, 1))
            return
        if t < 4.1:
            # 2) close-up: head lowered, eyes shut ... then they slowly open
            w.fill((6, 8, 16))
            drift = int((t - 1.8) * 30)
            down = int(170 * (1 - _ease((t - 3.3) / 0.8))) if t > 3.3 else 170
            name = "ren_closed" if t < 3.3 else "ren_open"
            self._motes(w, t, (40, 60, 90), 50, 30)
            grow = int((t - 1.8) * 40)
            size = (1240 + grow) // 8 * 8
            self._closeup(w, name, size, (CX, CY + down + 170 - drift // 3))
            if 3.3 <= t < 4.1:                                  # lids lifting
                lid = 1 - _ease((t - 3.3) / 0.8)
                top = CY + down + 170 - drift // 3 - size // 2
                ey0, ey1 = top + int(size * 26 / 64), top + int(size * 31 / 64)
                skin = (228, 184, 150)
                left = CX - size // 2
                for ex in (20, 36):
                    pygame.draw.rect(w, skin, (left + int(size * ex / 64), ey0, int(size * 9 / 64) + 1,
                                               int((ey1 - ey0) * lid) + 2))
            self._vignette(w, 255)
            self._letterbox(w)
            return
        if t < 4.6:
            # 3) everything goes dark
            w.fill((0, 0, 0))
            k = 1 - (t - 4.1) / 0.5
            self._eye_band(w, "ren_open", 980, (CX, CY), int(255 * max(0, k)))
            self._letterbox(w)
            return
        if t < 6.2:
            # 4) black - only the glowing eyes. First line.
            w.fill((0, 0, 0))
            pulse = 0.85 + 0.15 * math.sin(t * 9)
            bloom = pygame.Surface((1200, 300), pygame.SRCALPHA)
            pygame.draw.ellipse(bloom, CYAN + (int(40 * pulse),), bloom.get_rect())
            w.blit(bloom, bloom.get_rect(center=(CX, CY)))
            for sx in (-1, 1):                                  # light streaking off each eye
                y = CY + 4
                for k in range(6):
                    ln = int(260 + k * 60 + 40 * math.sin(t * 7 + k))
                    col = (int(CYAN[0] * (1 - k / 7)), int(CYAN[1] * (1 - k / 7)), int(CYAN[2] * (1 - k / 7)))
                    x0 = CX + sx * 300
                    pygame.draw.line(w, col, (x0, y - 3 + k), (x0 + sx * ln, y - 3 + k * 2), 3)
            self._eye_band(w, "ren_glow", 1100, (CX, CY))
            self._letterbox(w)
            self._subtitle(w, REN_LINES[0], t - 4.6)
            return
        if t < 7.6:
            # 5) cut to the opponents. Second line.
            w.fill((8, 12, 30))
            sway = int(math.sin(t * 2) * 12)
            self._closeup(w, "blue", 1100, (CX - 400 + sway, CY + 200), 0.35, (0, 10, 30))
            self._closeup(w, "blue", 760, (CX + 500 - sway, CY + 260), 0.0)
            wash(w, (0, 20, 40, 120))
            self._vignette(w, 255)
            self._letterbox(w)
            self._subtitle(w, REN_LINES[1], t - 6.2)
            return
        if t < 9.0:
            # 6) Ren looks forward, eyes lit. Third line.
            w.fill((4, 6, 14))
            for k in range(26):                                 # speed lines
                a = k * math.tau / 26 + t * 0.4
                pygame.draw.line(w, (20, 60, 90), (CX + math.cos(a) * 420, CY + math.sin(a) * 420),
                                 (CX + math.cos(a) * 1400, CY + math.sin(a) * 1400), 5)
            push = int(_ease((t - 7.6) / 1.4) * 120)
            self._motes(w, t, CYAN, 60, 160, 9)
            self._closeup(w, "ren_glow", 1320 + push, (CX, CY + 200))
            self._vignette(w, 220)
            self._letterbox(w)
            self._subtitle(w, REN_LINES[2], t - 7.6)
            return
        if t < 9.8:
            # 7) the Awakening meter shatters into particles
            w.fill((0, 0, 0))
            if t < 9.3:
                bar = pygame.Rect(CX - 420, CY - 30, 840, 60)
                pygame.draw.rect(w, YELLOW, bar, border_radius=10)
                pygame.draw.rect(w, WHITE, bar, 5, border_radius=10)
                lab = self.g.fit_text("AWAKENING", self.g.font_m, (40, 30, 0), 400, 44)
                w.blit(lab, lab.get_rect(center=bar.center))
                rnd = random.Random(7)
                for _ in range(int((t - 9.0) / 0.3 * 12)):       # cracks
                    x = rnd.uniform(bar.x, bar.right)
                    pygame.draw.lines(w, (20, 20, 20), False,
                                      [(x, bar.y), (x + rnd.uniform(-30, 30), bar.centery),
                                       (x + rnd.uniform(-40, 40), bar.bottom)], 3)
            for pos, vel, ang, spin, size in cs["shatter"]:
                pts = [(pos.x + math.cos(ang + k * 2.1) * size, pos.y + math.sin(ang + k * 2.1) * size * 0.7)
                       for k in range(3)]
                pygame.draw.polygon(w, YELLOW if size > 20 else CYAN, pts)
            self._letterbox(w)
            return
        # 8) eyes flare, the stadium comes back
        k = clamp((t - 9.8) / 0.6, 0, 1)
        w.blit(snap, (0, 0))
        wash(w, CYAN + (int(230 * (1 - k)),))
        if k < 0.5:
            self._eye_band(w, "ren_glow", 1300, (CX, CY), int(255 * (1 - k * 2)))
        self._letterbox(w, 1 - k)

    # ---- puppets for the side-on "Untouchable" cutscene
    def _piece(self, look, name, scale, flip):
        key = (id(look), name, scale, flip)
        if key not in self._scaled:
            if len(self._scaled) > 80:
                self._scaled.clear()
            img = look.get(name)
            if img is None:
                self._scaled[key] = None
            else:
                img = pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
                self._scaled[key] = pygame.transform.flip(img, True, False) if flip else img
        return self._scaled[key]

    def draw_puppet(self, w, look, x, ground, scale, facing, pose, alpha=255, eyes=None):
        layer = w if alpha >= 255 else scratch((WIDTH, HEIGHT), 4)
        flip = facing < 0
        lean = pose["lean"] * facing
        centre = Vector2(x, ground - (FOOT_OFFSET + 4) * scale - pose["lift"])

        def world(local):
            return centre + rot(Vector2(local[0] * facing, local[1]) * scale, lean)
        parts = []
        for side, key in ((-1, "leg_b"), (1, "leg_f")):
            ang = lean + pose[key] * facing * -1
            piv = world((side * HIP_X, HIP_Y))
            parts.append(("leg", piv + rot((0, LEG_L * scale / 2), ang), ang))
        for side, key in ((-1, "arm_b"), (1, "arm_f")):
            ang = lean + pose[key] * facing * -1
            piv = world((side * SHOULDER_X, SHOULDER_Y))
            parts.append(("arm", piv + rot((0, ARM_L * scale / 2), ang), ang))
        for name, c, ang in parts:
            img = self._piece(look, name, scale, flip)
            if img is not None:
                blit_rot(layer, img, c, ang)
        img = self._piece(look, "torso", scale, flip)
        if img is not None:
            blit_rot(layer, img, centre, lean)
        head_a = lean + pose["head"] * facing
        neck = world((0, -TORSO_H / 2))
        hc = neck + rot((0, -(NECK_GAP + HEAD_R) * scale), head_a)
        img = self._piece(look, "head", scale, flip)
        if img is not None:
            blit_rot(layer, img, hc, head_a)
        if eyes:
            for sx in (4, 13):
                e = hc + rot((sx * facing * scale * 0.9, 1.5 * scale), head_a)
                bloom = pygame.Surface((int(22 * scale), int(12 * scale)), pygame.SRCALPHA)
                pygame.draw.ellipse(bloom, eyes + (120,), bloom.get_rect())
                layer.blit(bloom, bloom.get_rect(center=(int(e.x), int(e.y))))
                pygame.draw.rect(layer, (235, 255, 255), (int(e.x - 2 * scale), int(e.y - scale), int(4 * scale),
                                                          int(2 * scale)))
        if layer is not w:
            layer.set_alpha(alpha)
            w.blit(layer, (0, 0))
        return centre

    def _draw_untouchable(self, w, t, cs):
        g = self.g
        ren_look = g.sig_looks.get(REN_CARD, {})
        blue = self.blue_look
        CX, CY = WIDTH // 2, HEIGHT // 2
        ground, S = 870, 3.8

        def X(v):                                               # stage layout, spread for the bigger puppets
            return 560 + (v - 640) * 1.25
        if t < 0.4:
            w.blit(cs["snap"], (0, 0))
            wash(w, (0, 0, 0, int(255 * t / 0.4)))
            return
        # rapid cuts between the two of them
        if 2.1 <= t < 3.1:
            k = int((t - 2.1) / 0.25)
            w.fill((0, 0, 0))
            if k % 2 == 0:
                if k == 0:
                    self._closeup(w, "ren_glow", 1100, (CX, CY + 80))
                else:
                    self._eye_band(w, "ren_glow", 1500, (CX, CY))
            else:
                self._closeup(w, "blue", 1000 + k * 60, (CX + (k - 2) * 40, CY + 60), 0.25, (0, 10, 40))
                if k == 3:                                      # a bead of sweat
                    pygame.draw.ellipse(w, (190, 230, 255), (CX + 260, CY - 120, 26, 40))
            self._letterbox(w)
            return
        # the dark stage
        w.fill((6, 7, 12))
        glow = pygame.Surface((1600, 300), pygame.SRCALPHA)
        pygame.draw.ellipse(glow, (30, 50, 80, 70), glow.get_rect())
        w.blit(glow, glow.get_rect(center=(CX, ground)))
        pygame.draw.line(w, (40, 60, 90), (0, ground), (WIDTH, ground), 3)
        seq = t - 3.1
        move = int(seq / 0.55) if seq >= 0 else -1
        local = (seq - move * 0.55) / 0.55 if seq >= 0 else 0.0
        # defaults before the sequence
        rx, dx, bx = 640.0, 1500.0, 730.0
        rpose, dpose = PUPPET_POSES["down"], PUPPET_POSES["stand"]
        dface, eyes = -1, None
        by = ground - BALL_RADIUS * 2.2
        after = []
        if t < 2.1:
            walk = _ease((t - 0.4) / 1.2)
            dx = lerp(1700, 1150, walk)
            step = math.sin(t * 12) * 0.5 * (1 - walk * 0.8)
            dpose = dict(PUPPET_POSES["stand"], leg_f=step, leg_b=-step, arm_f=-step * 0.6, arm_b=step * 0.6)
            if t >= 1.6:                                        # Ren looks up, eyes lit
                rpose = _lerp_pose(PUPPET_POSES["down"], PUPPET_POSES["stand"], _ease((t - 1.6) / 0.3))
                eyes = CYAN
        else:
            eyes = CYAN
            dx = 1150.0
            # 0 touch, 1 feint, 2 cut, 3 nutmeg, 4 burst, 5 final touch
            if move <= 0:
                rpose = _lerp_pose(PUPPET_POSES["stand"], PUPPET_POSES["touch"], _ease(local * 2))
                rx, bx = 640 + 40 * local, 730 + 90 * _ease(local)
            elif move == 1:
                rpose = _lerp_pose(PUPPET_POSES["touch"], PUPPET_POSES["feint"], _ease(local * 1.6))
                dpose = _lerp_pose(PUPPET_POSES["stand"], PUPPET_POSES["lunge"], _ease(local * 1.4))
                rx, bx, dx = 680 - 20 * local, 820, 1150 - 70 * _ease(local)
            elif move == 2:
                rpose = _lerp_pose(PUPPET_POSES["feint"], PUPPET_POSES["cut"], _ease(local * 2))
                dpose = PUPPET_POSES["lunge"]
                rx, bx, dx = 660 + 160 * _ease(local), 820 + 120 * _ease(local), 1080
                after = [(660 + 160 * _ease(local) - k * 45, PUPPET_POSES["feint"]) for k in (1, 2)]
            elif move == 3:
                rpose = PUPPET_POSES["nutmeg"]
                dpose = _lerp_pose(PUPPET_POSES["lunge"], PUPPET_POSES["spread"], _ease(local * 2))
                rx, dx = 820, 1080
                bx = lerp(940, 1300, _ease(local))
                by = ground - BALL_RADIUS * 2.2
            elif move == 4:
                rpose = PUPPET_POSES["burst"]
                dpose = _lerp_pose(PUPPET_POSES["spread"], PUPPET_POSES["turn"], _ease(local))
                dface = -1 if local < 0.5 else 1
                rx, dx, bx = lerp(820, 1260, _ease(local)), 1080, 1300 + 40 * local
                after = [(rx - k * 90, PUPPET_POSES["burst"]) for k in (1, 2, 3)]
            else:
                rpose = _lerp_pose(PUPPET_POSES["burst"], PUPPET_POSES["strike"], _ease(local * 2.5))
                dpose, dface = PUPPET_POSES["turn"], 1
                rx, dx = 1260, 1080
                bx = lerp(1340, 1850, _ease(clamp((seq - 2.75) / 0.9, 0, 1)))
        # afterimages first (cyan ghosts)
        for ax, pose in after:
            self.draw_puppet(w, ren_look, X(ax), ground, S, 1, pose, alpha=70)
        self.draw_puppet(w, blue, X(dx), ground, S * 0.97, dface, dpose)
        self.draw_puppet(w, ren_look, X(rx), ground, S, 1, rpose, eyes=eyes)
        ball = pygame.transform.scale(g.ball.art, (int(BALL_RADIUS * 2.9), int(BALL_RADIUS * 2.9)))
        w.blit(ball, ball.get_rect(center=(int(X(bx)), int(ground - BALL_RADIUS * 1.45 - (ground - BALL_RADIUS * 2.2 - by)))))
        if 0 <= seq < 3.3:                                      # cyan flash + label on every move
            f = clamp(1 - local / 0.25, 0, 1)
            if f > 0:
                wash(w, CYAN + (int(110 * f),))
            names = ("TOUCH", "FEINT", "CUT", "NUTMEG", "BURST", "FINAL TOUCH")
            lab = self.g.outlined(names[min(move, 5)], self.g.font_l, CYAN, 0.8, (0, 0, 0), 5)
            w.blit(lab, lab.get_rect(center=(CX, 230)))
        # the final touch tears space
        if t >= 6.35:
            k = clamp((t - 6.35) / 0.8, 0, 1)
            frame = w.copy()
            amp = 34 * (1 - k)
            for y in range(0, HEIGHT, 24):
                off = int(math.sin(y * 0.03 + t * 30) * amp)
                w.blit(frame, (off, y), pygame.Rect(0, y, WIDTH, 24))
            for r in range(3):
                rad = int((k * 1.6 + r * 0.25) * 900)
                if rad > 0:
                    pygame.draw.ellipse(w, (200, 250, 255), pygame.Rect(int(X(1300)) - rad, ground - 60 - rad // 2,
                                                                         rad * 2, rad), 6)
        self._letterbox(w)
        if t >= 7.2:                                            # the stadium returns
            k = clamp((t - 7.2) / 0.6, 0, 1)
            live = pygame.Surface((WIDTH, HEIGHT))
            g.draw_match(live)
            live.set_alpha(int(255 * k))
            w.blit(live, (0, 0))


class Game:
    def __init__(self, headless=False):
        self.headless = headless
        self.screen = None
        if WEB_VIEW:
            try:    # small canvas (?small=1): the browser stretches it back up
                self.screen = pygame.display.set_mode((WIDTH // PIXEL, HEIGHT // PIXEL))
            except Exception:
                self.screen = None
        if self.screen is None:
            try:
                self.screen = pygame.display.set_mode(
                    (WIDTH, HEIGHT), pygame.SCALED | pygame.FULLSCREEN, vsync=1)
            except Exception:
                self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("A Small World Cup")
        self.world = pygame.Surface((WIDTH, HEIGHT)).convert()

        self.clock = pygame.time.Clock()
        self.pointer = (WIDTH // 2, HEIGHT // 2)   # where the mouse or last finger is, in game pixels
        self.touch_t = -99.0                       # when the last touch came in
        if TOUCH_OR_WEB:
            try:
                pygame.mouse.get_pos = lambda: self.pointer   # hover highlights follow touch too
            except Exception:
                pass                                          # hover just stays on the real mouse
        self.text_cache = {}                       # rendered text, kept between frames
        self.input_lock = 0.0                      # seconds before a fresh screen takes clicks
        self._screen_sig = None
        def font(size):
            raw = pygame.font.SysFont(None, size, bold=True)
            try:
                cached = CachedFont(raw)
                cached.render("test", True, (255, 255, 255))
                return cached
            except Exception:
                return raw                             # never lose the game over a cache
        self.font_s, self.font_m = font(42), font(64)
        self.font_l, self.font_xl = font(104), font(220)

        self.sfx = SFX()
        self.particles = Particles()
        self.crossbar_y = GROUND_Y - GOAL_HEIGHT
        cy = self.crossbar_y
        # goal roofs (crossbars). The rounded front end acts as the post.
        self.segments = [
            (Vector2(0, cy - ROOF_SLOPE), Vector2(GOAL_DEPTH, cy), CROSSBAR_THICK),
            (Vector2(WIDTH, cy - ROOF_SLOPE), Vector2(WIDTH - GOAL_DEPTH, cy), CROSSBAR_THICK),
        ]
        self.stadiums = [load_pixel("stadium_%d" % i, (WIDTH, GROUND_Y), quiet=True) for i in range(4)]
        self.stadiums = [s for s in self.stadiums if s is not None]
        self.stadium = 0
        self._bg_cache = {}
        self.background = self._build_background()
        self.shop_bg = load_pixel("shop_bg", (WIDTH, HEIGHT), quiet=True)

        self.ball = Ball()
        self.player = Player(WIDTH * 0.5 - 430, 1, HOME_KIT)
        self.cpu = Player(WIDTH * 0.5 + 430, -1, AWAY_KIT)
        self.brain = Brain(self.cpu, -1, DIFFICULTY[1][1], opponent=self.player)
        self.difficulty = 1
        # looks[code][piece] = [easy, medium, hard] sprites
        self.looks = {}
        cache = {}
        for code, spec in TEAM_LOOKS.items():
            self.looks[code] = {}
            for piece, names in spec.items():
                names = (names,) * 3 if isinstance(names, str) else tuple(names)
                size, fit = PIECE_SIZE[piece]
                imgs = []
                for n in names:
                    if (n, piece) not in cache:
                        cache[(n, piece)] = load_pixel(n, size, fit=fit)
                    imgs.append(cache[(n, piece)])
                self.looks[code][piece] = imgs
        self.sfx.start_music()

        self.debug = False
        self.paused = False
        self.accumulator = 0.0
        self.teams = load_teams()
        self.team = None           # index of the player's team
        self.opponents = []        # one opponent per round
        self.round = 0             # rounds won so far in this tournament
        self.results = []
        self.ren_pending = False   # his card walks out after the CHAMPIONS screen
        self.run_impossible = False # every round of this World Cup run played on IMPOSSIBLE
        self.roulette = None
        self.select_bg = self._build_select_bg()
        # clubs
        self.mode = "wc"
        self.clubs = []
        self.club_looks = {}
        for code, name, strength, players in CLUBS:
            badge = (load_pixel("%s_logo" % code, (96, 112), fit=True, quiet=True)
                     or load_pixel("%s_badge" % code, (96, 112), fit=True))
            self.clubs.append({"code": code, "name": name, "strength": strength, "badge": badge})
            self.club_looks[code] = {}
            for piece in ("head", "torso", "arm", "leg"):
                size, fit = PIECE_SIZE[piece]
                self.club_looks[code][piece] = [load_pixel("%s_%s_%s" % (code, p, piece), size, fit=fit)
                                                for p in players]
        self.match_pick = (0, 0)
        # cards, save file, custom team
        self.cards = {r[0]: dict(zip(("id", "name", "kind", "team", "slot", "tier", "rating", "pos",
                                      "number", "pack", "sho", "str", "design", "desc"), r))
                      for r in CARD_DB}
        if not REN_IN_GAME:
            self.cards.pop(REN_CARD, None)                   # retired, but still in the file
        for i, (slug, name, pos, ovr, price, nation, club, num, desc) in enumerate(STAR_SIGNINGS):
            sho, strength = star_stats(pos, ovr)
            cid = "STAR_" + slug
            self.cards[cid] = {"id": cid, "name": name, "kind": "star", "team": club, "slot": 0, "tier": "good",
                               "rating": ovr, "pos": pos, "number": num, "pack": None, "sho": sho,
                               "str": strength, "design": "starsign", "desc": desc, "nation": nation,
                               "price": price, "order": i}
        self.star_ids = ["STAR_" + row[0] for row in STAR_SIGNINGS if row[4]]   # price None = not in the shop
        self.gift_ids = ["STAR_" + row[0] for row in STAR_SIGNINGS if not row[4]]
        for slug, name, pos, ovr, nation, club, num, desc in ROOKIE_CARDS:
            sho, strength = star_stats(pos, ovr)
            cid = "ROOKIE_" + slug
            self.cards[cid] = {"id": cid, "name": name, "kind": "rookie", "team": club, "slot": 0, "tier": "alright",
                               "rating": ovr, "pos": pos, "number": num, "pack": None, "sho": sho,
                               "str": strength, "design": "beginner", "desc": desc, "nation": nation}
        self.rookie_ids = ["ROOKIE_" + row[0] for row in ROOKIE_CARDS]
        for slug, name, pos, ovr, nation, num, desc in NO10_CARDS:
            sho, strength = star_stats(pos, ovr)
            cid = "NO10_" + slug
            self.cards[cid] = {"id": cid, "name": name, "kind": "no10", "team": nation, "slot": 0,
                               "tier": "good" if ovr >= 110 else "alright", "rating": ovr, "pos": pos,
                               "number": num, "pack": NO10_PACK, "sho": sho, "str": strength,
                               "design": "no10", "desc": desc, "nation": nation}
        self.no10_ids = ["NO10_" + row[0] for row in NO10_CARDS]
        self.star_badges = {code: load_pixel("%s_badge" % code, (96, 112), fit=True, quiet=True)
                            for code in STAR_CLUB_NAMES}
        self.user_idx = len(CLUBS)
        self.kit_cache = {}
        self.editing_name = False
        self.coll_page = 0
        self.played_this_match = set()
        self.my_card = None
        self.cpu_card = None
        self.wc_stamina = {}
        self.last_earned = 0
        self.last_xp = 0
        self.toasts = []
        self.versus = None
        self.quit_prompt = False
        self.lineup_half = 1
        self.pack_reveal = None
        self.pack_art = [load_pixel("pack_%d" % i, (330, 462), fit=True, quiet=True) for i in range(len(PACK_NAMES))]
        self.no10_badge = load_pixel("no10_badge", (240, 280), fit=True, quiet=True)
        self.card_back = load_pixel("card_back", (300, 416), quiet=True)
        self.banners = [load_pixel("banner_%d" % i, (840, 270), quiet=True) for i in (1, 2, 3)]
        self.slides = [load_pixel("slide_%d" % i, (560, 680), quiet=True) for i in (1, 2, 3, 4, 5)]
        self.menu_page = "main"
        self.wc_badge = load_pixel("wc_badge", (240, 280), fit=True, quiet=True)
        self.event_bg = load_pixel("event_bg", (WIDTH, HEIGHT), quiet=True)
        self.box_art = load_pixel("box_neymar", (330, 462), fit=True, quiet=True)
        self.event_spin = None
        self.event_popup = None
        self.extra_flags = {code: load_pixel("flag_%s" % code, (240, 160), fit=True, quiet=True)
                            for code in EXTRA_FLAGS}
        self.star_bg = load_pixel("star_bg", (WIDTH, HEIGHT), quiet=True)
        self.star_pack = load_pixel("pack_star", (330, 462), fit=True, quiet=True)
        self.tut = None
        self.rookie_sel = None
        self.time_scale = 1.0
        self.robots = []
        self._match_cpu = None
        self.practice = {"goals": {"home": 0, "away": 0}, "reset_t": 0.0, "flash": "home", "next_id": 1}
        self.multi = None
        self.stars_sel = "STAR_pele"
        self.stars_page = 0
        self.exchange_page = 0
        self.exchange_dupes = False
        self.store_confirm = None
        self.icon_faces = {}
        self.sig_looks = {}
        self.card_faces = {}
        for c in self.cards.values():
            face = load_pixel("%s_portrait" % c["id"], (192, 192), fit=True, quiet=True)
            if face is not None:
                self.card_faces[c["id"]] = face
            if c["design"] in ("icon", "signature"):
                slug = c["id"].split("_")[-1]
                self.icon_faces[c["id"]] = face or load_pixel("icon_%s" % slug, (192, 192), fit=True, quiet=True)
            if c["kind"] in ("sig", "star", "rookie", "no10"):
                slug = c["id"].split("_")[-1]
                pre = {"star": "STAR", "rookie": "ROOKIE", "no10": "NO10"}.get(c["kind"], "SIG")
                look = {}
                for piece in ("head", "torso", "arm", "leg"):
                    size, fit = PIECE_SIZE[piece]
                    look[piece] = load_pixel("%s_%s_%s" % (pre, slug, piece), size, fit=fit, quiet=True)
                self.sig_looks[c["id"]] = look
        self.view_pack = 0
        self.view_scroll = 0.0
        self.view_more = False
        self.view_more_scroll = 0.0
        self.quit_requested = False
        self.pending_click = None
        self.card_detail = None
        self.fx = []
        self.flag_colour_cache = {}
        self.match_time = 0.0
        self.half = 1
        self.save = self.default_save()
        self.ren = RenKit(self)
        self.net = NetLink()                       # online play + chat (browser only)
        self.pvp = None                            # {"role","name","opp","rank","oppRank","ranked"}
        self.net_t = 0.0                           # when the next snapshot goes out
        self.chat_log = []                         # [(name, text, age)]
        self.chat_open = False
        self.searching = None                      # {"t": seconds spent looking}
        self.refresh_team()
        self.load_save()
        self.refresh_team()
        self.restore_season()
        self.new_match()
        self.state = TITLE
        if TUTORIAL_ON_FIRST_RUN and not headless and not self.save.get("tutorial_done"):
            self.start_tutorial()                          # first launch: learn to play, then 3 packs + a beginner

    # ---- setup -------------------------------------------
    def pick_stadium(self):
        """A different ground every match."""
        if self.stadiums:
            self.stadium = random.randrange(len(self.stadiums))
        self.background = self._build_background(self.stadium)

    def _build_background(self, which=0):
        if which in self._bg_cache:
            return self._bg_cache[which]
        bg = pygame.Surface((WIDTH, HEIGHT)).convert()
        stadium = self.stadiums[which] if which < len(self.stadiums) else None
        if stadium is not None:
            bg.blit(pygame.transform.scale(stadium, (WIDTH, GROUND_Y)), (0, 0))
            veil = pygame.Surface((WIDTH, GROUND_Y), pygame.SRCALPHA)
            veil.fill((8, 12, 28, 52))
            bg.blit(veil, (0, 0))
        else:
            for y in range(0, GROUND_Y):
                t = y / max(1, GROUND_Y)
                col = tuple(int(lerp(SKY_TOP[i], SKY_BOT[i], t)) for i in range(3))
                pygame.draw.line(bg, col, (0, y), (WIDTH, y))

        pygame.draw.rect(bg, PITCH_A, (0, GROUND_Y, WIDTH, HEIGHT - GROUND_Y))
        for i, x in enumerate(range(0, WIDTH, 160)):
            if i % 2:
                pygame.draw.rect(bg, PITCH_B, (x, GROUND_Y, 160, HEIGHT - GROUND_Y))
        pygame.draw.line(bg, PITCH_EDGE, (0, GROUND_Y), (WIDTH, GROUND_Y), 6)

        # nets
        cy = self.crossbar_y
        for left in (True, False):
            x0 = 0 if left else WIDTH - GOAL_DEPTH
            rect = pygame.Rect(x0, cy, GOAL_DEPTH, GOAL_HEIGHT)
            shade = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
            shade.fill((10, 14, 24, 130))
            bg.blit(shade, rect.topleft)
            for x in range(rect.left, rect.right + 1, 22):
                pygame.draw.line(bg, NET, (x, rect.top), (x, rect.bottom), 1)
            for y in range(rect.top, rect.bottom + 1, 22):
                pygame.draw.line(bg, NET, (rect.left, y), (rect.right, y), 1)
        self._bg_cache[which] = bg
        return bg

    def impossible_unlocked(self):
        return hasattr(self, "save") and self.level() >= IMPOSSIBLE_LEVEL

    def impossible_run(self):
        return self.mode == "wc" and self.difficulty == IMPOSSIBLE

    def set_difficulty(self, i):
        if i == IMPOSSIBLE and (self.mode != "wc" or not self.impossible_unlocked()):
            self.toast("IMPOSSIBLE UNLOCKS AT LEVEL %d" % IMPOSSIBLE_LEVEL, (255, 120, 120))
            return
        self.difficulty = i
        self.brain.skill = DIFFICULTY[i][1]
        self.brain.impossible = i == IMPOSSIBLE
        if hasattr(self, "save"):
            self.write_save()

    def look_for(self, team_idx):
        """Teams in TEAM_LOOKS wear their kit + the difficulty's player."""
        if team_idx is None or not self.teams:
            return None
        pieces = self.looks.get(self.teams[team_idx]["name"])
        if not pieces:
            return None
        return {piece: imgs[min(self.difficulty, 2)] for piece, imgs in pieces.items()}

    def apply_looks(self):
        if getattr(self, "mode", "wc") == "practice":
            self.player.set_look(self.team_look(self.my_card) if self.my_card else None)
            return
        if getattr(self, "my_card", None) is not None:
            if self.mode == "club":
                self.player.set_look(self.team_look(self.my_card))      # your kit, their head
            else:
                self.player.set_look(self.card_original_look(self.my_card))
            self.cpu.set_look(self.card_original_look(self.cpu_card) if self.cpu_card else None)
            return
        if getattr(self, "mode", "wc") == "club":
            self.player.set_look(None)
            self.cpu.set_look(None)
            return
        mine = self.team if getattr(self, "teams", None) else None
        theirs = self.opponents[-1] if getattr(self, "opponents", None) else None
        self.player.set_look(self.look_for(mine))
        self.cpu.set_look(self.look_for(theirs))

    def club_look(self, idx, slot):
        if idx is None:
            return None
        pieces = self.club_looks.get(self.clubs[idx]["code"])
        return {piece: imgs[slot] for piece, imgs in pieces.items()} if pieces else None

    def new_match(self):
        self.forfeited = False
        if self.mode == "wc" and self.difficulty != IMPOSSIBLE:
            self.run_impossible = False                    # one easier round spoils the run
        if hasattr(self, "ren"):
            self.ren.reset_match()
        self.apply_looks()
        self.pick_stadium()
        self.match_track = random.choice(["match", "match2"]) if self.sfx.has_track("match2") else "match"
        self.match_time = 0.0
        self.half = 1
        self.score_home = 0
        self.score_away = 0
        self.slowmo = 1.0
        self.shake = 0.0
        self.goal_text_pop = 0.0
        self.last_scorer = None
        self.dragging = False
        self.particles.items.clear()
        self.setup_kickoff(None)

    def setup_kickoff(self, conceded_by):
        self.player.reset_to(WIDTH * 0.5 - 430)
        self.cpu.reset_to(WIDTH * 0.5 + 430)
        if self.mode == "practice":
            self.place_robots()
            self.sync_robots()
        # the ball drops on the side of whoever just conceded
        bias = {"home": 260.0, "away": -260.0}.get(conceded_by, 0.0)
        self.ball.reset(WIDTH * 0.5 + bias, 220, frozen=True)
        self.state = KICKOFF
        if hasattr(self, "ren"):
            self.ren.on_kickoff()
        self.state_timer = 0.0                     # no countdown
        self.last_touch = None
        self.own_goal = False
        self.dragging = False

    # ---- input -------------------------------------------
    FINGER_TO_MOUSE = {getattr(pygame, "FINGERDOWN", -901): pygame.MOUSEBUTTONDOWN,
                       getattr(pygame, "FINGERMOTION", -902): pygame.MOUSEMOTION,
                       getattr(pygame, "FINGERUP", -903): pygame.MOUSEBUTTONUP}

    def map_event(self, event):
        """Touch becomes mouse, and browser window coordinates become game coordinates.
        Returns None for events that should be dropped."""
        t = event.type
        if t in self.FINGER_TO_MOUSE:                       # iPad / phone
            self.touch_t = pygame.time.get_ticks() / 1000.0
            pos = (int(clamp(getattr(event, "x", 0.0), 0.0, 1.0) * WIDTH),
                   int(clamp(getattr(event, "y", 0.0), 0.0, 1.0) * HEIGHT))
            self.pointer = pos
            return pygame.event.Event(self.FINGER_TO_MOUSE[t], {"pos": pos, "button": 1, "touch": True})
        if t in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            if pygame.time.get_ticks() / 1000.0 - self.touch_t < 1.5:
                return None                                 # SDL's copy of the touch we just handled
            pos = getattr(event, "pos", None)
            if pos is not None:
                if VIEW_SCALE != 1:
                    pos = (pos[0] * VIEW_SCALE, pos[1] * VIEW_SCALE)
                    try:
                        event = pygame.event.Event(t, dict(event.__dict__, pos=pos))
                    except Exception:
                        event = pygame.event.Event(t, {"pos": pos, "button": getattr(event, "button", 1)})
                self.pointer = pos
        return event

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if TOUCH_OR_WEB:
                event = self.map_event(event)
                if event is None:
                    continue
            if self.card_detail is not None:
                if event.type == pygame.MOUSEBUTTONDOWN and self.input_locked():
                    continue
                if event.type == pygame.MOUSEBUTTONDOWN or (event.type == pygame.KEYDOWN
                                                             and event.key == pygame.K_ESCAPE):
                    self.card_detail = None
                continue
            if self.state == MYCLUB and self.editing_name and event.type == pygame.KEYDOWN:
                self.myclub_key(event)                      # typing the team name
                continue
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and self.tut is not None:
                    continue                                # the tutorial has its own SKIP button
                if event.key == pygame.K_ESCAPE:
                    if self.state == TITLE:
                        if getattr(self, "menu_page", "main") == "play":
                            self.menu_page = "main"
                            continue
                        return False
                    if self.state == FREE_SELECT:
                        self.state = TITLE
                        self.menu_page = "play"
                        continue
                    if self.state == PACK_MULTI:
                        self.open_packs(self.multi["pack"])
                        continue
                    if self.state == PACK_OPEN:
                        if self.pack_reveal and self.pack_reveal.get("multi"):
                            self.open_multi(self.pack_reveal["multi"])
                        elif self.pack_reveal and self.pack_reveal.get("back") == "event":
                            self.open_event()
                        elif self.pack_reveal and self.pack_reveal.get("back") == "stars":
                            self.open_stars()
                        else:
                            self.open_packs(self.pack_reveal["pack"] if self.pack_reveal else None)
                    elif self.state in (STARS, EXCHANGE):
                        if self.store_confirm is not None:
                            self.store_confirm = None
                        else:
                            self.open_store()
                    elif self.state == STORE:
                        self.state = TITLE
                    elif self.state == EVENT:
                        if self.event_spin is None:
                            self.event_popup = None
                            self.open_store()
                    elif self.state == PACK_VIEW:
                        if self.view_more:
                            self.view_more = False
                        else:
                            self.state = PACKS
                    elif self.state == PACKS:
                        self.open_store()
                    elif self.state in (SELECT, CLUB, MYCLUB):
                        if self.state == MYCLUB:
                            self.refresh_team()
                            self.write_save()
                        self.state = TITLE          # back to the menu
                    elif self.state == LINEUP and self.lineup_half == 1:
                        # back out before kick-off - the drawn opponent stays locked in
                        self.go_to_club() if self.mode == "club" else self.go_to_select()
                    elif self.state == TABLE:
                        self.table_click()
                    elif self.state == FULLTIME:
                        self.advance_after_goal()   # same as clicking: the result counts
                    else:
                        self.quit_prompt = not self.quit_prompt   # pause: resume / quit = loss
                        self.paused = self.quit_prompt
                        self.dragging = False
                    continue
                if event.key == pygame.K_p and self.state in (KICKOFF, PLAY):
                    self.paused = not self.paused
                    self.dragging = False
                elif event.key == pygame.K_F11:
                    try:
                        pygame.display.toggle_fullscreen()
                    except Exception:
                        pass
                elif event.key == pygame.K_F1:
                    self.debug = not self.debug
                elif event.key == pygame.K_m:
                    self.sfx.toggle_mute()
                elif event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                    self.set_difficulty({pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2}[event.key])

            if self.quit_prompt:
                if event.type == pygame.MOUSEBUTTONDOWN and self.input_locked():
                    continue
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    resume, quit_btn = self.quit_prompt_layout()
                    if resume.collidepoint(event.pos):
                        self.quit_prompt = False
                        self.paused = False
                    elif quit_btn.collidepoint(event.pos):
                        if self.mode == "pvp":
                            self.net.send({"t": "leave"})
                            self.leave_pvp("YOU LEFT THE MATCH")
                        else:
                            self.forfeit_match()
                continue
            if self.paused:
                continue
            if self.state in MENU_STATES:
                if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP) and self.input_locked():
                    continue                       # the screen only just opened
                if self.state in (STARS, EXCHANGE) and self.store_page_event(event):
                    continue
                if self.state == PACK_VIEW and event.type == getattr(pygame, "MOUSEWHEEL", -1):
                    self.scroll_view(-getattr(event, "y", 0) * 220)
                    continue
                if event.type == pygame.MOUSEBUTTONDOWN and event.button in (4, 5) and self.state == PACK_VIEW:
                    self.scroll_view(-220 if event.button == 4 else 220)
                    continue
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.searching:
                    if self.search_cancel_rect().collidepoint(event.pos):
                        self.cancel_search()
                    continue                       # the overlay swallows menu clicks
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    pos = Vector2(event.pos)
                    if self.tut is not None and (self.tutorial_click(event.pos) or not self.tutorial_allows(pos)):
                        continue                            # tutorial: its buttons, and only what it points at
                    {SELECT: self.select_click, TITLE: self.title_click,
                     CLUB: self.club_click, TABLE: lambda _p: self.table_click(),
                     PACKS: self.packs_click, MYCLUB: self.myclub_click, LINEUP: self.lineup_click,
                     PACK_OPEN: lambda _p: self.pack_open_click(),
                     PACK_VIEW: self.pack_view_click, EVENT: self.event_click,
                     STORE: self.store_click, STARS: self.stars_click, EXCHANGE: self.exchange_click,
                     FREE_SELECT: self.free_click, PACK_MULTI: self.multi_click,
                     ROOKIE_PICK: self.rookie_click}[self.state](pos)
                    if self.quit_requested:
                        return False
                continue
            if self.state == VERSUS:
                if event.type == pygame.MOUSEBUTTONDOWN or (event.type == pygame.KEYDOWN
                                                             and event.key == pygame.K_SPACE):
                    self.versus["t"] = max(self.versus["t"], VS_LENGTH)
                continue
            if self.state in (GOAL, FULLTIME):
                if self.input_locked():
                    continue                       # don't let the celebration be clicked away at once
                if event.type == pygame.MOUSEBUTTONDOWN or (
                        event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE):
                    self.advance_after_goal()
                continue

            if self.mode == "practice" and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 \
                    and (self.tutorial_click(event.pos) if self.tut else self.practice_click(event.pos)):
                continue                                    # the practice panel / tutorial box, not a throw
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.mode == "pvp":
                if self.chat_click(event.pos):
                    continue
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                btn = self.pause_button_rect()
                if btn is not None and btn.collidepoint(event.pos):
                    self.quit_prompt = True                 # same as Esc, for touch screens
                    self.paused = True
                    self.dragging = False
                    continue
            if self.ren.handle_event(event):                # Ren's ability keys / buttons
                continue
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self.dragging = True
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.dragging:
                self.dragging = False
                if self.state == PLAY:
                    self.release_throw(Vector2(event.pos))
        return True

    def throw_power(self, launch):
        p = self.player
        return lerp(THROW_MIN, p.max_power(), clamp(launch.length() / p.drag_range(), 0.0, 1.0))

    def release_throw(self, mouse):
        # launch_vector = mouse_position - player_position
        if self.mode == "pvp" and self.pvp is not None and not self.pvp_host():
            # mirror it back into the host's world before sending
            self.net.send({"t": "input", "x": round(WIDTH - mouse.x, 1), "y": round(mouse.y, 1)})
        launch = mouse - self.player.pos
        if launch.length() > 1.0:              # no cancel: every release throws
            # the throw goes where the (possibly shaky) arrow points right now
            launch = rot(launch, self.player.aim_wobble(pygame.time.get_ticks() * 0.001))
            if self.player.throw(launch, self.throw_power(launch), self.sfx, self.particles):
                self.ren.on_throw()
                if self.tut is not None:
                    self.tut["throws"] += 1

    def advance_after_goal(self):
        self.slowmo = 1.0
        if self.mode == "pvp":
            if self.state == FULLTIME:
                self.net.send({"t": "leave"})
                self.leave_pvp()
            else:
                self.setup_kickoff(self.last_scorer)   # the host restarts, the guest follows
            return
        if self.state == FULLTIME and self.mode == "free":
            self.leave_freeplay()
            return
        if self.state == FULLTIME and self.mode == "club" and self.club is not None:
            self.finish_club_round(self.score_home, self.score_away)
            return
        if self.state == FULLTIME:
            if self.teams and self.team is not None:
                if self.score_home > self.score_away:
                    self.results.append((self.score_home, self.score_away))
                    self.round += 1                 # through to the next round
                else:
                    self.new_tournament(None)       # knocked out: pick again
            if self.ren_pending:
                self.ren_pending = False
                self.reveal_ren()                   # REN AOYAGI UNLOCKED
                return
            self.go_to_select()
        else:
            self.setup_kickoff(self.last_scorer)

    # ---- update ------------------------------------------
    def tick_input_lock(self, dt):
        """A screen that has just appeared ignores clicks for a moment.

        Without it a double-click, or a click carried over from the last screen, goes
        straight through the new one - you tap a goal banner and end up two menus deep.
        The pitch itself is never locked: a throw has to be instant."""
        self.input_lock = max(0.0, self.input_lock - dt)
        sig = (self.state, getattr(self, "menu_page", ""), bool(self.quit_prompt),
               self.card_detail is not None)
        if sig != self._screen_sig:
            self._screen_sig = sig
            if self.state not in (PLAY, KICKOFF):
                self.input_lock = MENU_INPUT_DELAY

    def input_locked(self):
        return self.input_lock > 0.0

    def music_for_state(self):
        """menu/shop, match, pack opening, impossible, or results/credits."""
        if self.state == SELECT and self.mode == "wc" and self.difficulty == IMPOSSIBLE:
            return "impossible"
        if self.state == VERSUS and self.impossible_run():
            return "impossible"
        if self.state in (KICKOFF, PLAY, GOAL, VERSUS):
            return getattr(self, "match_track", "match")
        if self.state == FULLTIME:
            return "credits" if self.sfx.has_track("credits") else getattr(self, "match_track", "match")
        if self.state == PACK_OPEN and self.pack_reveal and self.pack_reveal["opened"] \
                and self.pack_reveal["tier"] in ("A", "B"):
            return "pack"
        return "menu"

    def update(self, dt):
        self.process_pending()
        self.sfx.play_track(self.music_for_state())
        self.shake = max(0.0, self.shake - dt * 46.0)      # always fades, even on menus / paused
        self.tick_input_lock(dt)
        if self.net.on:
            self.net_pump(dt)                              # online play + chat
        if self.tut is not None:
            self.update_tutorial(dt)
        if self.state == PACK_MULTI:
            self.multi["t"] += dt
            return
        if self.state == SELECT:
            self.update_select(dt)
            return
        if self.state == CLUB:
            self.update_club(dt)
            return
        if self.state == VERSUS:
            if not self.quit_prompt:
                self.update_versus(dt)
            return
        if self.state == EVENT:
            self.update_event(dt)
            return
        if self.state in (TITLE, TABLE, PACKS, PACK_OPEN, MYCLUB, LINEUP, PACK_VIEW,
                          STORE, STARS, EXCHANGE, FREE_SELECT, ROOKIE_PICK):
            return
        if self.paused:
            return
        dt *= self.time_scale
        if self.ren.cutscene is not None:                  # the match is frozen during a cutscene
            self.ren.update_cutscene(dt)
            return
        self.ren.update(dt)
        self.particles.update(dt)
        self.goal_text_pop = min(1.0, self.goal_text_pop + dt * 4.0)

        if self.state == KICKOFF:
            self.state_timer -= dt
            self.ball.pos.y = 220 + math.sin(pygame.time.get_ticks() * 0.004) * 12
            if self.state_timer <= 0.0:
                self.state = PLAY
                self.ball.frozen = False
                self.ball.vel.update(random.uniform(-160, 160), 120.0)
                self.sfx.play("whistle", 0.35)
        elif self.state in (GOAL, FULLTIME):
            pass                                   # waits for a click, stays in slow-mo

        if self.mode == "practice" and self.practice["reset_t"] > 0.0:
            self.practice["reset_t"] -= dt
            if self.practice["reset_t"] <= 0.0:
                self.practice_reset_ball()                 # practice goal: the ball comes straight back
        if self.state == PLAY and self.half < 3 and self.mode != "practice" \
                and not (self.mode == "pvp" and not self.pvp_host()):
            # the clock only runs while the ball is in play
            self.match_time += dt * self.slowmo
            if self.half == 1 and self.match_time >= HALF_SECONDS:
                self.match_time = HALF_SECONDS
                if self.mode == "pvp":                   # online: no subs, straight on
                    self.half = 2
                    self.toast("HALF TIME  %d - %d" % (self.score_home, self.score_away), WHITE, 2.0)
                    self.setup_kickoff(None)
                    return
                if self.mode == "free":                  # freeplay: same players, straight into the 2nd half
                    self.half = 2
                    self.toast("HALF TIME  %d - %d" % (self.score_home, self.score_away), WHITE, 2.0)
                    self.setup_kickoff(None)
                    return
                self.go_lineup(2)                        # half time: sub in
                return
            if self.half == 2 and self.match_time >= HALF_SECONDS * 2:
                self.match_time = HALF_SECONDS * 2
                if self.mode == "pvp":
                    self.finish_pvp()
                    return
                if self.mode == "wc" and self.score_home == self.score_away:
                    self.half = 3                        # knockout draw: golden goal
                    self.sfx.play("whistle", 0.3)
                else:
                    self.finish_match()
                    return
        if self.state == PLAY and self.mode == "practice":
            for bot in self.robots:
                if bot["mode"] != "DUMMY":                 # dummies just stand there
                    bot["brain"].slow = self.brain.slow
                    bot["brain"].update(dt * self.slowmo, self.ball)
        elif self.state == PLAY and self.mode != "pvp":
            self.brain.bonus = CPU_LOSING_BONUS * max(0, self.score_home - self.score_away)
            self.brain.update(dt * self.slowmo, self.ball)

        self.accumulator += dt * self.slowmo
        steps = 0
        while self.accumulator >= FIXED_DT and steps < MAX_STEPS_PER_FRAME:
            self.accumulator -= FIXED_DT
            steps += 1
            self.physics_step(FIXED_DT)
        if steps == MAX_STEPS_PER_FRAME:
            self.accumulator = 0.0

    def update_ability_ctx(self):
        """What the abilities look at: where the ball is, who's close, who's behind."""
        b = self.ball
        dolls = [self.player] + ([bot["doll"] for bot in self.robots] if self.mode == "practice" else [self.cpu])
        late = (self.state == PLAY and self.half >= 2 and self.mode in ("wc", "club", "free")
                and self.match_time >= HALF_SECONDS * 2 - 10.0)
        for d in dolls:
            own_goal_x = GOAL_DEPTH if d.facing > 0 else WIDTH - GOAL_DEPTH
            behind = (self.score_home < self.score_away) if d is self.player else (self.score_away < self.score_home)
            near = any(o is not d and o.pos.distance_to(d.pos) < 330.0 for o in dolls)
            d.ctx = {"own_third": abs(b.pos.x - own_goal_x) < WIDTH / 3.0,
                     "own_half": abs(d.pos.x - own_goal_x) < WIDTH * 0.5,
                     "near_opp": near, "clutch": behind or late}

    def physics_step(self, h):
        self.update_ability_ctx()
        if self.mode == "practice":
            self.practice_step(h)
            return
        self.player.step(h, self.segments, self.sfx, self.particles)
        self.cpu.step(h, self.segments, self.sfx, self.particles)
        self.ball.step(h, self.segments, self.sfx, self.particles)
        prev, v0 = self.last_touch, Vector2(self.ball.vel)
        if self.ball.home_ghost_t <= 0.0 and \
                ball_vs_player(self.ball, self.player, self.sfx, self.particles, self.on_big_hit):
            self.last_touch = "home"
            self.ren.on_touch((self.ball.vel - v0).length(), prev)
        if self.ball.ghost_t <= 0.0 and ball_vs_player(self.ball, self.cpu, self.sfx, self.particles,
                                                       self.on_big_hit):
            self.last_touch = "away"
        player_vs_player(self.player, self.cpu, self.sfx)
        if self.state == PLAY:
            self.check_goal()

    def on_big_hit(self, strength):
        self.shake = min(SHAKE_CAP, self.shake + strength / 400.0)

    def check_goal(self):
        # the ball has to be fully past the goal line and under the crossbar
        b = self.ball
        if b.pos.y < self.crossbar_y + CROSSBAR_THICK * 0.5:
            return
        if b.pos.x < GOAL_DEPTH - b.radius:
            self.score_goal("away")        # left goal -> CPU scores
        elif b.pos.x > WIDTH - GOAL_DEPTH + b.radius:
            self.score_goal("home")        # right goal -> player scores

    def score_goal(self, team):
        if self.mode == "practice":
            pr = self.practice
            pr["goals"][team] += 1
            pr["reset_t"] = PRACTICE_RESET
            if self.tut is not None and team == "home":
                self.tut["goals"] += 1
            pr["flash"] = team
            self.sfx.play("cheer", 0.6)
            self.ren.on_goal(team)
            self.shake = SHAKE_CAP * 0.6
            return
        if team == "home":
            self.score_home += 1
        else:
            self.score_away += 1
        self.last_scorer = team
        self.sfx.play("cheer", 0.9)
        self.ren.on_goal(team)
        # an own goal: the team that conceded touched it last
        self.own_goal = self.last_touch is not None and self.last_touch != team
        # the ball keeps flying into the net - the whole world just slows down
        self.shake = SHAKE_CAP
        self.slowmo = 0.22
        self.goal_text_pop = 0.0
        self.dragging = False
        if self.half == 3:
            self.finish_match()                          # golden goal wins it
        else:
            self.state = GOAL
            self.state_timer = GOAL_HOLD

    def forfeit_match(self):
        """Quitting a match counts as a 0-3 loss - no dodging a bad result."""
        if self.mode == "practice":
            self.end_practice()
            return
        if self.mode == "free":
            self.leave_freeplay()                          # freeplay: just leave, no reward
            return
        self.quit_prompt = False
        self.paused = False
        self.versus = None
        self.score_home, self.score_away = FORFEIT_SCORE
        self.forfeited = True
        self.finish_match()

    def quit_prompt_layout(self):
        resume = pygame.Rect(WIDTH // 2 - 430, 560, 400, 110)
        quit_btn = pygame.Rect(WIDTH // 2 + 30, 560, 400, 110)
        return resume, quit_btn

    def draw_quit_prompt(self, w):
        w.blit(tint((WIDTH, HEIGHT), (6, 8, 16, 190)), (0, 0))
        self.centre_text(w, "PAUSED", self.font_xl, WHITE, 250)
        warn = {"practice": "LEAVE PRACTICE?", "free": "QUIT FREEPLAY - NO REWARD"}.get(
            self.mode, "QUITTING COUNTS AS A %d-%d LOSS" % FORFEIT_SCORE)
        self.centre_text(w, warn, self.font_m, (255, 150, 150), 440)
        mouse = pygame.mouse.get_pos()
        quit_txt = "EXIT" if self.mode == "practice" else "QUIT MATCH"
        for rect, text, col in zip(self.quit_prompt_layout(), ("RESUME", quit_txt),
                                   (SELECT_GREEN, (170, 36, 44))):
            pygame.draw.rect(w, col, rect, border_radius=16)
            pygame.draw.rect(w, YELLOW if rect.collidepoint(mouse) else WHITE, rect, 6, border_radius=16)
            self.centre_in(w, text, rect, self.font_m)
        self.centre_text(w, "ESC TO RESUME", self.font_s, (190, 196, 210), 720)

    def finish_match(self):
        self.shake = 0.0                                   # no shaking through the full-time banner
        self.state = FULLTIME
        self.state_timer = 1e9
        self.goal_text_pop = 0.0
        self.sfx.play("whistle", 0.4)
        self.settle_match()

    # ---- drawing -----------------------------------------
    def draw(self):
        w = self.world
        if self.state == SELECT:
            self.draw_select(w)
        elif self.state == TITLE:
            self.draw_title(w)
        elif self.state == CLUB:
            self.draw_club(w)
        elif self.state == TABLE:
            self.draw_table(w)
        elif self.state == PACKS:
            self.draw_packs(w)
        elif self.state == PACK_VIEW:
            self.draw_pack_view(w)
        elif self.state == VERSUS:
            self.draw_versus(w)
        elif self.state == EVENT:
            self.draw_event(w)
        elif self.state == FREE_SELECT:
            self.draw_freeplay(w)
        elif self.state == PACK_MULTI:
            self.draw_multi(w)
        elif self.state == ROOKIE_PICK:
            self.draw_rookie_pick(w)
        elif self.state == STORE:
            self.draw_store(w)
        elif self.state == STARS:
            self.draw_stars(w)
        elif self.state == EXCHANGE:
            self.draw_exchange(w)
        elif self.state == PACK_OPEN:
            self.draw_pack_open(w)
        elif self.state == MYCLUB:
            self.draw_myclub(w)
        elif self.state == LINEUP:
            self.draw_lineup(w)
        elif self.ren.cutscene is not None:
            self.ren.draw_cutscene(w)
        else:
            self.draw_match(w)
        if self.card_detail is not None:
            self.draw_card_detail(w)
        if self.quit_prompt:
            self.draw_quit_prompt(w)
        if self.mode == "pvp" or self.chat_log:
            self.draw_chat(w)
        if self.searching:
            self.draw_searching(w)
        if self.tut is not None and self.ren.cutscene is None and self.card_detail is None:
            self.draw_tutorial(w)
        if self.ren.cutscene is None:
            self.draw_toasts(w)

        if PIXEL > 1:
            small = scale_into(w, (WIDTH // PIXEL, HEIGHT // PIXEL), "small")
            frame = small if WEB_VIEW else scale_into(small, (WIDTH, HEIGHT), "frame")
        else:
            frame = w
        dx = dy = 0
        if self.shake > 0.3:
            step = max(1, PIXEL)
            dx = int(random.uniform(-self.shake, self.shake)) // step * step
            dy = int(random.uniform(-self.shake, self.shake)) // step * step
            if WEB_VIEW:
                dx, dy = dx // PIXEL, dy // PIXEL
            self.screen.fill((8, 10, 16))
        self.screen.blit(frame, (dx, dy))

    def draw_match(self, w):
        w.blit(self.background, (0, 0))

        cy = self.crossbar_y
        for left in (True, False):
            a, b, _ = self.segments[0 if left else 1]
            pygame.draw.line(w, INK, a, b, CROSSBAR_THICK + 6)
            pygame.draw.line(w, LINE_WHITE, a, b, CROSSBAR_THICK)
            # front post is only a marking: the mouth below the bar is open
            post_x = GOAL_DEPTH if left else WIDTH - GOAL_DEPTH
            pygame.draw.line(w, INK, (post_x, cy), (post_x, GROUND_Y), 10)
            pygame.draw.line(w, LINE_WHITE, (post_x, cy), (post_x, GROUND_Y), 5)


        if self.mode == "practice":
            for bot in self.robots:
                bot["doll"].draw(w, self.debug)
        else:
            self.cpu.draw(w, self.debug)
        self.ren.draw_under(w)                     # darkened pitch + afterimages
        self.ren.draw_player(w)
        self.ren.draw_over_player(w)               # aura, eye glow
        self.ball.draw(w)
        self.ren.draw_ball_fx(w)

        if self.state == PLAY:
            self.draw_aim(w)
        self.ren.apply_camera(w)
        if self.mode == "practice" and self.tut is None:
            self.draw_practice_ui(w)
        elif self.mode == "practice":
            self.draw_practice_flash(w)
        else:
            self.draw_hud(w)
        self.ren.draw_ui(w)

        if self.state in (GOAL, FULLTIME):
            self.draw_banner(w)
        if self.paused and not self.quit_prompt:
            w.blit(tint((WIDTH, HEIGHT), (8, 10, 18, 140)), (0, 0))
            self.centre_text(w, "PAUSED", self.font_xl, WHITE, HEIGHT * 0.36)



    # ---- pre-match VS screen -------------------------------------------------
    def start_versus(self):
        self.versus = {"t": 0.0}
        self.state = VERSUS
        self.dragging = False

    def match_sides(self):
        """(name, crest image, card, colour) for home and away."""
        if self.mode == "free":
            home = (self.my_card["name"].upper(), self.card_badge(self.my_card))
            away = (self.cpu_card["name"].upper(), self.card_badge(self.cpu_card))
        elif self.mode == "club":
            me, opp = self.clubs[self.user_idx], self.clubs[self.club_opps[-1]]
            home = (me["name"].upper(), me["badge"])
            away = (opp["name"].upper(), opp["badge"])
        else:
            mine = self.teams[self.team] if self.team is not None and self.teams else None
            theirs = self.teams[self.opponents[-1]] if self.opponents and self.teams else None
            home = (NATION_NAMES.get(mine["name"], mine["name"]) if mine else "HOME", mine["flag"] if mine else None)
            away = (NATION_NAMES.get(theirs["name"], theirs["name"]) if theirs else "AWAY",
                    theirs["flag"] if theirs else None)
        return ((home[0], home[1], self.my_card, (40, 96, 214)),
                (away[0], away[1], self.cpu_card, (206, 40, 54)))

    def update_versus(self, dt):
        v = self.versus
        prev = v["t"]
        v["t"] += dt
        for moment in VS_SLAMS:
            if prev < moment <= v["t"]:
                self.sfx.play("shock", 1.0)
        if v["t"] >= (PVP_VS_LENGTH if self.mode == "pvp" else VS_LENGTH):
            self.versus = None
            self.state = KICKOFF                           # the old throw-in
            self.state_timer = 0.0

    ROUND_TITLES = {"DAY1": "MATCH DAY 1", "DAY2": "MATCH DAY 2", "DAY3": "MATCH DAY 3", "R 16": "ROUND OF 16",
                    "QRTR": "QUARTER FINAL", "SEMI": "SEMI FINAL", "FINL": "FINAL"}

    def intro_title(self):
        if self.mode == "free":
            return "FREEPLAY  -  %s" % DIFFICULTY[self.free["diff"]][0]
        if self.mode == "club":
            return "CLUB FOOTBALL  ROUND %d" % (getattr(self, "club_round", 0) + 1)
        name = ROUNDS[min(self.round, len(ROUNDS) - 1)]
        return "WORLD CUP 2026 " + self.ROUND_TITLES.get(name, name)

    def intro_background(self):
        """The match stadium, blurred - built once per stadium."""
        key = self.stadium
        if getattr(self, "_intro_bg", (None, None))[0] != key:
            small = pygame.transform.smoothscale(self.background, (WIDTH // 14, HEIGHT // 14))
            blur = pygame.transform.smoothscale(small, (WIDTH, HEIGHT))
            wash(blur, (10, 12, 20, 70))
            self._intro_bg = (key, blur)
        return self._intro_bg[1]

    def outlined(self, text, font, colour, scale=1.0, outline=(34, 24, 8), width=6):
        """Chunky yellow-on-dark text like the original's intro."""
        key = ("out", text, id(font), tuple(colour)[:4], round(scale, 3),
               tuple(outline)[:4] if outline else None, width)
        hit = self.text_cache.get(key)
        if hit is not None:
            return hit
        base = font.render(text, True, colour)
        edge = font.render(text, True, outline)
        W, H = base.get_width() + width * 2, base.get_height() + width * 2
        surf = pygame.Surface((W, H), pygame.SRCALPHA)
        for dx in (-width, 0, width):
            for dy in (-width, 0, width):
                if dx or dy:
                    surf.blit(edge, (width + dx, width + dy))
        surf.blit(base, (width, width))
        if scale != 1.0:
            surf = pygame.transform.smoothscale(surf, (max(1, int(W * scale)), max(1, int(H * scale))))
        self.cache_text(key, surf)
        return surf

    def draw_versus(self, w):
        v = self.versus
        t = v["t"] if v else VS_LENGTH
        home, away = self.match_sides()
        title = self.intro_title()
        if t < VS_TITLE_END:
            # 1) plain grey card with the round title
            w.fill((88, 88, 92))
            img = self.label(title, WIDTH - 200, WHITE, self.font_m)
            w.blit(img, img.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
            return
        # 2) the blurred stadium, title at the top
        w.blit(self.intro_background(), (0, 0))
        k = clamp((t - VS_TITLE_END) / 0.5, 0.0, 1.0)
        if k < 1.0:
            wash(w, (88, 88, 92, int(255 * (1 - k))))
        ty = int(lerp(HEIGHT // 2, 110, k))
        img = self.label(title, WIDTH - 200, WHITE, self.font_m)
        w.blit(img, img.get_rect(center=(WIDTH // 2, ty)))
        if self.impossible_run():
            tag = self.label("IMPOSSIBLE  -  3X COINS", 900, (255, 90, 90))
            w.blit(tag, tag.get_rect(center=(WIDTH // 2, ty + 70)))

        def pop(moment):
            if t < moment:
                return None
            p = clamp((t - moment) / 0.18, 0.0, 1.0)
            return 1.0 + (1.0 - p) * 0.6               # lands from a bit bigger

        yellow = (255, 214, 40)
        rows = ((home[0], VS_SLAMS[0], 400, yellow, self.font_xl, 0.95),
                ("VS", VS_SLAMS[1], 555, WHITE, self.font_l, 0.8),
                (away[0], VS_SLAMS[2], 710, yellow, self.font_xl, 0.95))
        for text, moment, y, col, font, size in rows:
            sc = pop(moment)
            if sc is None:
                continue
            img = self.outlined(text, font, col, size * sc)
            if img.get_width() > WIDTH - 360:
                r = (WIDTH - 360) / img.get_width()
                img = pygame.transform.smoothscale(img, (int(img.get_width() * r), int(img.get_height() * r)))
            w.blit(img, img.get_rect(center=(WIDTH // 2, y)))
        if t > VS_FADE:                                        # 3) fade into the match
            f = clamp((t - VS_FADE) / (VS_LENGTH - VS_FADE), 0.0, 1.0)
            match = self.background.copy()
            match.set_alpha(int(255 * f))
            w.blit(match, (0, 0))
        elif t > VS_SLAMS[2] + 0.4:
            self.centre_text(w, "CLICK TO KICK OFF", self.font_s, (220, 224, 236), HEIGHT - 80)


    # ---- team select + tournament ------------------------
    def new_tournament(self, team):
        self.team = team
        self.run_impossible = True
        self.wc_stamina = {}
        self.round = 0
        self.opponents = []        # filled in one round at a time by the draw
        self.results = []          # (your goals, their goals) for each round won
        self.roulette = None

    def run_in_progress(self):
        return bool(self.opponents) and self.round < len(ROUNDS)

    def start_draw(self):
        """White outline hops around the flags, slowing down, until it lands
        on this round's opponent (never yourself or someone already played)."""
        cands = [i for i in range(len(self.teams))
                 if i != self.team and i not in self.opponents]
        if not cands:
            cands = [i for i in range(len(self.teams)) if i != self.team] or [self.team]
        self.roulette = {"cands": cands, "cur": random.choice(cands),
                         "interval": ROULETTE_START, "timer": 0.0,
                         "landed": False, "hold": 0.0}

    def update_select(self, dt):
        rl = self.roulette
        if rl is None:
            return
        if rl["landed"]:
            rl["hold"] += dt                       # waits for a click to kick off
            return
        rl["timer"] += dt
        if rl["timer"] >= rl["interval"]:
            rl["timer"] = 0.0
            options = [c for c in rl["cands"] if c != rl["cur"]] or rl["cands"]
            rl["cur"] = random.choice(options)
            rl["interval"] *= ROULETTE_SLOWDOWN
            if rl["interval"] >= ROULETTE_STOP:
                rl["landed"] = True
                self.sfx.play("whistle", 0.3)

    def go_to_select(self):
        self.state = SELECT
        self.paused = False
        self.dragging = False
        self.slowmo = 1.0
        self.shake = 0.0

    def start_round(self):
        self.brain.skill = DIFFICULTY[self.difficulty][1]
        self.brain.impossible = self.difficulty == IMPOSSIBLE
        self.played_this_match = set()
        self.my_card = None
        self.go_lineup(1)                     # kicks off against opponents[round]

    def select_layout(self):
        """Screen rectangles for the select screen (same idea as the original)."""
        n = len(self.teams)
        cols = max(1, min(7, math.ceil(n / 2))) if n > 1 else 1
        rows = max(1, math.ceil(n / cols))
        area_x0, area_x1, area_y0 = 390, WIDTH - 40, 190
        cell_w = (area_x1 - area_x0) / cols
        row_h = min(240, 480 / rows)
        flag_w, flag_h = min(190, cell_w - 30), min(118, row_h - 70)
        flags = []
        for i in range(n):
            r, c = divmod(i, cols)
            cx = area_x0 + cell_w * (c + 0.5)
            y = area_y0 + r * row_h
            flags.append(pygame.Rect(int(cx - flag_w / 2), int(y), int(flag_w), int(flag_h)))
        arrow = pygame.Rect(55, 290, 250, 240)
        self.diff_rects = [pygame.Rect(55, 536 + i * 48, 250, 42) for i in range(len(DIFFICULTY))]
        box_w, box_h, y_box = 240, 225, 795
        gap = (WIDTH - 110 - box_w * len(ROUNDS)) / (len(ROUNDS) - 1)
        boxes = [pygame.Rect(int(55 + i * (box_w + gap)), y_box, box_w, box_h) for i in range(len(ROUNDS))]
        return flags, arrow, boxes

    def can_start(self):
        return self.team is not None and self.round < len(ROUNDS) and self.roulette is None

    def select_click(self, pos):
        flags, arrow, _ = self.select_layout()
        if self.roulette is not None:
            if self.roulette["landed"]:            # opponent drawn: click to start
                self.opponents.append(self.roulette["cur"])
                self.roulette = None
                self.start_round()
            return
        if not self.run_in_progress():             # locked during a run
            for i, rect in enumerate(self.diff_rects):
                if rect.collidepoint(pos.x, pos.y):
                    self.set_difficulty(i)
                    return
            for i, rect in enumerate(flags):
                if rect.inflate(20, 70).move(0, 30).collidepoint(pos.x, pos.y):
                    self.new_tournament(i)
                    return
        if arrow.collidepoint(pos.x, pos.y) and self.can_start():
            if len(self.opponents) > self.round:
                self.start_round()                  # opponent already drawn: play them
            else:
                self.start_draw()

    def _build_select_bg(self):
        bg = pygame.Surface((WIDTH, HEIGHT)).convert()
        bg.fill(SELECT_BG)
        rng = random.Random(3)
        for y in range(0, HEIGHT, 6):           # faint scanline texture
            shade = rng.randint(-4, 4)
            col = tuple(clamp(c + shade, 0, 255) for c in SELECT_BG)
            pygame.draw.line(bg, col, (0, y), (WIDTH, y), 3)
        faint = (44, 76, 46)                    # ghost pitch markings
        pygame.draw.circle(bg, faint, (WIDTH // 2 - 120, 260), 330, 5)
        pygame.draw.line(bg, faint, (WIDTH // 2 - 120, 0), (WIDTH // 2 - 120, HEIGHT), 5)
        return bg

    def label(self, text, max_w, color=WHITE, font=None):
        key = ("lab", text, int(max_w), tuple(color)[:4], id(font) if font else 0)
        hit = self.text_cache.get(key)
        if hit is not None:
            return hit
        img = (font or self.font_m).render(text, True, color)
        if img.get_width() > max_w:
            img = (self.font_m if font else self.font_s).render(text, True, color)
        if img.get_width() > max_w and font:
            img = self.font_s.render(text, True, color)
        if img.get_width() > max_w:
            k = max_w / img.get_width()
            img = pygame.transform.smoothscale(img, (int(img.get_width() * k), int(img.get_height() * k)))
        self.cache_text(key, img)
        return img

    def draw_select(self, w):
        w.blit(self.select_bg, (0, 0))
        flags, arrow, boxes = self.select_layout()
        mouse = pygame.mouse.get_pos()
        t = pygame.time.get_ticks() * 0.001

        champion = self.team is not None and self.round >= len(ROUNDS)
        if champion:
            title = "CHAMPIONS!"
        elif self.roulette is not None and self.roulette["landed"]:
            title = "%s:  %s  VS  %s" % (ROUNDS[self.round], self.teams[self.team]["name"],
                                         self.teams[self.roulette["cur"]]["name"])
        elif self.roulette is not None:
            title = ROUNDS[self.round] + "  -  DRAWING OPPONENT"
        elif self.opponents:
            title = "NEXT: " + ROUNDS[self.round]
        else:
            title = "SELECT YOUR TEAM"
        self.centre_text(w, title, self.font_l, YELLOW if champion else WHITE, 50)
        if REN_IN_GAME and self.mode == "wc" and self.difficulty == IMPOSSIBLE and not self.ren_unlocked():
            hint = self.label(REN_UNLOCK_HINT, 1500, (170, 240, 255), font=self.font_s)
            w.blit(hint, hint.get_rect(center=(WIDTH // 2, 145)))

        if self.roulette is not None and self.roulette["landed"] and int(t * 2.5) % 2 == 0:
            self.centre_text(w, "CLICK TO START", self.font_m, YELLOW, 655)

        # the go button
        ready = self.can_start() or (self.roulette is not None and self.roulette["landed"])
        pygame.draw.rect(w, SELECT_GREEN if ready else (40, 88, 44), arrow)
        pygame.draw.rect(w, WHITE if ready else (120, 140, 120), arrow, 8)
        cx, cy = arrow.centerx, arrow.centery
        nudge = int(math.sin(t * 6.0) * 6) if ready else 0
        shaft = pygame.Rect(cx - 62 + nudge, cy - 16, 70, 32)
        head = [(cx + 8 + nudge, cy - 44), (cx + 62 + nudge, cy), (cx + 8 + nudge, cy + 44)]
        arrow_col = (236, 236, 236) if ready else (120, 140, 120)
        pygame.draw.rect(w, arrow_col, shaft)
        pygame.draw.polygon(w, arrow_col, head)
        pygame.draw.rect(w, (176, 176, 176) if ready else (100, 120, 100),
                         (shaft.x, shaft.bottom - 10, shaft.w, 10))

        if MISSING_SPRITES:                    # tell the player what's missing
            note = self.font_s.render("MISSING FROM THE SPRITES FOLDER: " + ", ".join(MISSING_SPRITES),
                                      True, (255, 110, 110))
            if note.get_width() > WIDTH - 40:
                k = (WIDTH - 40) / note.get_width()
                note = pygame.transform.smoothscale(note, (int(note.get_width() * k), int(note.get_height() * k)))
            w.blit(note, note.get_rect(midbottom=(WIDTH // 2, HEIGHT - 6)))

        # difficulty (easy / medium / hard) - with the team's players if it has any
        locked = self.run_in_progress() or self.roulette is not None
        team_heads = (self.looks.get(self.teams[self.team]["name"], {}).get("head")
                      if self.team is not None else None)
        for i, rect in enumerate(self.diff_rects):
            chosen = i == self.difficulty
            pygame.draw.rect(w, SELECT_GREEN if (chosen or not locked) else (40, 88, 44), rect)
            pygame.draw.rect(w, YELLOW if chosen else (WHITE if not locked else (120, 140, 120)), rect,
                             6 if chosen else 3)
            txt = self.font_s.render(DIFFICULTY[i][0], True, YELLOW if chosen else WHITE)
            if i == IMPOSSIBLE:
                unlocked = self.impossible_unlocked()
                pygame.draw.rect(w, (120, 20, 30) if unlocked else (50, 40, 44), rect.inflate(-6, -6))
                if chosen:
                    pygame.draw.rect(w, YELLOW, rect, 6)
                label = "IMPOSSIBLE" if unlocked else "LOCKED - LV %d" % IMPOSSIBLE_LEVEL
                txt = self.label(label, rect.w - 24, YELLOW if chosen else ((255, 210, 210) if unlocked
                                                                            else (160, 150, 150)))
            head = None                                  # difficulty only changes the CPU now
            if head is not None:
                icon = pygame.transform.scale(head, (int(head.get_width() * 44 / head.get_height()), 44))
                w.blit(icon, icon.get_rect(midleft=(rect.x + 14, rect.centery)))
                w.blit(txt, txt.get_rect(midleft=(rect.x + 78, rect.centery)))
            else:
                w.blit(txt, txt.get_rect(center=rect.center))

        # flags
        for i, rect in enumerate(flags):
            team = self.teams[i]
            img = fit_flag(team["flag"], rect.w, rect.h)
            pos = img.get_rect(center=rect.center)
            chosen = i == self.team
            used = i in self.opponents[:self.round]
            rl = self.roulette
            if chosen:
                pos.y -= 8
                pygame.draw.rect(w, YELLOW, pos.inflate(18, 18), 7)
            elif rl is not None and i == rl["cur"]:
                flash = rl["landed"] and rl["hold"] < ROULETTE_BLINK and int(rl["hold"] * 8) % 2 == 1
                if not flash:
                    pygame.draw.rect(w, WHITE, pos.inflate(22, 22), 8)
            elif (not self.run_in_progress() and rl is None
                  and pos.inflate(20, 70).move(0, 30).collidepoint(mouse)):
                pygame.draw.rect(w, WHITE, pos.inflate(12, 12), 3)
            if used:                                   # already beaten this run
                img = img.copy()
                img.fill((110, 110, 110), special_flags=pygame.BLEND_RGB_MULT)
            w.blit(img, pos)
            name = self.label(team["name"], rect.w + 24, YELLOW if chosen else WHITE)
            w.blit(name, name.get_rect(midtop=(rect.centerx, rect.bottom + 12)))

        # tournament path
        for i, (label, box) in enumerate(zip(ROUNDS, boxes)):
            txt = self.label(label, box.w)
            w.blit(txt, txt.get_rect(midbottom=(box.centerx, box.top - 12)))
            pygame.draw.rect(w, SELECT_GREEN, box)
            current = self.team is not None and i == self.round and self.round < len(ROUNDS)
            border = YELLOW if (current and int(t * 3) % 2 == 0) else WHITE
            pygame.draw.rect(w, border, box, 8)
            if self.team is None:
                continue
            if i < len(self.opponents):
                opp = self.teams[self.opponents[i]]
            elif i == len(self.opponents) and self.roulette is not None:
                opp = self.teams[self.roulette["cur"]]  # the draw, live
            else:
                continue
            img = fit_flag(opp["flag"], box.w - 60, box.h - 90)
            if i < self.round:                     # already beaten
                img = img.copy()
                img.fill((110, 110, 110), special_flags=pygame.BLEND_RGB_MULT)
            w.blit(img, img.get_rect(center=(box.centerx, box.centery - 18)))
            name = self.label(opp["name"], box.w - 20)
            w.blit(name, name.get_rect(midtop=(box.centerx, box.bottom - 62)))
            if i < self.round and i < len(self.results):   # show the score
                hs, as_ = self.results[i]
                score = self.font_l.render("%d-%d" % (hs, as_), True, WHITE)
                shadow = self.font_l.render("%d-%d" % (hs, as_), True, INK)
                c = (box.centerx, box.centery - 18)
                w.blit(shadow, shadow.get_rect(center=(c[0] + 4, c[1] + 5)))
                w.blit(score, score.get_rect(center=c))

    # ---- club season ---------------------------------------
    def new_season(self, club):
        self.club = club
        self.club_round = 0
        self.club_opps = []
        self.club_results = []
        self.club_roulette = None
        self.club_over = None            # None | "champions" | "finished" | "relegated"
        self.table_msg = ""
        self.table = {i: {"p": 0, "w": 0, "d": 0, "l": 0, "gf": 0, "ga": 0, "pts": 0,
                          "strikes": 0, "out": False, "out_round": 0} for i in range(len(self.clubs))}

    def active_clubs(self):
        return [i for i in range(len(self.clubs)) if not self.table[i]["out"]]

    def season_running(self):
        return self.club is not None and self.club_round > 0 and self.club_over is None

    def standings(self):
        """Clubs still in the league, best first; removed clubs after them."""
        def key(i):
            r = self.table[i]
            return (-r["pts"], -(r["gf"] - r["ga"]), -r["gf"], -self.clubs[i]["strength"])
        active = sorted(self.active_clubs(), key=key)
        gone = sorted([i for i in self.table if self.table[i]["out"]],
                      key=lambda i: (-self.table[i]["out_round"], key(i)))
        return active + gone

    def go_to_club(self):
        self.mode = "club"
        if self.difficulty == IMPOSSIBLE:
            self.difficulty = 2
            self.brain.skill = DIFFICULTY[2][1]
        self.brain.impossible = False
        self.state = CLUB
        self.paused = False
        self.dragging = False
        self.slowmo = 1.0
        self.shake = 0.0

    def club_layout(self):
        n = len(CLUBS)
        cols = max(1, math.ceil(n / 2))
        x0, x1 = 390, WIDTH - 40
        cell = (x1 - x0) / cols
        badges = []
        for i in range(n):
            r, c = divmod(i, cols)
            cx = x0 + cell * (c + 0.5)
            badges.append(pygame.Rect(int(cx - 42), 118 + r * 200, 84, 98))
        arrow = pygame.Rect(55, 130, 250, 200)
        diff = [pygame.Rect(55, 350 + i * 60, 250, 52) for i in range(3)]
        table_btn = pygame.Rect(55, 540, 250, 52)
        box_w, box_h = 270, 160
        gap = (WIDTH - 110 - box_w * 6) / 5
        boxes = [pygame.Rect(int(55 + (i % 6) * (box_w + gap)), 650 + (i // 6) * 215, box_w, box_h)
                 for i in range(CLUB_ROUNDS)]
        return badges, arrow, diff, table_btn, boxes

    def club_can_draw(self):
        if len(self.save["squad"]) < SQUAD_SIZE or self.club_roulette is not None:
            return False
        if self.club is None or self.club_over is not None:
            return True                                   # ready to start a new season
        return self.club_round < CLUB_ROUNDS

    def club_click(self, pos):
        badges, arrow, diff, table_btn, boxes = self.club_layout()
        rl = self.club_roulette
        if rl is not None:
            if rl["landed"]:                          # opponent drawn: click to start
                self.club_opps.append(rl["cur"])
                self.club_roulette = None
                self.start_club_match()
            return
        if table_btn.collidepoint(pos.x, pos.y):
            self.table_msg = ""
            self.state = TABLE
            return
        if not self.season_running():
            for i, rect in enumerate(diff):
                if rect.collidepoint(pos.x, pos.y):
                    self.set_difficulty(i)
                    return
        if arrow.collidepoint(pos.x, pos.y):
            if len(self.save["squad"]) < SQUAD_SIZE:
                self.club_notice = "PICK 5 PLAYERS IN MY CLUB FIRST"
                return
            if self.club is None or self.club_over is not None:
                self.new_season(self.user_idx)         # a new season with your team
            if self.club_can_draw():
                if self.club_over is None and len(self.club_opps) > len(self.club_results):
                    self.start_club_match()            # opponent already drawn: play them
                else:
                    self.start_club_draw()

    def start_club_draw(self):
        """Roulette over the clubs still in the league - never yourself, and
        never a club you've played in the last CLUB_NO_REPEAT - 1 rounds."""
        recent = set(self.club_opps[-(CLUB_NO_REPEAT - 1):])
        active = [i for i in self.active_clubs() if i != self.club]
        cands = [i for i in active if i not in recent] or active or [self.club]
        self.club_roulette = {"cands": cands, "cur": random.choice(cands),
                              "interval": ROULETTE_START, "timer": 0.0, "landed": False, "hold": 0.0}

    def update_club(self, dt):
        rl = self.club_roulette
        if rl is None:
            return
        if rl["landed"]:
            rl["hold"] += dt
            return
        rl["timer"] += dt
        if rl["timer"] >= rl["interval"]:
            rl["timer"] = 0.0
            options = [c for c in rl["cands"] if c != rl["cur"]] or rl["cands"]
            rl["cur"] = random.choice(options)
            rl["interval"] *= ROULETTE_SLOWDOWN
            if rl["interval"] >= ROULETTE_STOP:
                rl["landed"] = True
                self.sfx.play("whistle", 0.3)

    def start_club_match(self):
        # stronger real-life clubs play a bit sharper
        opp = self.clubs[self.club_opps[-1]]
        self.brain.skill = clamp(DIFFICULTY[self.difficulty][1] + (opp["strength"] - 76) / 150.0, 0.25, 0.98)
        self.played_this_match = set()
        self.my_card = None
        self.go_lineup(1)

    # ---- results, simulation, relegation --------------------
    def record(self, a, b, ga, gb):
        for i, f, x in ((a, ga, gb), (b, gb, ga)):
            r = self.table[i]
            r["p"] += 1
            r["gf"] += f
            r["ga"] += x
            if f > x:
                r["w"] += 1
                r["pts"] += 3
            elif f == x:
                r["d"] = r.get("d", 0) + 1
                r["pts"] += 1
            else:
                r["l"] += 1

    def simulate(self, a, b):
        """A 2 x 30s match between two clubs: goals from real-life strength
        (stronger clubs score more, draws happen)."""
        sa, sb = self.clubs[a]["strength"], self.clubs[b]["strength"]
        edge = (sa - sb) / 40.0

        def goals(lam):
            n, p, l = 0, random.random(), math.exp(-lam)
            acc = l
            while p > acc and n < 8:
                n += 1
                l *= lam / n
                acc += l
            return n
        return goals(1.4 * math.exp(edge)), goals(1.4 * math.exp(-edge))

    def finish_club_round(self, my_goals, their_goals):
        me, opp = self.club, self.club_opps[-1]
        self.club_results.append((my_goals, their_goals))
        self.record(me, opp, my_goals, their_goals)
        # everyone else plays too
        others = [i for i in self.active_clubs() if i not in (me, opp)]
        random.shuffle(others)
        for a, b in zip(others[0::2], others[1::2]):
            self.record(a, b, *self.simulate(a, b))
        self.club_round += 1

        # relegation zone: bottom 3 for 2 rounds in a row are removed
        order = self.standings()
        active = [i for i in order if not self.table[i]["out"]]
        zone = set(active[-RELEGATION_ZONE:]) if len(active) > RELEGATION_ZONE else set()
        for i in active:
            self.table[i]["strikes"] = self.table[i]["strikes"] + 1 if i in zone else 0
        removed = []
        for i in active[::-1]:
            if (self.table[i]["strikes"] >= RELEGATION_STRIKES
                    and len(self.active_clubs()) > MIN_CLUBS_LEFT):
                self.table[i]["out"] = True
                self.table[i]["out_round"] = self.club_round
                removed.append(self.clubs[i]["code"])

        won = my_goals > their_goals
        msg = "ROUND %d:  %s %d - %d %s" % (self.club_round, self.clubs[me]["code"], my_goals,
                                           their_goals, self.clubs[opp]["code"])
        if removed:
            msg += "   |   OUT: " + ", ".join(removed)
        if self.table[me]["out"]:
            self.club_over = "relegated"
        elif len(self.active_clubs()) <= 1 or self.club_round >= CLUB_ROUNDS:
            pos = self.standings().index(me) + 1
            self.club_over = "champions" if pos == 1 else "finished"
            if pos == 1:
                self.award_xp(XP_TROPHY)
        self.table_msg = msg
        self.slowmo = 1.0
        self.state = TABLE
        self.write_save()

    def table_click(self):
        if self.club_over in ("relegated", "champions", "finished") and self.table_msg:
            # season over: back to picking a club, table stays visible there
            self.table_msg = ""
            self.go_to_club()
            return
        self.table_msg = ""
        self.go_to_club()

    # ---- drawing: club select --------------------------------
    def draw_club(self, w):
        w.blit(self.select_bg, (0, 0))
        badges, arrow, diff, table_btn, boxes = self.club_layout()
        mouse = pygame.mouse.get_pos()
        t = pygame.time.get_ticks() * 0.001
        rl = self.club_roulette

        if self.club_over == "champions":
            title, col = "CHAMPIONS!", YELLOW
        elif self.club_over == "relegated":
            title, col = "GAME OVER - RELEGATED", (255, 110, 110)
        elif self.club_over == "finished":
            pos = self.standings().index(self.club) + 1
            title, col = "SEASON OVER - FINISHED %s" % ordinal(pos), WHITE
        elif rl is not None and rl["landed"]:
            title, col = "ROUND %d:  %s  VS  %s" % (self.club_round + 1, self.clubs[self.club]["code"],
                                                  self.clubs[rl["cur"]]["code"]), WHITE
        elif rl is not None:
            title, col = "ROUND %d  -  DRAWING OPPONENT" % (self.club_round + 1), WHITE
        elif self.club is not None and self.club_round > 0:
            title, col = "NEXT: ROUND %d" % (self.club_round + 1), WHITE
        else:
            title, col = "%s  -  NEW SEASON" % self.clubs[self.user_idx]["name"], WHITE
        self.centre_text(w, title, self.font_l, col, 22)
        if len(self.save["squad"]) < SQUAD_SIZE:
            self.centre_text(w, "PICK 5 PLAYERS IN MY CLUB FIRST", self.font_m, (255, 130, 130), 562)
        me = self.clubs[self.user_idx]
        if me["badge"] is not None:
            b = fit_flag(me["badge"], 70, 82)
            w.blit(b, b.get_rect(center=(arrow.centerx, 64)))

        # go button
        ready = self.club_can_draw() or (rl is not None and rl["landed"])
        pygame.draw.rect(w, SELECT_GREEN if ready else (40, 88, 44), arrow)
        pygame.draw.rect(w, WHITE if ready else (120, 140, 120), arrow, 8)
        cx, cy = arrow.centerx, arrow.centery
        nudge = int(math.sin(t * 6.0) * 6) if ready else 0
        acol = (236, 236, 236) if ready else (120, 140, 120)
        pygame.draw.rect(w, acol, (cx - 62 + nudge, cy - 16, 70, 32))
        pygame.draw.polygon(w, acol, [(cx + 8 + nudge, cy - 44), (cx + 62 + nudge, cy), (cx + 8 + nudge, cy + 44)])

        # difficulty: shows your club's player for each level
        locked = self.season_running() or rl is not None
        for i, rect in enumerate(diff):
            chosen = i == self.difficulty
            pygame.draw.rect(w, SELECT_GREEN if (chosen or not locked) else (40, 88, 44), rect)
            pygame.draw.rect(w, YELLOW if chosen else (WHITE if not locked else (120, 140, 120)), rect,
                             6 if chosen else 3)
            txt = self.font_s.render(DIFFICULTY[i][0], True, YELLOW if chosen else WHITE)
            head = None
            if head is not None:
                icon = pygame.transform.scale(head, (int(head.get_width() * 42 / head.get_height()), 42))
                w.blit(icon, icon.get_rect(midleft=(rect.x + 14, rect.centery)))
                w.blit(txt, txt.get_rect(midleft=(rect.x + 78, rect.centery)))
            else:
                w.blit(txt, txt.get_rect(center=rect.center))

        # table button
        hover = table_btn.collidepoint(mouse)
        pygame.draw.rect(w, SELECT_GREEN, table_btn)
        pygame.draw.rect(w, YELLOW if hover else WHITE, table_btn, 3)
        txt = self.font_s.render("TABLE", True, YELLOW if hover else WHITE)
        w.blit(txt, txt.get_rect(center=table_btn.center))

        # club badges
        faced_recent = set(self.club_opps[-(CLUB_NO_REPEAT - 1):]) if self.season_running() else set()
        for i, rect in enumerate(badges):
            club = self.clubs[i]
            img = club["badge"]
            out = self.table[i]["out"]
            pos = rect.copy()
            if i == self.club:
                pos.y -= 8
                pygame.draw.rect(w, YELLOW, pos.inflate(20, 20), 6)
            elif rl is not None and i == rl["cur"]:
                flash = rl["landed"] and rl["hold"] < ROULETTE_BLINK and int(rl["hold"] * 8) % 2 == 1
                if not flash:
                    pygame.draw.rect(w, WHITE, pos.inflate(24, 24), 7)
            elif (not self.season_running() and rl is None
                  and pos.inflate(30, 50).move(0, 20).collidepoint(mouse)):
                pygame.draw.rect(w, WHITE, pos.inflate(14, 14), 3)
            if img is not None:
                im = fit_flag(img, rect.w, rect.h)
                if out or i in faced_recent:
                    im = im.copy()
                    im.fill((90, 90, 90) if out else (150, 150, 150), special_flags=pygame.BLEND_RGB_MULT)
                w.blit(im, im.get_rect(center=pos.center))
            if out:
                pygame.draw.line(w, (230, 60, 60), pos.topleft, pos.bottomright, 8)
                pygame.draw.line(w, (230, 60, 60), pos.topright, pos.bottomleft, 8)
            name = self.label(club["code"], rect.w + 50, YELLOW if i == self.club else WHITE)
            w.blit(name, name.get_rect(midtop=(rect.centerx, rect.bottom + 8)))

        if rl is not None and rl["landed"] and int(t * 2.5) % 2 == 0:
            self.centre_text(w, "CLICK TO START", self.font_m, YELLOW, 562)

        # the 12-round bracket, 6 above and 6 below
        for i, box in enumerate(boxes):
            lab = self.label("ROUND %d" % (i + 1), box.w)
            w.blit(lab, lab.get_rect(midbottom=(box.centerx, box.top - 6)))
            pygame.draw.rect(w, SELECT_GREEN, box)
            current = self.club is not None and i == self.club_round and self.club_over is None
            border = YELLOW if (current and int(t * 3) % 2 == 0) else WHITE
            if i < len(self.club_results):
                mg, tg = self.club_results[i]
                border = (120, 230, 120) if mg > tg else (240, 90, 90)
            pygame.draw.rect(w, border, box, 7)
            if i < len(self.club_opps):
                opp = self.clubs[self.club_opps[i]]
            elif i == len(self.club_opps) and rl is not None:
                opp = self.clubs[rl["cur"]]
            else:
                continue
            if opp["badge"] is not None:
                im = fit_flag(opp["badge"], box.w - 120, box.h - 60)
                if i < len(self.club_results):
                    im = im.copy()
                    im.fill((120, 120, 120), special_flags=pygame.BLEND_RGB_MULT)
                w.blit(im, im.get_rect(center=(box.centerx, box.centery - 12)))
            code = self.font_s.render(opp["code"], True, WHITE)
            w.blit(code, code.get_rect(midbottom=(box.centerx, box.bottom - 8)))
            if i < len(self.club_results):
                mg, tg = self.club_results[i]
                sc = "%d-%d" % (mg, tg)
                w.blit(self.font_l.render(sc, True, INK),
                       self.font_l.render(sc, True, INK).get_rect(center=(box.centerx + 4, box.centery - 7)))
                img = self.font_l.render(sc, True, WHITE)
                w.blit(img, img.get_rect(center=(box.centerx, box.centery - 12)))

        if MISSING_SPRITES:
            note = self.font_s.render("MISSING FROM THE SPRITES FOLDER: " + ", ".join(MISSING_SPRITES[:6]),
                                      True, (255, 110, 110))
            if note.get_width() > WIDTH - 40:
                k = (WIDTH - 40) / note.get_width()
                note = pygame.transform.smoothscale(note, (int(note.get_width() * k), int(note.get_height() * k)))
            w.blit(note, note.get_rect(midbottom=(WIDTH // 2, HEIGHT - 4)))

    # ---- drawing: league table -------------------------------
    def draw_table(self, w):
        w.blit(self.select_bg, (0, 0))
        head = "LEAGUE TABLE" + ("  -  AFTER ROUND %d" % self.club_round if self.club_round else "")
        self.centre_text(w, head, self.font_m, WHITE, 14)
        if self.table_msg:
            self.centre_text(w, self.table_msg, self.font_s, YELLOW, 74)

        order = self.standings()
        top, row_h = 124, 42
        cols = {"POS": 70, "CLUB": 200, "P": 900, "W": 990, "D": 1080, "L": 1170, "GD": 1270, "PTS": 1390,
                "ZONE": 1520}
        for name, x in cols.items():
            img = self.font_s.render(name, True, (190, 220, 190))
            w.blit(img, (x, top - 10))
        active = [i for i in order if not self.table[i]["out"]]
        zone = set(active[-RELEGATION_ZONE:]) if len(active) > RELEGATION_ZONE else set()
        for r, i in enumerate(order):
            y = top + 30 + r * row_h
            rec = self.table[i]
            club = self.clubs[i]
            band = pygame.Rect(50, y - 4, WIDTH - 100, row_h - 4)
            if rec["out"]:
                pygame.draw.rect(w, (46, 46, 50), band)
            elif i in zone:
                pygame.draw.rect(w, (110, 34, 38), band)
            elif r % 2:
                pygame.draw.rect(w, (38, 72, 40), band)
            if i == self.club:
                pygame.draw.rect(w, YELLOW, band, 3)
            ink = (140, 140, 140) if rec["out"] else (YELLOW if i == self.club else WHITE)
            pos_txt = "OUT" if rec["out"] else str(r + 1)
            w.blit(self.font_s.render(pos_txt, True, ink), (cols["POS"], y))
            if club["badge"] is not None:
                im = fit_flag(club["badge"], 30, 34)
                w.blit(im, (cols["CLUB"] - 44, y - 2))
            w.blit(self.font_s.render("%s  %s" % (club["code"], club["name"].upper()), True, ink),
                   (cols["CLUB"], y))
            gd = rec["gf"] - rec["ga"]
            for key, val in (("P", rec["p"]), ("W", rec["w"]), ("D", rec.get("d", 0)), ("L", rec["l"]),
                             ("GD", ("+%d" % gd) if gd > 0 else str(gd)), ("PTS", rec["pts"])):
                w.blit(self.font_s.render(str(val), True, ink), (cols[key], y))
            if not rec["out"]:
                for k in range(RELEGATION_STRIKES):
                    c = (240, 70, 70) if k < rec["strikes"] else (70, 90, 70)
                    pygame.draw.circle(w, c, (cols["ZONE"] + 18 + k * 30, y + 14), 10)
            else:
                w.blit(self.font_s.render("ROUND %d" % rec["out_round"], True, ink), (cols["ZONE"], y))

        foot = "BOTTOM 3 FOR 2 ROUNDS IN A ROW = OUT OF THE LEAGUE      CLICK TO CONTINUE"
        img = self.font_s.render(foot, True, (200, 210, 200))
        if img.get_width() > WIDTH - 40:
            k = (WIDTH - 40) / img.get_width()
            img = pygame.transform.smoothscale(img, (int(img.get_width() * k), int(img.get_height() * k)))
        w.blit(img, img.get_rect(midbottom=(WIDTH // 2, HEIGHT - 6)))

    # ================================================================ META GAME
    # ---- save file -------------------------------------------
    def default_save(self):
        return {"coins": 0, "owned": {}, "squad": [], "stamina": {},
                "team": {"name": "MY TEAM", "c1": 6, "c2": 10, "pattern": "PLAIN"},
                "difficulty": 1, "season": None, "starter_opened": False, "xp": 0,
                "training_coins": 0, "puzzle_points": 0, "star_points": 0, "tutorial_done": False,
                "ren_unlocked": False}

    def load_save(self):
        data = self.default_save()
        try:
            loaded = json.loads(read_save_text() or "")
            if isinstance(loaded, dict):
                data.update(loaded)
                if "tutorial_done" not in loaded:
                    data["tutorial_done"] = True           # saves from before the tutorial skip it
        except Exception:
            pass
        self.save = data
        # drop anything that no longer exists in the card list
        self.save["owned"] = {k: v for k, v in self.save["owned"].items() if k in self.cards}
        self.save["squad"] = [k for k in self.save["squad"] if k in self.save["owned"]][:SQUAD_SIZE]
        if not self.save["starter_opened"]:
            self.open_starter_pack()
        self.difficulty = int(self.save.get("difficulty", 1)) % len(DIFFICULTY)
        if not self.save.get("ren_unlocked"):
            self.lock_ren()                                       # earn him, don't get given him
        if self.difficulty == IMPOSSIBLE and self.level() < IMPOSSIBLE_LEVEL:
            self.difficulty = 2
        self.brain.skill = DIFFICULTY[self.difficulty][1]
        self.brain.impossible = self.difficulty == IMPOSSIBLE

    def write_save(self):
        self.save["difficulty"] = self.difficulty
        self.save["season"] = self.season_to_dict()
        try:
            write_save_text(json.dumps(self.save, indent=1))
        except Exception as exc:
            print("[ragdoll_football] could not save:", exc)

    def season_to_dict(self):
        if self.mode != "club" and not getattr(self, "club_round", 0):
            return self.save.get("season")
        return {"round": self.club_round, "opps": self.club_opps, "results": self.club_results,
                "over": self.club_over, "table": {str(k): v for k, v in self.table.items()},
                "started": self.club is not None}

    def restore_season(self):
        s = self.save.get("season")
        self.new_season(None)
        if not s or not s.get("started"):
            return
        try:
            self.club = self.user_idx
            self.club_round = int(s["round"])
            self.club_opps = [int(x) for x in s["opps"]]
            self.club_results = [tuple(r) for r in s["results"]]
            self.club_over = s["over"]
            for k, v in s["table"].items():
                if int(k) in self.table:
                    self.table[int(k)].update(v)
        except Exception:
            self.new_season(None)

    # ---- cards -----------------------------------------------
    def card_head(self, card):
        if card["kind"] in ("sig", "star", "rookie", "no10"):
            return self.sig_looks.get(card["id"], {}).get("head")
        looks = self.looks if card["kind"] == "wc" else self.club_looks
        pieces = looks.get(card["team"] if card["kind"] == "club" else card["team"], {})
        heads = pieces.get("head") or []
        return heads[card["slot"]] if card["slot"] < len(heads) else None

    def card_badge(self, card):
        if card["kind"] == "no10":                         # nation cards: the flag is the badge
            return self.nation_flag(card["nation"])
        if card["kind"] in ("star", "rookie"):
            return self.star_badges.get(card["team"])
        if card["kind"] == "club":
            for c in self.clubs:
                if c["code"] == card["team"]:
                    return c["badge"]
            return None
        for t in self.teams:
            if t["name"] == card["team"]:
                return t["flag"]
        return None

    def card_original_look(self, card):
        if card["kind"] in ("sig", "star", "rookie", "no10"):
            return dict(self.sig_looks.get(card["id"], {})) or None
        looks = self.looks if card["kind"] == "wc" else self.club_looks
        pieces = looks.get(card["team"])
        if not pieces:
            return None
        return {piece: imgs[card["slot"]] for piece, imgs in pieces.items()}

    def team_colours(self):
        t = self.save["team"]
        return (TEAM_PALETTE[t["c1"] % len(TEAM_PALETTE)], TEAM_PALETTE[t["c2"] % len(TEAM_PALETTE)],
                t.get("pattern", "PLAIN"))

    def team_look(self, card):
        """A card's own head + skin in the custom team kit (with its number)."""
        c1, c2, pattern = self.team_colours()
        key = (card["id"], c1, c2, pattern)
        if key in self.kit_cache:
            return self.kit_cache[key]
        orig = self.card_original_look(card) or {}
        skin, boots = (206, 160, 122), (30, 30, 36)
        try:
            arm, leg = orig.get("arm"), orig.get("leg")
            if arm is not None:
                c = arm.get_at((arm.get_width() // 2, int(arm.get_height() * 0.72)))
                skin = (c[0], c[1], c[2])
            if leg is not None:
                c = leg.get_at((leg.get_width() // 2, leg.get_height() - int(leg.get_height() / 12) - 1))
                boots = (c[0], c[1], c[2])
        except Exception:
            pass
        look = {"head": orig.get("head"),
                "torso": paint_torso(c1, c2, pattern, card["number"], (TORSO_W, TORSO_H)),
                "arm": paint_arm(c1, c2, pattern, skin, (ARM_W, ARM_L)),
                "leg": paint_leg(c1, c2, skin, boots, (LEG_W, LEG_L))}
        self.kit_cache[key] = look
        return look

    def refresh_team(self):
        """Rebuild the custom team's badge and league entry after an edit."""
        c1, c2, _ = self.team_colours()
        name = self.save["team"]["name"].strip() or "MY TEAM"
        badge = paint_badge(name, c1, c2, (96, 112))
        code = "".join(ch for ch in name.upper() if ch in FONT3)[:3] or "YOU"
        entry = {"code": code, "name": name, "strength": 75, "badge": badge, "user": True}
        if len(self.clubs) > len(CLUBS):
            self.clubs[self.user_idx] = entry
        else:
            self.clubs.append(entry)
        self.kit_cache = {}

    def card_frame(self, card):
        """(outer, inner, ink, strip) colours for a card's design."""
        if card["design"] == "icon":
            return (226, 186, 72), (250, 246, 234), (60, 44, 10), (190, 150, 50)
        if card["design"] == "wc":
            return (222, 182, 70), (20, 30, 66), WHITE, (12, 18, 44)
        r = card["rating"]
        if r >= 110:
            return (168, 118, 26), (248, 212, 90), INK, (168, 118, 26)
        if r >= 90:
            return (120, 128, 146), (214, 220, 230), INK, (120, 128, 146)
        return (120, 70, 36), (214, 142, 84), INK, (120, 70, 36)

    def nation_colours(self, code):
        if code in self.flag_colour_cache:
            return self.flag_colour_cache[code]
        cols = [(200, 200, 200)] * 3
        for t in self.teams:
            if t["name"] == code and t["flag"] is not None:
                f = t["flag"]
                fw, fh = f.get_size()
                try:
                    cols = [tuple(f.get_at((int(fw * 0.8), int(fh * y)))[:3]) for y in (0.15, 0.5, 0.85)]
                except Exception:
                    pass
        self.flag_colour_cache[code] = cols
        return cols

    # ---- pool A / B cards: pre-drawn backgrounds + portrait + text ------------------
    TPL_SIZE = (400, 500)
    TPL_BODY = (66, 34, 334, 458)                 # where the card itself sits in a template

    def card_template_key(self, card):
        pool = self.card_pool(card)
        if card["design"] == "icon":
            return "icon"
        if card["design"] == "signature":
            return "sig"
        if card["design"] == "prodigy":
            return "prodigy"
        if card["design"] == "starsign":
            return "star"
        if card["design"] == "beginner":
            return "rookie"
        if card["design"] == "no10":                       # only the No. 10 pack uses the three pool looks
            return {"A": "eclipse", "B": "neon", "C": "street"}[pool]
        if pool == "A":
            return ("club_" if card["kind"] == "club" else "nat_") + card["team"]
        return "b"

    def card_template(self, key, w, h):
        """Template scaled so its card body is exactly w x h (cached)."""
        ck = (key, w, h)
        cache = self.__dict__.setdefault("_tpl_cache", {})
        if ck in cache:
            return cache[ck]
        raw = self.__dict__.setdefault("_tpl_raw", {})
        if key not in raw:
            raw[key] = load_pixel("tpl_%s_card" % key, self.TPL_SIZE, quiet=True)
        src = raw[key]
        if src is None:
            cache[ck] = None
            return None
        bx0, by0, bx1, by1 = self.TPL_BODY
        kx, ky = w / (bx1 - bx0), h / (by1 - by0)
        img = pygame.transform.smoothscale(src, (max(1, int(self.TPL_SIZE[0] * kx)),
                                                 max(1, int(self.TPL_SIZE[1] * ky))))
        try:                                              # how bright is the top of the card?
            px = [src.get_at((bx0 + 40 + i * 30, by0 + 60 + i * 20))[:3] for i in range(5)]
            bright = sum(0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2] for p in px) / len(px)
        except Exception:
            bright = 100
        cache[ck] = (img, int(bx0 * kx), int(by0 * ky), bright)
        if len(cache) > 400:
            cache.clear()
        return cache[ck]

    def fit_text(self, text, font, colour, max_w, max_h, outline=None):
        key = ("fit", text, id(font), tuple(colour)[:4], int(max_w), int(max_h),
               tuple(outline)[:4] if outline else None)
        hit = self.text_cache.get(key)
        if hit is not None:
            return hit
        img = self.outlined(text, font, colour, 1.0, outline, 3) if outline else font.render(text, True, colour)
        k = min(max_w / max(1, img.get_width()), max_h / max(1, img.get_height()))
        out = pygame.transform.smoothscale(img, (max(1, int(img.get_width() * k)), max(1, int(img.get_height() * k))))
        self.cache_text(key, out)
        return out

    def cache_text(self, key, surf):
        if len(self.text_cache) >= 1500:
            self.text_cache.clear()
        self.text_cache[key] = surf

    # pool A = ECLIPSE (black/purple), pool B = NEON PLAYMAKER (navy/cyan), pool C = STREET (concrete)
    POOL_DESIGNS = {"eclipse": {"accent": (214, 170, 255), "num": (150, 70, 240), "edge": (236, 214, 255),
                                "size": 0.66, "alpha": 170, "at": (0.5, 0.42)},
                    "neon": {"accent": (120, 235, 255), "num": (40, 200, 255), "edge": (200, 250, 255),
                             "size": 0.5, "alpha": 110, "at": (0.5, 0.40)},
                    "street": {"accent": (196, 204, 186), "num": (150, 160, 142), "edge": (60, 70, 60),
                               "size": 0.14, "alpha": 190, "at": (0.84, 0.13)}}

    def draw_ability_pips(self, surf, card, rect):
        """Little tier diamonds in the card's top-right corner."""
        abilities = ability_list(card)
        if not abilities or rect.w < 90:
            return
        r = max(4, int(rect.w * 0.030))
        for i, (_ab, tier) in enumerate(abilities):
            cx = rect.right - int(rect.w * 0.07) - i * int(r * 2.6)
            cy = rect.y + int(rect.h * 0.052)
            pts = [(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)]
            pygame.draw.polygon(surf, ABILITY_TIERS[tier][1], pts)
            pygame.draw.polygon(surf, (12, 12, 20), pts, max(1, r // 3))

    def draw_big_number(self, surf, card, rect, key):
        """The giant shirt number behind the player (small and flat on Street cards)."""
        d = self.POOL_DESIGNS[key]
        h = max(6, int(rect.h * d["size"]))
        img = self.font_xl.render(str(card["number"]), True, d["num"])
        k = h / max(1, img.get_height())
        img = pygame.transform.smoothscale(img, (max(1, int(img.get_width() * k)), h))
        edge = self.font_xl.render(str(card["number"]), True, d["edge"])
        edge = pygame.transform.smoothscale(edge, img.get_size())
        big = pygame.Surface((img.get_width() + 8, img.get_height() + 8), pygame.SRCALPHA)
        for dx, dy in ((0, 4), (4, 0), (8, 4), (4, 8)):
            big.blit(edge, (dx, dy))
        big.blit(img, (4, 4))
        big.set_alpha(d["alpha"])
        surf.blit(big, big.get_rect(center=(rect.x + int(rect.w * d["at"][0]), rect.y + int(rect.h * d["at"][1]))))

    def draw_pool_card(self, surf, card, rect, count=0, stamina=None, dim=False, glow=False):
        key = self.card_template_key(card)
        tpl = self.card_template(key, rect.w, rect.h)
        t = pygame.time.get_ticks() * 0.001
        if glow:
            pulse = int(10 + 6 * (0.5 + 0.5 * math.sin(t * 3)))
            pygame.draw.rect(surf, YELLOW, rect.inflate(pulse, pulse), border_radius=16)
        if tpl is None:                                    # art missing: plain gold card
            pygame.draw.rect(surf, (226, 186, 72), rect, border_radius=14)
        else:
            img, ox, oy, _b = tpl
            surf.blit(img, (rect.x - ox, rect.y - oy))
        W, H = rect.w, rect.h
        pool_key = key in self.POOL_DESIGNS
        light = not pool_key and (key == "b" or (tpl is not None and tpl[3] > 165
                                                and key not in ("sig", "prodigy")))
        ink = (20, 28, 76) if light else WHITE
        gold = (150, 104, 14) if light else (246, 206, 100)
        if pool_key:
            gold = self.POOL_DESIGNS[key]["accent"]
            self.draw_big_number(surf, card, rect, key)    # the giant shirt number behind the player
        # faded crest / flag behind the player on club + nation cards
        badge = self.card_badge(card)
        if key.startswith(("club_", "nat_")) and badge is not None:
            ghost = fit_flag(badge, int(W * 0.62), int(H * 0.36)).copy()
            ghost.set_alpha(70)
            surf.blit(ghost, ghost.get_rect(center=(rect.x + int(W * 0.62), rect.y + int(H * 0.25))))
        # portrait
        face = self.card_faces.get(card["id"])
        if face is not None:
            fw = int(W * 0.86)
            img = scaled(face, (fw, fw))
            surf.blit(img, img.get_rect(midbottom=(rect.x + W // 2 + int(W * 0.09), rect.y + int(H * 0.715))))
        else:
            head = self.card_head(card)
            if head is not None:
                hh = fit_flag(head, int(W * 0.5), int(W * 0.5))
                surf.blit(hh, hh.get_rect(center=(rect.centerx, rect.y + int(H * 0.42))))
        # rating + position (+ the nation flag beside the rating on the pool designs)
        num = self.fit_text(str(card["rating"]), self.font_xl, ink, W * 0.38, H * 0.11,
                            (250, 250, 252) if light else (10, 14, 30))
        surf.blit(num, (rect.x + int(W * 0.06), rect.y + int(H * 0.03)))
        pos = self.fit_text(card["pos"], self.font_m, gold, W * 0.3, H * 0.065)
        surf.blit(pos, (rect.x + int(W * 0.075), rect.y + int(H * 0.035) + num.get_height()))
        if pool_key:
            flag = self.card_flag(card)
            if flag is not None:
                fl = fit_flag(flag, int(W * 0.17), int(H * 0.07))
                surf.blit(fl, fl.get_rect(midleft=(rect.x + int(W * 0.06) + num.get_width() + int(W * 0.03),
                                                   rect.y + int(H * 0.03) + num.get_height() // 2)))
        if key == "prodigy":                               # PRODIGY ribbon
            rib = pygame.Rect(0, 0, int(W * 0.46), int(H * 0.055))
            rib.midtop = (rect.centerx, rect.y + int(H * 0.005))
            pygame.draw.rect(surf, CYAN, rib, border_radius=6)
            lab = self.fit_text("PRODIGY", self.font_s, (8, 20, 30), rib.w * 0.8, rib.h * 0.8)
            surf.blit(lab, lab.get_rect(center=rib.center))
        if key == "sig":                                   # SIGNATURE ribbon + gold autograph
            rib = pygame.Rect(0, 0, int(W * 0.5), int(H * 0.06))
            rib.midtop = (rect.centerx, rect.y - int(H * 0.035))
            pygame.draw.rect(surf, (236, 196, 90), rib, border_radius=6)
            lab = self.fit_text("SIGNATURE", self.font_s, (60, 40, 8), rib.w * 0.86, rib.h * 0.8)
            surf.blit(lab, lab.get_rect(center=rib.center))
            pts = []
            x0, y0 = rect.x + int(W * 0.18), rect.y + int(H * 0.66)
            for i in range(40):
                tt = i / 39.0
                pts.append((x0 + tt * W * 0.62, y0 + math.sin(tt * 13.0) * H * 0.02 * (1 - tt * 0.5) - tt * H * 0.035))
            pygame.draw.lines(surf, (255, 230, 130), False, pts, max(2, int(W / 90)))
        # name in the band
        name = card["name"].upper()
        if len(name) > 13 and " " in name:
            name = name.split()[-1]
        name_col = (70, 44, 8) if key == "icon" else WHITE
        nm = self.fit_text(name, self.font_m, name_col, W * 0.86, H * 0.075)
        surf.blit(nm, nm.get_rect(center=(rect.centerx, rect.y + int(H * 0.775))))
        # flag / crest row
        row_y = rect.y + int(H * 0.87)
        flag = self.card_flag(card)
        items = [] if pool_key else ([flag] if flag is not None else [])
        if card["kind"] == "club" and badge is not None:
            items.append(badge)
        n = len(items)
        for i, im in enumerate(items):
            b = fit_flag(im, int(W * 0.17), int(H * 0.07))
            cx = rect.centerx + int((i - (n - 1) / 2) * W * 0.24)
            surf.blit(b, b.get_rect(center=(cx, row_y)))
        if n == 2:
            pygame.draw.line(surf, gold, (rect.centerx, row_y - int(H * 0.03)), (rect.centerx, row_y + int(H * 0.03)),
                             max(1, int(W / 140)))
        # shirt number on the gold plate (club / nation designs)
        if key.startswith(("club_", "nat_", "sig")):
            nb = self.fit_text(str(card["number"]), self.font_m, (90, 60, 10), W * 0.14, H * 0.05)
            surf.blit(nb, nb.get_rect(center=(rect.centerx, rect.y + int(H * 1.014))))
        self.card_overlays(surf, rect, count, stamina, dim, card)

    def draw_icon_card(self, surf, card, rect, count=0, stamina=None, dim=False, glow=False):
        """Big detailed icon card: gold shard frame, portrait, rating, name bar."""
        k = rect.w / 300.0
        t = pygame.time.get_ticks() * 0.001
        sig = card["design"] == "signature"
        gold, deep, navy = (236, 198, 96), (150, 112, 30), ((0, 110, 52) if sig else (18, 26, 62))
        pulse = int(10 + 8 * (0.5 + 0.5 * math.sin(t * 3)))
        aura = glow_blob((rect.w + 120, rect.h + 120), (255, 226, 140), 55 if not glow else 95)
        surf.blit(aura, aura.get_rect(center=rect.center))
        if glow:
            pygame.draw.rect(surf, YELLOW, rect.inflate(pulse, pulse), border_radius=int(18 * k))
        # frame
        pygame.draw.rect(surf, deep, rect, border_radius=int(14 * k))
        pygame.draw.rect(surf, gold, rect.inflate(int(-6 * k), int(-6 * k)), border_radius=int(12 * k))
        inner = rect.inflate(int(-24 * k), int(-24 * k))
        pygame.draw.rect(surf, navy, inner, border_radius=int(8 * k))
        # shattered-glass backdrop inside the card
        rng = random.Random(hash(card["id"]) & 0xffff)
        clip = surf.get_clip()
        surf.set_clip(inner)
        if sig:                                              # Brazil flag behind the player
            cx, cy = inner.centerx, inner.y + int(inner.h * 0.42)
            dw, dh = int(inner.w * 0.62), int(inner.h * 0.36)
            pygame.draw.polygon(surf, (236, 200, 30), [(cx - dw, cy), (cx, cy - dh), (cx + dw, cy), (cx, cy + dh)])
            pygame.draw.circle(surf, (24, 46, 130), (cx, cy), int(dh * 0.62))
            pygame.draw.arc(surf, WHITE, pygame.Rect(cx - dh, cy - int(dh * 0.35), dh * 2, dh * 2), 1.05, 2.1,
                            max(2, int(4 * k)))
        for _ in range(0 if sig else 16):
            x = inner.x + rng.random() * inner.w
            y = inner.y + rng.random() * inner.h * 0.8
            s = (18 + rng.random() * 60) * k
            a = rng.uniform(0, math.tau)
            pts = [(x + math.cos(a + j * 2.1) * s * (0.5 + 0.5 * rng.random()),
                    y + math.sin(a + j * 2.1) * s * (0.5 + 0.5 * rng.random())) for j in range(4)]
            shade = rng.random()
            col = _shade((34, 48, 110), 0.7 + shade * 0.9) if shade < 0.75 else _shade(gold, 0.55)
            pygame.draw.polygon(surf, col, pts)
        for j in range(0 if sig else 4):                     # gold rays behind the player
            x0 = inner.x + int(inner.w * (0.12 + j * 0.26))
            pygame.draw.polygon(surf, _shade(gold, 0.45),
                                [(x0, inner.bottom), (x0 + int(40 * k), inner.y),
                                 (x0 + int(64 * k), inner.y), (x0 + int(28 * k), inner.bottom)])
        surf.set_clip(clip)
        # portrait
        face = self.icon_faces.get(card["id"])
        if face is not None:
            fh = int(inner.h * 0.58)
            fw = int(fh * face.get_width() / face.get_height())
            img = pygame.transform.scale(face, (max(1, fw), max(1, fh)))
            surf.blit(img, img.get_rect(midbottom=(inner.centerx + int(14 * k), inner.bottom - int(98 * k))))
        else:
            head = self.card_head(card)
            if head is not None:
                hh = fit_flag(head, int(150 * k), int(150 * k))
                surf.blit(hh, hh.get_rect(center=(inner.centerx, inner.y + int(150 * k))))
        # rating + position, top left, FC Mobile style
        rt = self.font_xl if k > 0.75 else self.font_l
        num = rt.render(str(card["rating"]), True, WHITE)
        sc = (56 * k) / num.get_height()
        num = pygame.transform.smoothscale(num, (max(1, int(num.get_width() * sc)), max(1, int(56 * k))))
        shadow = num.copy()
        shadow.fill((0, 0, 0), special_flags=getattr(pygame, "BLEND_RGB_MULT", 0))
        surf.blit(shadow, (inner.x + int(16 * k) + 3, inner.y + int(18 * k) + 3))
        surf.blit(num, (inner.x + int(16 * k), inner.y + int(18 * k)))
        pos = self.font_m.render(card["pos"], True, gold)
        sc = (30 * k) / pos.get_height()
        pos = pygame.transform.smoothscale(pos, (max(1, int(pos.get_width() * sc)), max(1, int(30 * k))))
        surf.blit(pos, (inner.x + int(18 * k), inner.y + int(80 * k)))
        pygame.draw.line(surf, gold, (inner.x + int(16 * k), inner.y + int(116 * k)),
                         (inner.x + int(16 * k) + pos.get_width(), inner.y + int(116 * k)), max(2, int(3 * k)))
        # ICON banner top right
        rib = pygame.Rect(0, 0, int((130 if sig else 80) * k), int(28 * k))
        rib.topright = (inner.right - int(14 * k), inner.y + int(16 * k))
        if sig:                                              # ribbon on the top edge of the frame
            rib.midtop = (rect.centerx, rect.y + int(2 * k))
        pygame.draw.polygon(surf, gold, [(rib.x, rib.y), (rib.right, rib.y),
                                         (rib.right, rib.bottom), (rib.x + int(14 * k), rib.bottom)])
        lab = self.font_s.render("SIGNATURE" if sig else "ICON", True, (40, 30, 8))
        sc = (rib.h * 0.66) / lab.get_height()
        lab = pygame.transform.smoothscale(lab, (max(1, int(lab.get_width() * sc)), max(1, int(rib.h * 0.66))))
        surf.blit(lab, lab.get_rect(center=(rib.centerx + int(4 * k), rib.centery)))
        if sig:                                              # gold autograph across the shirt
            pts = []
            x0, y0 = inner.x + int(inner.w * 0.2), inner.bottom - int(104 * k)
            for i in range(40):
                tt = i / 39.0
                pts.append((x0 + tt * inner.w * 0.6, y0 + math.sin(tt * 13.0) * 8 * k * (1 - tt * 0.5) - tt * 14 * k))
            pygame.draw.lines(surf, (255, 230, 130), False, pts, max(2, int(3 * k)))
        # name bar
        bar = pygame.Rect(inner.x, inner.bottom - int(92 * k), inner.w, int(40 * k))
        surf.blit(tint((bar.w, bar.h), (8, 12, 30, 210)), bar.topleft)
        pygame.draw.line(surf, gold, bar.topleft, bar.topright, max(2, int(2 * k)))
        pygame.draw.line(surf, gold, bar.bottomleft, bar.bottomright, max(2, int(2 * k)))
        nm = self.label(card["name"].upper(), bar.w - int(16 * k), gold)
        if nm.get_height() > bar.h * 0.8:
            s2 = bar.h * 0.8 / nm.get_height()
            nm = pygame.transform.smoothscale(nm, (max(1, int(nm.get_width() * s2)), max(1, int(bar.h * 0.8))))
        surf.blit(nm, nm.get_rect(center=bar.center))
        # crest + team row
        badge = self.card_badge(card)
        row_y = bar.bottom + int(24 * k)
        name_txt = self.team_name(card)
        nat = self.font_s.render(name_txt[:14], True, gold)
        sc2 = (20 * k) / nat.get_height()
        nat = pygame.transform.smoothscale(nat, (max(1, int(nat.get_width() * sc2)), max(1, int(20 * k))))
        crest_w = int(54 * k) if badge is not None else 0
        total = crest_w + int(10 * k) + nat.get_width()
        x = inner.centerx - total // 2
        if badge is not None:
            bimg = fit_flag(badge, crest_w, int(38 * k))
            surf.blit(bimg, bimg.get_rect(center=(x + crest_w // 2, row_y)))
            x += crest_w + int(10 * k)
            pygame.draw.line(surf, gold, (x - int(5 * k), row_y - int(14 * k)),
                             (x - int(5 * k), row_y + int(14 * k)), max(1, int(2 * k)))
        surf.blit(nat, nat.get_rect(midleft=(x, row_y)))
        # gem at the bottom
        gx, gy, gs = inner.centerx, inner.bottom - int(14 * k), int(13 * k)
        pygame.draw.polygon(surf, (150, 230, 255),
                            [(gx, gy - gs), (gx + gs, gy), (gx, gy + gs), (gx - gs, gy)])
        pygame.draw.polygon(surf, WHITE, [(gx, gy - gs), (gx + gs, gy), (gx, gy + gs), (gx - gs, gy)],
                            max(1, int(2 * k)))
        # shine sweep
        surf.blit(shine_sweep((inner.w, inner.h)), inner.topleft)
        if count > 1:
            c = self.font_s.render("x%d" % count, True, WHITE)
            pygame.draw.circle(surf, (200, 40, 40), (rect.right - 8, rect.bottom - 8), 24)
            surf.blit(c, c.get_rect(center=(rect.right - 8, rect.bottom - 8)))
        if stamina is not None:
            b2 = pygame.Rect(rect.x, rect.bottom + 8, rect.w, 16)
            pygame.draw.rect(surf, (30, 30, 30), b2)
            col = (90, 220, 90) if stamina > 50 else ((240, 200, 60) if stamina > 0 else (220, 60, 60))
            pygame.draw.rect(surf, col, (b2.x, b2.y, int(b2.w * stamina / 100), b2.h))
            pygame.draw.rect(surf, WHITE, b2, 2)
        if dim:
            surf.blit(tint((rect.w, rect.h), (0, 0, 0, 150)), rect.topleft)

    def draw_card(self, surf, card, rect, count=0, stamina=None, dim=False, glow=False):
        if card["design"] in ("starsign", "beginner"):
            return self.draw_star_card(surf, card, rect, count, stamina, dim, glow)
        if card["design"] == "no10" or self.card_pool(card) in ("A", "B"):
            return self.draw_pool_card(surf, card, rect, count, stamina, dim, glow)
        return self.draw_plain_card(surf, card, rect, count, stamina, dim, glow)

    def draw_plain_card(self, surf, card, rect, count=0, stamina=None, dim=False, glow=False):
        """Pool C: the simple bronze / silver / gold card."""
        outer, inner_c, ink, strip_c = self.card_frame(card)
        design = card["design"]
        t = pygame.time.get_ticks() * 0.001
        if design == "icon":                                  # pulsing glow
            g = int(8 + 6 * (0.5 + 0.5 * math.sin(t * 3)))
            pygame.draw.rect(surf, (255, 236, 150), rect.inflate(g, g), border_radius=20)
        if glow:
            pygame.draw.rect(surf, YELLOW, rect.inflate(16, 16), border_radius=18)
        pygame.draw.rect(surf, outer, rect, border_radius=14)
        inner = rect.inflate(-10, -10)
        pygame.draw.rect(surf, inner_c, inner, border_radius=10)
        k = rect.w / 180.0
        if design == "icon":                                  # marble streaks + ribbon
            for j in range(5):
                y0 = inner.y + int((0.15 + j * 0.2) * inner.h)
                pygame.draw.line(surf, (226, 222, 210), (inner.x, y0), (inner.right, y0 - int(40 * k)), 3)
            rib = pygame.Rect(0, 0, int(90 * k), int(26 * k))
            rib.midtop = (rect.centerx, rect.y - int(6 * k))
            pygame.draw.rect(surf, (200, 150, 40), rib, border_radius=6)
            txt = self.font_s.render("ICON", True, WHITE)
            txt = pygame.transform.smoothscale(txt, (int(rib.h * txt.get_width() / txt.get_height() * 0.9),
                                                     int(rib.h * 0.9)))
            surf.blit(txt, txt.get_rect(center=rib.center))
        elif design == "wc":                                  # nation band + trophy
            cols = self.nation_colours(card["team"])
            bh = max(3, int(12 * k))
            for j, c in enumerate(cols):
                y0 = inner.y + int(inner.h * 0.58) + j * bh
                pygame.draw.polygon(surf, c, [(inner.x, y0 + int(30 * k)), (inner.right, y0 - int(30 * k)),
                                              (inner.right, y0 - int(30 * k) + bh), (inner.x, y0 + int(30 * k) + bh)])
            tx, ty = inner.x + int(14 * k), inner.bottom - int(78 * k)
            gold = (236, 196, 70)
            pygame.draw.rect(surf, gold, (tx, ty, int(16 * k), int(12 * k)))           # cup
            pygame.draw.rect(surf, gold, (tx + int(6 * k), ty + int(12 * k), int(4 * k), int(6 * k)))
            pygame.draw.rect(surf, gold, (tx + int(2 * k), ty + int(18 * k), int(12 * k), int(4 * k)))
        # diagonal shine
        shine = pygame.Surface((inner.w, inner.h), pygame.SRCALPHA)
        pygame.draw.polygon(shine, (255, 255, 255, 50),
                            [(inner.w * 0.55, 0), (inner.w * 0.8, 0), (inner.w * 0.25, inner.h), (0, inner.h)])
        surf.blit(shine, inner.topleft)
        f_big = self.font_m if k > 0.8 else self.font_s
        rt = f_big.render(str(card["rating"]), True, ink)
        surf.blit(rt, (inner.x + int(10 * k), inner.y + int(8 * k)))
        pos = self.font_s.render(card["pos"], True, ink)
        if k < 0.8:
            pos = pygame.transform.smoothscale(pos, (int(pos.get_width() * 0.75), int(pos.get_height() * 0.75)))
        surf.blit(pos, (inner.x + int(12 * k), inner.y + int(8 * k) + rt.get_height() - 4))
        badge = self.card_badge(card)
        if badge is not None:
            b = fit_flag(badge, int(46 * k), int(40 * k))
            surf.blit(b, b.get_rect(topright=(inner.right - int(8 * k), inner.y + int(12 * k))))
        head = self.card_head(card)
        if head is not None:
            hh = fit_flag(head, int(104 * k), int(104 * k))
            surf.blit(hh, hh.get_rect(center=(rect.centerx, rect.y + int(128 * k))))
        strip = pygame.Rect(inner.x, inner.bottom - int(52 * k), inner.w, int(40 * k))
        pygame.draw.rect(surf, strip_c, strip)
        nm = self.label(card["name"].split()[-1].upper() if len(card["name"]) > 12 else card["name"].upper(),
                        strip.w - 10)
        if nm.get_height() > strip.h:
            sc = strip.h / nm.get_height()
            nm = pygame.transform.smoothscale(nm, (int(nm.get_width() * sc), int(nm.get_height() * sc)))
        surf.blit(nm, nm.get_rect(center=strip.center))
        if count > 1:
            c = self.font_s.render("x%d" % count, True, WHITE)
            pygame.draw.circle(surf, (200, 40, 40), (rect.right - 8, rect.bottom - 8), 24)
            surf.blit(c, c.get_rect(center=(rect.right - 8, rect.bottom - 8)))
        if stamina is not None:
            bar = pygame.Rect(rect.x, rect.bottom + 8, rect.w, 16)
            pygame.draw.rect(surf, (30, 30, 30), bar)
            col = (90, 220, 90) if stamina > 50 else ((240, 200, 60) if stamina > 0 else (220, 60, 60))
            pygame.draw.rect(surf, col, (bar.x, bar.y, int(bar.w * stamina / 100), bar.h))
            pygame.draw.rect(surf, WHITE, bar, 2)
        if dim:
            surf.blit(tint((rect.w, rect.h), (0, 0, 0, 150)), rect.topleft)

    # ---- double-click a card to see its stats ------------------------
    def card_click(self, card, action):
        """Single click runs `action` after a short wait; a second click on the
        same card inside that wait opens the stats view instead."""
        now = pygame.time.get_ticks() / 1000.0
        p = self.pending_click
        if p is not None and p[1] == card["id"] and now - p[0] < DOUBLE_CLICK:
            self.pending_click = None
            self.card_detail = card
            return
        if p is not None:
            p[2]()
        self.pending_click = (now, card["id"], action)

    def process_pending(self):
        p = self.pending_click
        if p is not None and pygame.time.get_ticks() / 1000.0 - p[0] >= DOUBLE_CLICK:
            self.pending_click = None
            p[2]()

    def team_name(self, card):
        if card["kind"] == "no10":
            return NATION_NAMES.get(card["nation"], card["nation"])
        if card["kind"] in ("star", "rookie"):
            return "%s  -  %s" % (NATION_NAMES.get(card["nation"], card["nation"]),
                                  STAR_CLUB_NAMES.get(card["team"], card["team"]).upper())
        if card["kind"] == "club":
            for code, name, _s, _p in CLUBS:
                if code == card["team"]:
                    return name.upper()
            return card["team"]
        return NATION_NAMES.get(card["team"], card["team"])

    def draw_card_detail(self, w):
        card = self.card_detail
        wash(w, (6, 10, 8, 215))
        big = pygame.Rect(260, 230, 380, 530)
        self.draw_card(w, card, big)
        x = 740
        w.blit(self.font_l.render(card["name"].upper(), True, WHITE), (x, 210))
        sub = "%s  -  %s  -  #%d" % (self.team_name(card), card["pos"], card["number"])
        w.blit(self.font_s.render(sub, True, (200, 220, 200)), (x, 320))
        if card["design"] == "icon":
            w.blit(self.font_s.render("ICON", True, (255, 220, 120)), (x, 370))
        elif card["design"] == "signature":
            w.blit(self.font_s.render("SIGNATURE CARD", True, (140, 255, 160)), (x, 370))
        elif card["design"] == "wc":
            w.blit(self.font_s.render("WORLD CUP CARD", True, (255, 220, 120)), (x, 370))
        elif card["design"] == "starsign":
            w.blit(self.font_s.render("STAR SIGNING ELITE  -  CAN'T BE EXCHANGED", True, STAR_LILAC), (x, 370))
        elif card["design"] == "beginner":
            w.blit(self.font_s.render("BEGINNER CARD", True, ROOKIE_MINT), (x, 370))
        for i, (label, val, what) in enumerate((
                ("OVR", card["rating"], "hit power"),
                ("SHO", card["sho"], "aim - low = shaky arrow"),
                ("STR", card["str"], "longer drag + knocks players further"))):
            y = 420 + i * 86
            w.blit(self.font_m.render(label, True, WHITE), (x, y))
            bar = pygame.Rect(x + 150, y + 12, 600, 34)
            pygame.draw.rect(w, (30, 40, 32), bar)
            frac = clamp(val / 150.0, 0.0, 1.0)
            col = (90, 220, 90) if val >= 120 else ((240, 200, 60) if val >= 90 else (230, 120, 60))
            pygame.draw.rect(w, col, (bar.x, bar.y, int(bar.w * frac), bar.h))
            pygame.draw.rect(w, WHITE, bar, 2)
            w.blit(self.font_m.render(str(val), True, WHITE), (bar.right + 20, y))
            w.blit(self.font_s.render(what, True, (170, 190, 170)), (x + 150, y + 50))
        abilities = ability_list(card)
        top = 786
        if not abilities:
            w.blit(self.font_s.render("ABILITIES:  OVER 100 OVR ONLY", True, (160, 160, 175)), (x, top + 6))
        for i, (ab, tier) in enumerate(abilities):
            y = top + i * 56
            name, col, _k = ABILITY_TIERS[tier]
            chip = pygame.Rect(x, y, 180, 44)
            pygame.draw.rect(w, col, chip, border_radius=10)
            lab = self.fit_text(name, self.font_s, (16, 16, 22), chip.w - 16, 28)
            w.blit(lab, lab.get_rect(center=chip.center))
            cat, ccol = ABILITY_CATS[ab["cat"]]
            nm = self.fit_text(ab["name"], self.font_m, ccol, 380, 40)
            w.blit(nm, nm.get_rect(midleft=(x + 210, chip.centery)))
            txt = self.fit_text(ab["text"], self.font_s, (206, 212, 226), 560, 28)
            w.blit(txt, txt.get_rect(midleft=(x + 610, chip.centery)))
        # description, word-wrapped
        words, line, y = card["desc"].split(), "", 700
        for word in words + [None]:
            test = (line + " " + word).strip() if word else line
            if word is None or self.font_s.size(test)[0] > 1000:
                w.blit(self.font_s.render(line, True, WHITE), (x, y))
                y += 44
                line = word or ""
            else:
                line = test
        self.centre_text(w, "CLICK ANYWHERE TO CLOSE", self.font_s, (200, 220, 200), 1032)

    # ---- packs -------------------------------------------------
    # ---- Ren Aoyagi: the one card you have to earn ----------
    def ren_unlocked(self):
        return bool(self.save.get("ren_unlocked"))

    def lock_ren(self):
        """He never sits in a save that hasn't beaten Impossible with Japan."""
        self.save["owned"].pop(REN_CARD, None)
        self.save["stamina"].pop(REN_CARD, None)
        self.save["squad"] = [k for k in self.save["squad"] if k != REN_CARD]

    def ren_unlock_ready(self, result):
        """True the moment the Japan Impossible World Cup is won."""
        return (result == "win" and self.mode == "wc" and self.difficulty == IMPOSSIBLE
                and self.run_impossible                   # no dropping the difficulty mid-run
                and self.team is not None and self.teams
                and self.teams[self.team]["name"] == REN_UNLOCK_TEAM
                and self.round + 1 >= len(ROUNDS) and not self.ren_unlocked())

    def unlock_ren(self):
        if self.ren_unlocked() or REN_CARD not in self.cards:
            return False
        self.save["ren_unlocked"] = True
        self.give_card(self.cards[REN_CARD])
        self.toast("REN AOYAGI (187) UNLOCKED", CYAN)
        if len(self.save["squad"]) < SQUAD_SIZE:
            self.save["squad"].append(REN_CARD)
        self.write_save()
        return True

    def reveal_ren(self):
        """His card walks out over the CHAMPIONS screen."""
        card = self.cards[REN_CARD]
        self.pack_reveal = {"card": card, "t": 0.0, "count": self.save["owned"].get(REN_CARD, 1),
                            "pack": 0, "tier": "A", "opened": True, "back": "ren",
                            "art": self.pack_art[0]}
        self.fx = []
        self.state = PACK_OPEN
        self.sfx.play_track("pack", force=True)

    def give_card(self, card):
        owned = self.save["owned"]
        owned[card["id"]] = owned.get(card["id"], 0) + 1
        self.save["stamina"].setdefault(card["id"], 100)
        return owned[card["id"]]

    def open_starter_pack(self):
        pool = [c for c in self.cards.values() if c["kind"] == "club"]
        picked = []
        for tier in STARTER_TIERS:
            options = [c for c in pool if c["tier"] == tier and c not in picked]
            card = random.choice(options)
            picked.append(card)
            self.give_card(card)
        self.save["squad"] = [c["id"] for c in picked]
        self.save["starter_opened"] = True
        self.starter_cards = picked

    def draw_back_button(self, w):
        r = pygame.Rect(40, 30, 200, 70)
        hover = r.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(w, SELECT_GREEN, r)
        pygame.draw.rect(w, YELLOW if hover else WHITE, r, 4)
        t = self.font_s.render("< BACK", True, YELLOW if hover else WHITE)
        w.blit(t, t.get_rect(center=r.center))
        return r

    def draw_coins(self, w):
        t = self.font_m.render("%d COINS" % self.save["coins"], True, YELLOW)
        pygame.draw.circle(w, YELLOW, (WIDTH - 60 - t.get_width() - 30, 64), 20)
        pygame.draw.circle(w, (190, 140, 20), (WIDTH - 60 - t.get_width() - 30, 64), 20, 4)
        w.blit(t, (WIDTH - 60 - t.get_width(), 40))

    def burst_fireworks(self, x, y, colour, n=40):
        for _ in range(max(6, int(n * FX_SCALE))):
            a = random.uniform(0, math.tau)
            sp = random.uniform(150, 520)
            self.fx.append([x, y, math.cos(a) * sp, math.sin(a) * sp,
                            random.uniform(0.8, 1.5), colour])
        if len(self.fx) > FX_CAP:                      # the oldest ones go, nobody notices
            del self.fx[:len(self.fx) - FX_CAP]

    def draw_fx(self, w, dt):
        alive = []
        for p in self.fx:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += 380 * dt
            p[4] -= dt
            if p[4] > 0:
                alive.append(p)
                pygame.draw.rect(w, p[5], (int(p[0]), int(p[1]), 9, 9))
        self.fx = alive

    # ---- My Club: team editor + squad ---------------------------
    def myclub_layout(self):
        L = {}
        L["name"] = pygame.Rect(60, 170, 680, 80)
        L["c1"] = [pygame.Rect(60 + i * 48, 330, 42, 42) for i in range(len(TEAM_PALETTE))]
        L["c2"] = [pygame.Rect(60 + i * 48, 440, 42, 42) for i in range(len(TEAM_PALETTE))]
        L["pattern"] = [pygame.Rect(60 + i * 172, 550, 160, 56) for i in range(len(PATTERNS))]
        L["squad"] = [pygame.Rect(830 + i * 205, 150, 180, 250) for i in range(SQUAD_SIZE)]
        L["coll"] = [pygame.Rect(830 + (i % 7) * 148, 520 + (i // 7) * 222, 130, 180) for i in range(14)]
        L["prev"] = pygame.Rect(830, 980, 120, 60)
        L["tutorial"] = pygame.Rect(60, 972, 320, 70)
        L["next"] = pygame.Rect(1760, 980, 120, 60)
        return L

    def owned_cards(self):
        cards = [self.cards[k] for k in self.save["owned"]]
        return sorted(cards, key=lambda c: (-c["rating"], c["name"]))

    def myclub_click(self, pos):
        L = self.myclub_layout()
        if pygame.Rect(40, 30, 200, 70).collidepoint(pos.x, pos.y):
            self.editing_name = False
            self.refresh_team()
            self.write_save()
            self.state = TITLE
            return
        if L["tutorial"].collidepoint(pos.x, pos.y):
            self.editing_name = False
            self.refresh_team()
            self.write_save()
            self.start_tutorial(replay=True)
            return
        self.editing_name = L["name"].collidepoint(pos.x, pos.y)
        t = self.save["team"]
        for i, r in enumerate(L["c1"]):
            if r.collidepoint(pos.x, pos.y):
                t["c1"] = i
        for i, r in enumerate(L["c2"]):
            if r.collidepoint(pos.x, pos.y):
                t["c2"] = i
        for i, r in enumerate(L["pattern"]):
            if r.collidepoint(pos.x, pos.y):
                t["pattern"] = PATTERNS[i]
        locked = self.season_running()
        squad = self.save["squad"]

        def toggle(cid):
            def run():
                if locked:
                    return
                if cid in squad:
                    squad.remove(cid)
                elif len(squad) < SQUAD_SIZE:
                    squad.append(cid)
                self.refresh_team()
                self.write_save()
            return run
        for i, r in enumerate(L["squad"]):
            if r.collidepoint(pos.x, pos.y) and i < len(squad):
                self.card_click(self.cards[squad[i]], toggle(squad[i]))
        owned = self.owned_cards()
        page = owned[self.coll_page * 14:(self.coll_page + 1) * 14]
        for i, r in enumerate(L["coll"]):
            if r.collidepoint(pos.x, pos.y) and i < len(page):
                self.card_click(page[i], toggle(page[i]["id"]))
        pages = max(1, math.ceil(len(owned) / 14))
        if L["prev"].collidepoint(pos.x, pos.y):
            self.coll_page = (self.coll_page - 1) % pages
        if L["next"].collidepoint(pos.x, pos.y):
            self.coll_page = (self.coll_page + 1) % pages
        self.refresh_team()
        self.write_save()

    def myclub_key(self, event):
        t = self.save["team"]
        if event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
            self.editing_name = False
        elif event.key == pygame.K_BACKSPACE:
            t["name"] = t["name"][:-1]
        elif event.unicode and (event.unicode.isalnum() or event.unicode == " ") and len(t["name"]) < 14:
            t["name"] = (t["name"] + event.unicode).upper()
        self.refresh_team()

    def draw_myclub(self, w):
        w.blit(self.select_bg, (0, 0))
        self.draw_back_button(w)
        self.draw_coins(w)
        self.centre_text(w, "MY CLUB", self.font_l, WHITE, 30)
        L = self.myclub_layout()
        t = self.save["team"]
        c1, c2, pattern = self.team_colours()
        mouse = pygame.mouse.get_pos()
        blink = int(pygame.time.get_ticks() / 400) % 2 == 0

        w.blit(self.font_s.render("TEAM NAME (CLICK TO TYPE)", True, (200, 220, 200)), (60, 130))
        pygame.draw.rect(w, (20, 40, 22), L["name"])
        pygame.draw.rect(w, YELLOW if self.editing_name else WHITE, L["name"], 4)
        name = t["name"] + ("_" if self.editing_name and blink else "")
        w.blit(self.font_m.render(name, True, WHITE), (L["name"].x + 16, L["name"].y + 14))
        for label, key, rects, y in (("SHIRT COLOUR", "c1", L["c1"], 290), ("SECOND COLOUR", "c2", L["c2"], 400)):
            w.blit(self.font_s.render(label, True, (200, 220, 200)), (60, y))
            for i, r in enumerate(rects):
                pygame.draw.rect(w, TEAM_PALETTE[i], r)
                pygame.draw.rect(w, YELLOW if t[key] == i else INK, r, 5 if t[key] == i else 2)
        w.blit(self.font_s.render("PATTERN", True, (200, 220, 200)), (60, 512))
        for i, r in enumerate(L["pattern"]):
            on = PATTERNS[i] == pattern
            pygame.draw.rect(w, SELECT_GREEN, r)
            pygame.draw.rect(w, YELLOW if on else WHITE, r, 5 if on else 2)
            tx = self.label(PATTERNS[i], r.w - 10, YELLOW if on else WHITE)
            w.blit(tx, tx.get_rect(center=r.center))
        # preview: badge + a player in the kit
        me = self.clubs[self.user_idx]
        if me["badge"] is not None:
            b = fit_flag(me["badge"], 150, 175)
            w.blit(b, b.get_rect(center=(200, 800)))
        squad = [self.cards[k] for k in self.save["squad"]]
        if squad:
            look = self.team_look(squad[0])
            self.draw_look_preview(w, look, (520, 800))
        # squad
        locked = self.season_running()
        w.blit(self.font_s.render("SQUAD (%d/%d)%s" % (len(squad), SQUAD_SIZE,
                                  "  -  LOCKED DURING A SEASON" if locked else "  -  CLICK TO REMOVE"),
                                  True, (200, 220, 200)), (830, 110))
        for i, r in enumerate(L["squad"]):
            if i < len(squad):
                self.draw_card(w, squad[i], r, stamina=self.save["stamina"].get(squad[i]["id"], 100))
            else:
                pygame.draw.rect(w, (40, 70, 42), r, border_radius=14)
                pygame.draw.rect(w, (120, 150, 120), r, 3, border_radius=14)
                self.centre_in(w, "EMPTY", r)
        owned = self.owned_cards()
        pages = max(1, math.ceil(len(owned) / 14))
        self.coll_page %= pages
        w.blit(self.font_s.render("YOUR CARDS - CLICK TO ADD, DOUBLE-CLICK FOR STATS  (%d)" % len(owned),
                                  True, (200, 220, 200)),
               (830, 470))
        if REN_IN_GAME and not self.ren_unlocked():
            note = self.label("LOCKED:  REN AOYAGI (187)  -  " + REN_UNLOCK_HOW, 1000,
                              (150, 205, 235), font=self.font_s)
            w.blit(note, (830, 438))
        page = owned[self.coll_page * 14:(self.coll_page + 1) * 14]
        for i, r in enumerate(L["coll"]):
            if i < len(page):
                c = page[i]
                insq = c["id"] in self.save["squad"]
                self.draw_card(w, c, r, count=self.save["owned"][c["id"]], dim=insq,
                               glow=r.collidepoint(mouse) and not insq)
        for key, txt in (("prev", "<"), ("next", ">")):
            pygame.draw.rect(w, SELECT_GREEN, L[key])
            pygame.draw.rect(w, WHITE, L[key], 3)
            self.centre_in(w, txt, L[key])
        self.centre_text(w, "PAGE %d / %d" % (self.coll_page + 1, pages), self.font_s, WHITE, 990)
        tb = L["tutorial"]
        pygame.draw.rect(w, (40, 80, 160), tb, border_radius=14)
        pygame.draw.rect(w, YELLOW if tb.collidepoint(mouse) else WHITE, tb, 3, border_radius=14)
        lab = self.label("REPLAY TUTORIAL", tb.w - 30, WHITE)
        w.blit(lab, lab.get_rect(center=tb.center))

    def centre_in(self, w, text, rect, font=None, color=WHITE):
        img = (font or self.font_s).render(text, True, color)
        w.blit(img, img.get_rect(center=rect.center))

    def draw_look_preview(self, w, look, centre):
        """Standing preview of a player in a look (not physics, just pieces)."""
        cx, cy = centre
        for piece, off in (("leg", (-12, TORSO_H / 2 + LEG_L / 2 - 4)), ("leg", (12, TORSO_H / 2 + LEG_L / 2 - 4)),
                           ("arm", (-SHOULDER_X, SHOULDER_Y + ARM_L / 2)), ("arm", (SHOULDER_X, SHOULDER_Y + ARM_L / 2)),
                           ("torso", (0, 0)), ("head", (0, -TORSO_H / 2 - HEAD_R - 2))):
            img = look.get(piece)
            if img is None:
                continue
            img = scaled(img, (img.get_width() * 2, img.get_height() * 2))
            w.blit(img, img.get_rect(center=(int(cx + off[0] * 2), int(cy + off[1] * 2))))

    # ---- lineup / half-time sub ------------------------------------
    def lineup_cards(self):
        if self.mode == "club":
            return [self.cards[k] for k in self.save["squad"]]
        code = self.teams[self.team]["name"]
        return [c for c in self.cards.values() if c["kind"] == "wc" and c["team"] == code]

    def stamina_of(self, card):
        if self.mode == "club":
            return self.save["stamina"].get(card["id"], 100)
        return self.wc_stamina.get(card["id"], 100)

    def set_stamina(self, card, value):
        value = int(clamp(value, 0, 100))
        if self.mode == "club":
            self.save["stamina"][card["id"]] = value
        else:
            self.wc_stamina[card["id"]] = value

    def go_lineup(self, half):
        self.lineup_half = half
        self.state = LINEUP
        self.dragging = False
        self.slowmo = 1.0

    def lineup_layout(self):
        n = len(self.lineup_cards())
        w, h, gap = 260, 360, 50
        x0 = (WIDTH - (n * w + (n - 1) * gap)) // 2
        return [pygame.Rect(x0 + i * (w + gap), 330, w, h) for i in range(n)]

    def available(self, card):
        cards = self.lineup_cards()
        if all(self.stamina_of(c) <= 0 for c in cards):
            return True                                   # everyone's tired: anyone can go
        return self.stamina_of(card) > 0

    def lineup_click(self, pos):
        cards = self.lineup_cards()
        for card, rect in zip(cards, self.lineup_layout()):
            if rect.collidepoint(pos.x, pos.y):
                ok = self.available(card)
                self.card_click(card, (lambda c=card: self.pick_player(c)) if ok else (lambda: None))
                return

    def pick_player(self, card):
        self.set_stamina(card, self.stamina_of(card) - STAMINA_PER_HALF)
        self.played_this_match.add(card["id"])
        self.my_card = card
        self.player.set_stats(card)
        # CPU sends out a random player each half
        self.pick_cpu()
        if self.lineup_half == 1:
            self.new_match()
            self.start_versus()                            # TEAM1 vs TEAM2 before kick-off
        else:
            self.half = 2                                  # second half kicks off
            self.apply_looks()
            self.setup_kickoff(None)
        self.write_save()

    def pick_cpu(self):
        if self.mode == "club":
            code = self.clubs[self.club_opps[-1]]["code"]
            pool = [c for c in self.cards.values() if c["kind"] == "club" and c["team"] == code]
        else:
            code = self.teams[self.opponents[-1]]["name"]
            pool = [c for c in self.cards.values() if c["kind"] == "wc" and c["team"] == code]
        self.cpu_card = random.choice(pool) if pool else None
        if self.cpu_card is not None and self.impossible_run():
            c = self.cpu_card
            self.cpu_card = dict(c, rating=c["rating"] + IMPOSSIBLE_BOOST, sho=c["sho"] + IMPOSSIBLE_BOOST,
                                 str=c["str"] + IMPOSSIBLE_BOOST, boosted=True)
        self.cpu.set_stats(self.cpu_card)

    def draw_lineup(self, w):
        w.blit(self.select_bg, (0, 0))
        if self.lineup_half == 1:
            title = "KICK-OFF: WHO STARTS?"
        else:
            title = "HALF TIME  %d - %d  :  WHO PLAYS THE 2ND HALF?" % (self.score_home, self.score_away)
        self.centre_text(w, title, self.font_l if self.lineup_half == 1 else self.font_m, WHITE, 60)
        opp = (self.clubs[self.club_opps[-1]] if self.mode == "club" else None)
        sub = "PLAYING A HALF COSTS %d%% STAMINA  -  0%% = CAN'T PLAY" % STAMINA_PER_HALF
        self.centre_text(w, sub, self.font_s, (200, 220, 200), 190)
        if opp is not None and opp["badge"] is not None:
            b = fit_flag(opp["badge"], 90, 100)
            w.blit(b, b.get_rect(center=(WIDTH - 120, 110)))
        mouse = pygame.mouse.get_pos()
        for card, rect in zip(self.lineup_cards(), self.lineup_layout()):
            ok = self.available(card)
            st = self.stamina_of(card)
            self.draw_card(w, card, rect, stamina=st, dim=not ok, glow=ok and rect.collidepoint(mouse))
            lab = "%d%%" % st if ok else "TIRED"
            self.centre_text_at(w, lab, rect.centerx, rect.bottom + 34, YELLOW if ok else (230, 90, 90))
            if card.get("id") in self.played_this_match:
                self.centre_text_at(w, "PLAYED 1ST HALF", rect.centerx, rect.y - 34, (200, 220, 200))

    def centre_text_at(self, w, text, x, y, color=WHITE, font=None):
        img = (font or self.font_s).render(text, True, color)
        w.blit(img, img.get_rect(center=(int(x), int(y))))

    # ---- after the whistle ----------------------------------------
    # ---- levels ----------------------------------------------------
    def level(self):
        return level_from_xp(self.save.get("xp", 0))[0]

    def award_xp(self, amount):
        before = self.level()
        self.save["xp"] = self.save.get("xp", 0) + int(amount)
        self.last_xp = int(amount)
        after = self.level()
        if after > before:
            bonus = sum(LEVEL_UP_COINS * lv for lv in range(before + 1, after + 1))
            self.save["coins"] += bonus
            self.toast("LEVEL UP!  LEVEL %d   +%d COINS" % (after, bonus), YELLOW)
            if before < IMPOSSIBLE_LEVEL <= after:
                self.toast("IMPOSSIBLE MODE UNLOCKED - WORLD CUP", (255, 110, 110))
        self.write_save()

    def toast(self, text, colour=WHITE, seconds=3.5):
        if not hasattr(self, "toasts"):
            self.toasts = []
        self.toasts.append([text, colour, seconds])

    def draw_toasts(self, w):
        alive = []
        for i, t in enumerate(getattr(self, "toasts", [])[:3]):
            t[2] -= 1.0 / FPS
            if t[2] <= 0:
                continue
            alive.append(t)
            img = self.label(t[0], 1200, t[1], self.font_m)
            box = img.get_rect(center=(WIDTH // 2, 150 + i * 96)).inflate(60, 30)
            veil = pygame.Surface(box.size, pygame.SRCALPHA)
            veil.fill((8, 10, 24, 215))
            w.blit(veil, box.topleft)
            pygame.draw.rect(w, t[1], box, 4, border_radius=10)
            w.blit(img, img.get_rect(center=box.center))
        self.toasts = alive + getattr(self, "toasts", [])[3:]

    def draw_level(self, w, x, y, width=340):
        level, into, need = level_from_xp(self.save.get("xp", 0))
        badge = pygame.Rect(x, y, 110, 56)
        pygame.draw.rect(w, (30, 60, 140), badge, border_radius=12)
        pygame.draw.rect(w, (140, 220, 255), badge, 4, border_radius=12)
        self.centre_in(w, "LV %d" % level, badge)
        bar = pygame.Rect(x + 124, y + 12, width - 124, 32)
        pygame.draw.rect(w, (20, 24, 40), bar, border_radius=8)
        pygame.draw.rect(w, (80, 190, 255), (bar.x, bar.y, int(bar.w * into / max(1, need)), bar.h),
                         border_radius=8)
        pygame.draw.rect(w, WHITE, bar, 3, border_radius=8)
        t = self.font_s.render("%d / %d XP" % (into, need), True, WHITE)
        k = min(1.0, (bar.h - 6) / max(1, t.get_height()), (bar.w - 20) / max(1, t.get_width()))
        t = pygame.transform.smoothscale(t, (max(1, int(t.get_width() * k)), max(1, int(t.get_height() * k))))
        w.blit(t, t.get_rect(center=bar.center))

    def settle_match(self):
        """Coins + stamina recovery for everyone who sat the match out."""
        if self.mode == "free":                           # freeplay: a random few coins, nothing else
            self.last_earned = random.randint(*FREE_REWARD)
            self.last_xp = 0
            self.save["coins"] += self.last_earned
            self.write_save()
            return
        hs, as_ = self.score_home, self.score_away
        result = "win" if hs > as_ else ("draw" if hs == as_ else "loss")
        earned = REWARD[result] + REWARD_PER_GOAL * hs
        if self.impossible_run():
            earned *= IMPOSSIBLE_COINS
        self.save["coins"] += earned
        self.last_earned = earned
        xp = XP_REWARD[result] + XP_PER_GOAL * hs
        if self.mode == "wc" and result == "win" and self.round + 1 >= len(ROUNDS):
            xp += XP_TROPHY                               # world champions
        if self.ren_unlock_ready(result):                 # Japan + Impossible + the trophy
            self.unlock_ren()
            self.ren_pending = True
        self.award_xp(xp)
        for card in self.lineup_cards():
            rest = STAMINA_REST if card["id"] not in self.played_this_match else STAMINA_RECOVER
            self.set_stamina(card, self.stamina_of(card) + rest)
        self.write_save()

    # ================================================================ PACKS (v3)
    def card_pool(self, card):
        """A = icons and 120+, B = 100-119, C = the rest."""
        if card["design"] == "icon" or card["rating"] >= PACK_TIER_A:
            return "A"
        return "B" if card["rating"] >= PACK_TIER_B else "C"

    def pack_tier(self, card):
        return self.card_pool(card)

    def pack_pool(self, pack, pool=None):
        cards = [c for c in self.cards.values() if c["pack"] == pack]
        if pool is not None:
            cards = [c for c in cards if self.card_pool(c) == pool]
        return sorted(cards, key=lambda c: (-c["rating"], c["name"]))

    def pity(self, pack):
        p = self.save.setdefault("pity", {}).setdefault(str(pack), {"a": 0, "b": 0})
        return p

    def roll_pack(self, pack):
        """Pool odds with pity: pool B guaranteed every 10 packs, A every 40."""
        p = self.pity(pack)
        if p["a"] + 1 >= PITY_A:
            pool = "A"
        elif p["b"] + 1 >= PITY_B:
            pool = random.choices(["A", "B"], weights=[POOL_ODDS["A"], POOL_ODDS["B"]])[0]
        else:
            pool = random.choices(list(POOL_ODDS), weights=list(POOL_ODDS.values()))[0]
        cards = self.pack_pool(pack, pool) or self.pack_pool(pack)
        card = random.choice(cards)
        pool = self.card_pool(card)
        if pool == "A":
            p["a"], p["b"] = 0, 0
        elif pool == "B":
            p["a"], p["b"] = p["a"] + 1, 0
        else:
            p["a"], p["b"] = p["a"] + 1, p["b"] + 1
        return card

    def buy_pack(self, pack):
        if self.save["coins"] < PACK_PRICE:
            return False
        if self.tut is not None and self.tut["step"] == "packs":
            self.tutorial_progress()["packs"] += 1
        self.save["coins"] -= PACK_PRICE
        card = self.roll_pack(pack)
        count = self.give_card(card)
        self.pack_reveal = {"card": card, "t": 0.0, "count": count, "pack": pack,
                            "tier": self.card_pool(card), "opened": False}
        self.fx = []
        self.state = PACK_OPEN
        self.write_save()
        return True

    # ---- packs list -------------------------------------------------------
    # ---- the pack store: draft-style list + featured banner ----------------
    PACK_THEME = {0: ((26, 44, 96), (120, 170, 255)), 1: ((80, 18, 34), (255, 130, 140)),
                  2: ((16, 48, 92), (120, 200, 255)), 3: ((56, 20, 84), (210, 150, 255)),
                  4: ((30, 8, 60), (190, 120, 255))}

    def packs_layout(self):
        """The pack list down the left."""
        return [pygame.Rect(40, 140 + i * 152, 292, 140) for i in range(len(PACK_NAMES))]

    def packs_ui(self):
        L = {"panel": pygame.Rect(360, 120, 1520, 716), "info": pygame.Rect(0, 0, 54, 54),
             "all": pygame.Rect(388, 892, 300, 116), "one": pygame.Rect(748, 892, 420, 116),
             "ten": pygame.Rect(1204, 892, 500, 116), "box": pygame.Rect(40, 916, 292, 84),
             "slices": [], "pools": []}
        for i, pool in enumerate(("A", "B", "C")):
            L["pools"].append((pool, pygame.Rect(398 + i * 94, 946, 84, 52)))
        L["info"].topleft = (740, 152)
        for i in range(4):
            L["slices"].append(pygame.Rect(376 + i * 372, 196, 372, 508))
        return L

    def featured_cards(self, pack):
        """The four players on the banner: the best of pool A, topped up from pool B."""
        best = self.pack_pool(pack, "A") + self.pack_pool(pack, "B")
        return best[:4]

    def slice_fade(self, size):
        """The dark fade at the bottom of a banner slice - one per size, not one per frame."""
        cache = getattr(self, "_slice_fade", None)
        if cache is None:
            cache = self._slice_fade = {}
        key = (int(size[0]), int(size[1]))
        fade = cache.get(key)
        if fade is None:
            if len(cache) > 8:
                cache.clear()
            fade = pygame.Surface(key, pygame.SRCALPHA)
            for y in range(0, key[1], 4):
                a = int(150 * max(0.0, (y - key[1] * 0.45) / (key[1] * 0.55)))
                fade.fill((6, 4, 16, a), (0, y, key[0], 4))
            cache[key] = fade
        return fade

    def draw_slice(self, w, rect, card, i, accent):
        """One diagonal panel: portrait, the name down the side, the card at the bottom."""
        skew = 64
        pts = [(rect.x + skew, rect.y), (rect.right + skew, rect.y), (rect.right, rect.bottom),
               (rect.x, rect.bottom)]
        shade = _shade(accent[0], 0.7 + 0.16 * (i % 2))
        pygame.draw.polygon(w, shade, pts)
        clip = w.get_clip()
        if clip is not None:
            x0, y0 = max(rect.x, clip.x), max(rect.y, clip.y)
            x1, y1 = min(rect.right, clip.right), min(rect.bottom, clip.bottom)
            w.set_clip(pygame.Rect(x0, y0, max(0, x1 - x0), max(0, y1 - y0)))
        else:
            w.set_clip(rect)
        face = self.card_faces.get(card["id"])
        if face is not None:
            size = int(rect.h * 0.78)
            img = scaled(face, (size, size))
            w.blit(img, img.get_rect(midbottom=(rect.centerx + 26, rect.bottom + int(rect.h * 0.06))))
        w.blit(self.slice_fade(rect.size), rect.topleft)
        w.set_clip(clip)
        # the diagonal cuts: paint the corners back out in the panel colour
        bg = (10, 12, 26)
        pygame.draw.polygon(w, bg, [(rect.x, rect.y), (rect.x + skew, rect.y), (rect.x, rect.bottom)])
        pygame.draw.polygon(w, bg, [(rect.right, rect.y), (rect.right + skew, rect.y),
                                    (rect.right + skew, rect.bottom), (rect.right, rect.bottom)])
        pygame.draw.line(w, accent[1], (rect.x + skew, rect.y), (rect.x, rect.bottom), 3)
        # name down the slice
        nm = self.fit_text(card["name"].upper(), self.font_m, WHITE, rect.h * 0.8, 44)
        nm = pygame.transform.rotate(nm, 74)
        nm.set_alpha(150)
        w.blit(nm, nm.get_rect(center=(rect.x + 70, rect.centery)))
        # the card itself
        cr = pygame.Rect(0, 0, 150, 208)
        cr.midbottom = (rect.centerx + 18, rect.bottom - 4)
        self.draw_card(w, card, cr)

    def draw_packs(self, w):
        w.blit(self.shop_bg or self.select_bg, (0, 0))
        self.draw_back_button(w)
        self.draw_coins(w)
        mouse = pygame.mouse.get_pos()
        pack = self.view_pack
        L = self.packs_ui()
        base, accent = self.PACK_THEME.get(pack, ((30, 30, 60), WHITE))
        # ---- the pack list
        for i, r in enumerate(self.packs_layout()):
            on = i == pack
            tb, ta = self.PACK_THEME.get(i, ((30, 30, 60), WHITE))
            pygame.draw.rect(w, _shade(tb, 1.25 if on else 0.75), r, border_radius=14)
            pygame.draw.rect(w, YELLOW if on or r.collidepoint(mouse) else _shade(ta, 0.7), r,
                             5 if on else 3, border_radius=14)
            art = self.pack_art[i] if i < len(self.pack_art) else None
            if art is not None:
                im = scaled(art, (78, 110))
                w.blit(im, im.get_rect(midleft=(r.x + 14, r.centery)))
            nm = self.fit_text(PACK_NAMES[i], self.font_m, WHITE, r.w - 120, 40)
            w.blit(nm, nm.get_rect(midleft=(r.x + 104, r.centery - 18)))
            chip = pygame.Rect(r.x + 104, r.centery + 12, min(170, r.w - 116), 34)
            pygame.draw.rect(w, ta, chip, border_radius=8)
            tag = self.fit_text(PACK_TAGS[i], self.font_s, (10, 10, 20), chip.w - 12, 24)
            w.blit(tag, tag.get_rect(center=chip.center))
        box = L["box"]
        pygame.draw.rect(w, (0, 130, 60), box, border_radius=14)
        pygame.draw.rect(w, YELLOW if box.collidepoint(mouse) else (254, 214, 0), box, 4, border_radius=14)
        lab = self.fit_text("NEYMAR JR GAME BOX  >", self.font_m, WHITE, box.w - 24, 38)
        w.blit(lab, lab.get_rect(center=box.center))
        # ---- the banner
        panel = L["panel"]
        pygame.draw.rect(w, (10, 12, 26), panel, border_radius=18)
        pygame.draw.rect(w, accent, panel, 4, border_radius=18)
        head = self.fit_text(PACK_NAMES[pack], self.font_l, WHITE, 600, 74)
        w.blit(head, (panel.x + 28, panel.y + 18))
        info = L["info"]
        info.midleft = (panel.x + 40 + head.get_width() + 20, panel.y + 18 + head.get_height() // 2)
        pygame.draw.circle(w, accent, info.center, 26, 4)
        self.centre_in(w, "i", info, self.font_m, accent)
        odds = self.fit_text("POOL A %d%%   POOL B %d%%   POOL C %d%%"
                             % (POOL_ODDS["A"] * 100, POOL_ODDS["B"] * 100, POOL_ODDS["C"] * 100),
                             self.font_s, (200, 210, 235), 560, 32)
        w.blit(odds, odds.get_rect(topright=(panel.right - 28, panel.y + 30)))
        cards = self.featured_cards(pack)
        clip = w.get_clip()
        w.set_clip(panel.inflate(-8, -8))
        for i, (r, c) in enumerate(zip(L["slices"], cards)):
            self.draw_slice(w, r, c, i, (base, accent))
        w.set_clip(clip)
        # ---- guarantee bars
        p = self.pity(pack)
        for i, (txt, col, ink) in enumerate((("POOL B OR BETTER IN %d DRAWS" % (PITY_B - p["b"]), (150, 60, 235), WHITE),
                                             ("POOL A IN %d DRAWS" % (PITY_A - p["a"]), (236, 180, 40), (40, 26, 0)))):
            chip = pygame.Rect(0, 0, 560 - i * 60, 52)
            chip.topright = (panel.right - 28, panel.bottom - 122 + i * 58)
            pygame.draw.rect(w, col, chip, border_radius=26)
            pygame.draw.rect(w, WHITE, chip, 3, border_radius=26)
            lab = self.fit_text(txt, self.font_s, ink, chip.w - 30, 34)
            w.blit(lab, lab.get_rect(center=chip.center))
        # ---- buy row
        coins = self.save["coins"]
        for key, txt, cost in (("one", "1 DRAW", PACK_PRICE), ("ten", "10 DRAWS", PACK_PRICE * MULTI_PACKS)):
            r = L[key]
            can = coins >= cost
            pygame.draw.rect(w, (40, 170, 70) if can else (58, 70, 60), r, border_radius=58)
            pygame.draw.rect(w, YELLOW if can and r.collidepoint(mouse) else WHITE, r, 5, border_radius=58)
            lab = self.fit_text(txt, self.font_m, WHITE if can else (190, 190, 190), r.w * 0.5, 46)
            w.blit(lab, lab.get_rect(midleft=(r.x + 30, r.centery)))
            pygame.draw.circle(w, YELLOW, (r.right - 130, r.centery), 20)
            pygame.draw.circle(w, (190, 140, 20), (r.right - 130, r.centery), 20, 4)
            price = self.fit_text(self.fmt(cost), self.font_m, YELLOW if can else (190, 160, 120), 170, 42)
            w.blit(price, price.get_rect(midleft=(r.right - 100, r.centery)))
        r = L["all"]
        pygame.draw.rect(w, (36, 54, 110), r, border_radius=20)
        pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) else WHITE, r, 4, border_radius=20)
        lab = self.fit_text("WHO'S INSIDE", self.font_s, WHITE, r.w - 30, 30)
        w.blit(lab, lab.get_rect(midtop=(r.centerx, r.y + 10)))
        for pool, pr in L["pools"]:                          # jump straight to a pool's players
            col = {"A": (120, 46, 170), "B": (150, 116, 20), "C": (46, 60, 84)}[pool]
            pygame.draw.rect(w, col, pr, border_radius=12)
            pygame.draw.rect(w, YELLOW if pr.collidepoint(mouse) else WHITE, pr, 3, border_radius=12)
            pl = self.fit_text(pool, self.font_m, WHITE, pr.w - 10, 34)
            w.blit(pl, pl.get_rect(center=pr.center))
        n_owned = len(self.save["owned"])
        coll = self.fit_text("COLLECTION  %d / %d" % (n_owned, len(self.cards)), self.font_s, (200, 214, 240), 460, 32)
        w.blit(coll, coll.get_rect(midright=(panel.right - 28, 1044)))

    def box_button(self):
        return self.packs_ui()["box"]

    def packs_click(self, pos):
        L = self.packs_ui()
        if pygame.Rect(40, 30, 200, 70).collidepoint(pos.x, pos.y):
            self.open_store()
            return
        if L["box"].collidepoint(pos.x, pos.y):
            self.open_event()
            return
        for i, rect in enumerate(self.packs_layout()):
            if rect.collidepoint(pos.x, pos.y):
                self.view_pack = i                          # pick a pack from the list
                return
        for pool, pr in L["pools"]:
            if pr.collidepoint(pos.x, pos.y):
                self.open_pack_view(self.view_pack, pool)    # straight to pool A / B / C
                return
        if L["info"].collidepoint(pos.x, pos.y) or L["all"].collidepoint(pos.x, pos.y):
            self.open_pack_view(self.view_pack)
            return
        if L["one"].collidepoint(pos.x, pos.y):
            self.buy_pack(self.view_pack)
            return
        if L["ten"].collidepoint(pos.x, pos.y):
            self.buy_pack10(self.view_pack)
            return

    # ---- pack view: buy on the left, the players on the right --------------
    def open_packs(self, pack=None):
        """The pack store itself (the draft-style screen)."""
        if pack is not None:
            self.view_pack = pack
        self.state = PACKS

    def open_pack_view(self, pack, pool="A"):
        self.view_pack = pack
        self.view_scroll = 0.0
        self.view_more = False
        self.view_more_scroll = 0.0
        self.state = PACK_VIEW
        self.show_pool(pool)

    def pool_offset(self, pool):
        """Where pool B starts along the strip."""
        items, _total = self.view_strip()
        for it in items:
            if it[0] == "header" and it[1] == pool:
                return max(0.0, it[2] - 20.0)
        return 0.0

    def show_pool(self, pool):
        """Jump the pack view to pool A, B or C."""
        self.view_more = pool == "C"
        if pool == "C":
            self.view_more_scroll = 0.0
        else:
            self.view_scroll = 0.0
            if pool == "B":
                self.scroll_view(self.pool_offset("B"))

    def shown_pool(self):
        if self.view_more:
            return "C"
        return "B" if self.view_scroll >= max(60.0, self.pool_offset("B") - 160.0) else "A"

    def view_layout(self):
        L = {"art": pygame.Rect(90, 150, 330, 462), "buy": pygame.Rect(90, 636, 330, 92),
             "buy10": pygame.Rect(90, 740, 330, 92),
             "panel": pygame.Rect(560, 130, WIDTH - 600, 900),
             "left": pygame.Rect(600, 880, 90, 70), "right": pygame.Rect(WIDTH - 150, 880, 90, 70),
             "tabs": [(pool, pygame.Rect(600 + i * 176, 52, 166, 62))
                      for i, pool in enumerate(("A", "B", "C"))]}
        L["more"] = L["tabs"][2][1]                         # the old MORE button is now the POOL C tab
        return L

    def view_strip(self):
        """Cards along the scrolling strip: pool A big, then pool B."""
        items, x = [], 0
        for pool, size in (("A", (270, 375)), ("B", (200, 278))):
            cards = self.pack_pool(self.view_pack, pool)
            if not cards:
                continue
            items.append(("header", pool, x))
            x += 20
            for c in cards:
                items.append(("card", c, x, size))
                x += size[0] + 26
            x += 60
        return items, x

    def view_more_layout(self):
        cards = self.pack_pool(self.view_pack, "C")
        cols = 8
        rects = []
        for i, c in enumerate(cards):
            r, k = divmod(i, cols)
            rects.append((c, pygame.Rect(600 + k * 158, 260 + r * 214 - int(self.view_more_scroll), 136, 190)))
        return rects

    def pack_view_click(self, pos):
        L = self.view_layout()
        if pygame.Rect(40, 30, 200, 70).collidepoint(pos.x, pos.y):
            if self.view_more:
                self.view_more = False
            else:
                self.state = PACKS
            return
        if L["buy"].collidepoint(pos.x, pos.y) or L["art"].collidepoint(pos.x, pos.y):
            self.buy_pack(self.view_pack)
            return
        if L["buy10"].collidepoint(pos.x, pos.y):
            self.buy_pack10(self.view_pack)
            return
        for pool, r in L["tabs"]:
            if r.collidepoint(pos.x, pos.y):
                self.show_pool(pool)                        # POOL A / POOL B / POOL C
                return
        if not self.view_more:
            if L["left"].collidepoint(pos.x, pos.y):
                self.scroll_view(-600)
                return
            if L["right"].collidepoint(pos.x, pos.y):
                self.scroll_view(600)
                return
        for card, rect in self.visible_view_cards():
            if rect.collidepoint(pos.x, pos.y):
                self.card_click(card, lambda: None)          # double-click = stats
                return

    def scroll_view(self, dx):
        if self.view_more:
            rows = math.ceil(len(self.pack_pool(self.view_pack, "C")) / 8)
            panel = self.view_layout()["panel"]
            self.view_more_scroll = clamp(self.view_more_scroll + dx, 0,
                                          max(0, rows * 214 - (panel.bottom - 300)))
            return
        _items, total = self.view_strip()
        width = self.view_layout()["panel"].w - 40
        self.view_scroll = clamp(self.view_scroll + dx, 0, max(0, total - width))

    def visible_view_cards(self):
        if self.view_more:
            return [(c, r) for c, r in self.view_more_layout() if 230 < r.y < 1000]
        L = self.view_layout()
        items, _ = self.view_strip()
        out = []
        for it in items:
            if it[0] != "card":
                continue
            _k, c, x, size = it
            r = pygame.Rect(L["panel"].x + 20 + x - int(self.view_scroll), 0, *size)
            r.bottom = 820
            if r.right > L["panel"].x and r.x < L["panel"].right:
                out.append((c, r))
        return out

    def draw_pack_view(self, w):
        w.blit(self.shop_bg or self.select_bg, (0, 0))
        self.draw_back_button(w)
        self.draw_coins(w)
        L = self.view_layout()
        pack = self.view_pack
        mouse = pygame.mouse.get_pos()
        t = pygame.time.get_ticks() * 0.001
        head = self.label(PACK_NAMES[pack], 400, WHITE, self.font_m)
        w.blit(head, head.get_rect(center=(L["art"].centerx, 124)))
        art = self.pack_art[pack]
        bob = int(math.sin(t * 2.2) * 8)
        if art is not None:
            w.blit(scaled(art, L["art"].size), L["art"].move(0, bob))
        afford = self.save["coins"] >= PACK_PRICE
        b = L["buy"]
        hover = b.collidepoint(mouse) and afford
        pygame.draw.rect(w, (40, 170, 70) if afford else (70, 90, 72), b, border_radius=16)
        pygame.draw.rect(w, YELLOW if hover else WHITE, b, 5, border_radius=16)
        self.centre_in(w, "BUY  %d" % PACK_PRICE if afford else "NEED %d" % PACK_PRICE, b, self.font_m,
                       WHITE if afford else (200, 150, 150))
        cost10 = PACK_PRICE * MULTI_PACKS
        afford10 = self.save["coins"] >= cost10
        b10 = L["buy10"]
        pygame.draw.rect(w, (30, 120, 170) if afford10 else (60, 76, 90), b10, border_radius=16)
        pygame.draw.rect(w, YELLOW if b10.collidepoint(mouse) and afford10 else WHITE, b10, 5, border_radius=16)
        lab10 = self.label("OPEN 10x  %s" % self.fmt(cost10) if afford10 else "10x NEEDS %s" % self.fmt(cost10),
                           b10.w - 30, WHITE if afford10 else (200, 150, 150), self.font_m)
        w.blit(lab10, lab10.get_rect(center=b10.center))
        p = self.pity(pack)
        lines = [("PITY", WHITE),
                 ("POOL A IN %d" % (PITY_A - p["a"]), (220, 150, 255)),
                 ("POOL B IN %d" % (PITY_B - p["b"]), (255, 214, 90)),
                 ("ODDS  A %d%%  B %d%%" % (POOL_ODDS["A"] * 100, POOL_ODDS["B"] * 100), (200, 220, 200)),
                 ("POOL C %d%%" % (POOL_ODDS["C"] * 100), (200, 220, 200))]
        for k, (txt, col) in enumerate(lines):
            img = self.label(txt, 380, col)
            w.blit(img, img.get_rect(center=(b.centerx, 868 + k * 42)))

        panel = L["panel"]
        pygame.draw.rect(w, (12, 20, 52), panel, border_radius=18)
        pygame.draw.rect(w, (92, 128, 220), panel, 3, border_radius=18)
        shown = self.shown_pool()
        for pool, r in L["tabs"]:
            on = pool == shown
            col = {"A": (120, 46, 170), "B": (150, 116, 20), "C": (46, 60, 84)}[pool]
            pygame.draw.rect(w, _shade(col, 1.35 if on else 0.75), r, border_radius=12)
            pygame.draw.rect(w, YELLOW if on or r.collidepoint(mouse) else WHITE, r, 5 if on else 3,
                             border_radius=12)
            lab = self.fit_text("POOL %s" % pool, self.font_m, WHITE, r.w - 20, 38)
            w.blit(lab, lab.get_rect(center=r.center))

        clip = w.get_clip()
        w.set_clip(panel.inflate(-8, -8))
        if self.view_more:
            w.blit(self.font_m.render("POOL C", True, (200, 200, 210)), (panel.x + 40, panel.y + 24))
            for c, r in self.view_more_layout():
                if r.bottom > panel.y + 110 and r.y < panel.bottom:
                    self.draw_card(w, c, r, count=self.save["owned"].get(c["id"], 0),
                                   dim=c["id"] not in self.save["owned"])
        else:
            items, total = self.view_strip()
            for it in items:
                if it[0] == "header":
                    x = panel.x + 20 + it[2] - int(self.view_scroll)
                    col = (220, 150, 255) if it[1] == "A" else (255, 214, 90)
                    w.blit(self.font_m.render("POOL %s" % it[1], True, col), (x, panel.y + 24))
            for c, r in self.visible_view_cards():
                self.draw_card(w, c, r, count=self.save["owned"].get(c["id"], 0),
                               dim=c["id"] not in self.save["owned"], glow=r.collidepoint(mouse))
            hint = self.label("POOL A / B / C UP TOP, OR SCROLL   -   DOUBLE-CLICK A CARD FOR STATS",
                              panel.w - 80, (168, 190, 240))
            w.blit(hint, hint.get_rect(center=(panel.centerx, panel.bottom - 50)))
        w.set_clip(clip)
        if not self.view_more:
            for key, txt in (("left", "<"), ("right", ">")):
                pygame.draw.rect(w, SELECT_GREEN, L[key], border_radius=10)
                pygame.draw.rect(w, WHITE, L[key], 3, border_radius=10)
                self.centre_in(w, txt, L[key], self.font_m)

    # ---- FC Mobile-style opening ---------------------------------------------
    POOL_GLOW = {"A": (190, 90, 255), "B": (255, 205, 70), "C": (225, 225, 235)}
    POOL_SHARD = {"A": ((26, 40, 110), (58, 86, 190), (236, 200, 96)),
                  "B": ((44, 36, 16), (120, 92, 30), (250, 214, 110)),
                  "C": ((26, 30, 38), (66, 74, 90), (190, 200, 215)),
                  "S": ((40, 10, 82), (122, 52, 214), (232, 212, 255))}

    def opening_marks(self, pool):
        """(pack shatters, reveals end, beams end, card lands, -, beats).
        Pools A and B follow openingpack.mp3: flag 0:02, position 0:03.5,
        club 0:05, player 0:07. Pool C has no cutscene."""
        if pool == "C":
            return 0.0, 0.0, 0.0, 0.35, 0.0, 0
        return 1.3, 6.2, 6.75, PACK_CARD_AT, 1.5, len(PACK_BEATS)

    def opening_done_at(self, pool):
        return self.opening_marks(pool)[3]

    def nation_flag(self, code):
        for t in self.teams:
            if t["name"] == code:
                return t["flag"]
        return self.extra_flags.get(code)

    def card_flag(self, card):
        """Nation flag - or, for a club card, the flag of the club's country."""
        if card["kind"] in ("wc", "sig", "no10"):
            return self.card_badge(card)
        code = card["nation"] if card["kind"] in ("star", "rookie") else CLUB_COUNTRY.get(card["team"], "ENG")
        return self.nation_flag(code)

    def card_club(self, card):
        """Club crest - or, for a World Cup card, the World Cup badge."""
        if card["kind"] == "no10":
            return self.no10_badge or self.wc_badge
        if card["kind"] in ("club", "star", "rookie"):
            return self.card_badge(card)
        return self.wc_badge

    def reveal_beats(self, card, n):
        """flag -> position -> club, then the player lands."""
        beats = [("image", self.card_flag(card)), ("text", card["pos"]), ("image", self.card_club(card))]
        return beats[:n]

    def pack_shards(self, pr):
        if "shards" not in pr:
            rng = random.Random(hash(pr["card"]["id"]) & 0xffff)
            pr["shards"] = [(rng.uniform(0, math.tau), rng.uniform(0.05, 1.0), rng.uniform(26, 150),
                             rng.uniform(-3, 3), rng.uniform(0.3, 1.0), rng.random())
                            for _ in range(46)]
        return pr["shards"]

    def pack_backdrop(self, cx, cy):
        """The dark starburst behind a sealed pack - built once, then blitted."""
        if getattr(self, "_pack_bg", None) is None:
            bg = pygame.Surface((WIDTH, HEIGHT)).convert()
            bg.fill((6, 8, 16))
            for k in range(20):
                a = k * math.tau / 20
                pygame.draw.polygon(bg, (14, 18, 34) if k % 2 else (9, 11, 22),
                                    [(cx, cy), (cx + math.cos(a) * 1400, cy + math.sin(a) * 1400),
                                     (cx + math.cos(a + 0.13) * 1400, cy + math.sin(a + 0.13) * 1400)])
            self._pack_bg = bg
        return self._pack_bg

    def pack_stage(self, gold):
        """The chevron stage the card lands on - one surface per pool colour."""
        cache = getattr(self, "_pack_stage", None)
        if cache is None:
            cache = self._pack_stage = {}
        key = tuple(gold)[:3]
        stage = cache.get(key)
        if stage is None:
            if len(cache) > 6:
                cache.clear()
            stage = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            for j in range(11):
                x = int(WIDTH * (j + 0.5) / 11)
                lean = 150 if j % 2 else -150
                col = _shade(gold, 0.26 + 0.09 * (j % 3))
                pygame.draw.polygon(stage, col, [(x - 60, HEIGHT), (x + 60, HEIGHT),
                                                 (x + 20 + lean, 60), (x - 30 + lean, 60)])
            deep = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)   # once, not every frame
            deep.fill((6, 10, 24, 120))
            stage.blit(deep, (0, 0))
            cache[key] = stage
        return stage

    def pack_flare(self, glow):
        """The radial bloom under the wall of light - same picture every frame."""
        cache = getattr(self, "_pack_flare", None)
        if cache is None:
            cache = self._pack_flare = {}
        key = tuple(glow)[:3]
        flare = cache.get(key)
        if flare is None:
            if len(cache) > 6:
                cache.clear()
            flare = pygame.Surface((900, 900), pygame.SRCALPHA)
            for j in range(7):
                r = 900 - j * 120
                pygame.draw.ellipse(flare, tuple(glow)[:3] + (16 + j * 6,),
                                    pygame.Rect((900 - r) // 2, (900 - r) // 2, r, r))
            cache[key] = flare
        return flare

    def rating_shield(self, value, gold, dark):
        """The shield with the rating in it, one surface per number."""
        cache = getattr(self, "_shields", None)
        if cache is None:
            cache = self._shields = {}
        key = (int(value), tuple(gold)[:3], tuple(dark)[:3])
        shield = cache.get(key)
        if shield is None:
            if len(cache) > 120:
                cache.clear()
            shield = pygame.Surface((320, 360), pygame.SRCALPHA)
            pts = [(160, 0), (320, 60), (300, 250), (160, 360), (20, 250), (0, 60)]
            pygame.draw.polygon(shield, gold, pts)
            pygame.draw.polygon(shield, _shade(dark, 1.1), [(x * 0.86 + 22, y * 0.86 + 25) for x, y in pts])
            num = self.font_xl.render(str(int(value)), True, WHITE)
            nk = min(1.0, 190.0 / max(1, num.get_width()), 150.0 / max(1, num.get_height()))
            num = pygame.transform.smoothscale(num, (max(1, int(num.get_width() * nk)),
                                                     max(1, int(num.get_height() * nk))))
            shield.blit(num, num.get_rect(center=(160, 175)))
            cache[key] = shield
        return shield

    def draw_shard_field(self, w, pr, local, pool, cx, cy):
        """Crystal debris flying past the camera."""
        dark, mid, gold = self.POOL_SHARD["S" if pr["card"]["design"] == "starsign" else pool]
        for a, phase, size, spin, depth, kind in self.pack_shards(pr):
            k = (local * 0.55 + phase) % 1.0
            dist = 60 + k * 1500 * depth
            sc = size * (0.35 + k * 1.8) * depth
            x, y = cx + math.cos(a) * dist, cy + math.sin(a) * dist * 0.72
            if x < -300 or x > WIDTH + 300 or y < -300 or y > HEIGHT + 300:
                continue
            ang = a + spin * local
            pts = []
            for j, rad in enumerate((1.0, 0.55, 0.85, 0.45)):
                th = ang + j * math.tau / 4
                pts.append((x + math.cos(th) * sc * rad, y + math.sin(th) * sc * rad * 0.85))
            body = gold if kind > 0.72 else (mid if kind > 0.35 else dark)
            fade = max(0.0, 1.0 - k * 1.1)
            col = _shade(body, 0.35 + 0.75 * fade)
            pygame.draw.polygon(w, col, pts)
            pygame.draw.line(w, _shade(col, 1.6), pts[0], pts[2], max(1, int(sc * 0.08)))

    def pack_open_click(self):
        pr = self.pack_reveal
        if not pr:
            return
        if not pr["opened"]:
            pr["opened"] = True                           # tap the pack to open it
            pr["t"] = 0.0
            pr.pop("start", None)
            if pr["tier"] in ("A", "B"):
                self.sfx.play_track("pack", force=True)
            return
        end = self.opening_done_at(pr["tier"])
        if pr["t"] < end:
            pr["t"] = end                                 # skip straight to the card
            pr.pop("start", None)
            if pr["tier"] in ("A", "B"):
                self.sfx.play_track("pack", start=end, force=True)
            return
        if pr["t"] >= end + 0.4:
            if pr.get("multi"):                          # 10x: the best card walked out, now all 10
                self.card_click(pr["card"], lambda m=pr["multi"]: self.open_multi(m))
                return
            back = (lambda: self.open_event()) if pr.get("back") == "event" \
                else (lambda: self.tutorial_next() if self.tut else self.finish_tutorial()) \
                if pr.get("back") == "tutorial" \
                else (lambda: self.go_to_select()) if pr.get("back") == "ren" \
                else (lambda: self.open_stars()) if pr.get("back") == "stars" \
                else (lambda: self.open_packs(pr["pack"]))
            self.card_click(pr["card"], back)

    def draw_pack_open(self, w):
        pr = self.pack_reveal
        dt = 1.0 / FPS
        card, pool = pr["card"], pr["tier"]
        glow = (255, 226, 130) if card["design"] in ("icon", "signature") else self.POOL_GLOW[pool]
        dark, mid, gold = self.POOL_SHARD["S" if card["design"] == "starsign" else pool]
        cx, cy = WIDTH // 2, HEIGHT // 2 - 40
        tt = pygame.time.get_ticks() * 0.001
        art = pr.get("art") or self.pack_art[pr["pack"]]
        w.fill((6, 8, 16))

        # ---- idle: the pack waiting for a tap
        if not pr["opened"]:
            w.blit(self.pack_backdrop(cx, cy), (0, 0))
            rect = pygame.Rect(0, 0, 330, 462)
            rect.center = (cx, cy + int(math.sin(tt * 2.4) * 10))
            aura = glow_blob((rect.w + 160, rect.h + 160), glow, 45 + 30 * math.sin(tt * 3))
            w.blit(aura, aura.get_rect(center=rect.center))
            if art is not None:
                w.blit(scaled(art, rect.size), rect)
            else:
                pygame.draw.rect(w, SELECT_GREEN, rect, border_radius=16)
                self.centre_in(w, PACK_NAMES[pr["pack"]], rect, self.font_m)
            btn = pygame.Rect(0, 0, 420, 92)
            btn.center = (cx, rect.bottom + 110)
            pygame.draw.rect(w, (40, 190, 90), btn, border_radius=46)
            pygame.draw.rect(w, WHITE, btn, 5, border_radius=46)
            lab = self.fit_text("TAP TO OPEN", self.font_m, WHITE, btn.w - 56, 58)
            w.blit(lab, lab.get_rect(center=btn.center))
            return

        # clocked in real time so the reveals stay locked to the song
        now = pygame.time.get_ticks() / 1000.0
        if "start" not in pr:
            pr["start"] = now - pr["t"]
        prev = pr["t"]
        pr["t"] = max(prev, now - pr["start"])
        t = pr["t"]
        t1, t2, t3, t4, beat_len, n_beats = self.opening_marks(pool)
        beats = self.reveal_beats(card, n_beats)
        plain = n_beats == 0                       # pool C: straight to the card

        def crossed(m):
            return prev < m <= t

        if t < t1:
            # ---- 1) the pack rushes at the camera and shatters
            k = t / t1
            sc = 1.0 + k * k * 2.6
            shake = 6 + 26 * k
            rect = pygame.Rect(0, 0, int(330 * sc), int(462 * sc))
            rect.center = (cx + int(random.uniform(-shake, shake)), cy + int(random.uniform(-shake, shake)))
            aura = glow_blob((rect.w + 200, rect.h + 200), glow, 60 + 140 * k)
            w.blit(aura, aura.get_rect(center=rect.center))
            if art is not None:
                w.blit(scaled(art, (rect.w // 8 * 8, rect.h // 8 * 8)), rect)
            else:
                pygame.draw.rect(w, mid, rect, border_radius=16)
        elif t < t2:
            # ---- 2) flying through the crystal debris, one reveal per beat
            local = t - t1
            self.draw_shard_field(w, pr, local, pool, cx, cy)
            starts = [b for b in PACK_BEATS[:len(beats)] if b <= t]
            if not starts:                                 # shards only until the first beat
                self.draw_fx(w, dt)
                self.centre_text(w, "CLICK TO SKIP", self.font_s, (150, 150, 160), 1010)
                return
            i = len(starts) - 1
            end = PACK_BEATS[i + 1] if i + 1 < len(beats) else t2
            f = (t - PACK_BEATS[i]) / max(0.01, end - PACK_BEATS[i])
            zoom = 0.45 + 0.55 * min(1.0, f * 4.5)
            fade = 1.0 if f < 0.72 else max(0.0, 1.0 - (f - 0.72) / 0.28)
            kind, val = beats[i]
            img = None
            if kind == "text":
                img = self.font_xl.render(str(val), True, WHITE)          # cached by CachedFont
                img = scaled(img, (max(1, int(img.get_width() * zoom * 1.4)) // 6 * 6,
                                   max(1, int(img.get_height() * zoom * 1.4)) // 6 * 6))
            elif kind == "rating":
                shown = int(min(1.0, f / 0.55) * val)
                slam = 1.0 + max(0.0, 1.0 - max(0.0, f - 0.55) * 7) * 0.35 if f >= 0.55 else 1.0
                shield = self.rating_shield(shown, gold, dark)
                img = scaled(shield, (max(1, int(320 * zoom * slam)) // 6 * 6,
                                      max(1, int(360 * zoom * slam)) // 6 * 6))
                if crossed(t1 + i * beat_len + beat_len * 0.55):
                    pass                                          # (no ball-kick sound in packs)
            elif val is not None:
                img = fit_flag(val, max(1, int(430 * zoom)), max(1, int(330 * zoom)))
            if img is not None:
                if fade < 1.0:
                    img = img.copy()
                    img.set_alpha(int(255 * fade))
                w.blit(img, img.get_rect(center=(cx, cy)))
        elif t < t3:
            # ---- 3) white flash, then a wall of light beams
            k = (t - t2) / max(0.01, t3 - t2)
            self.draw_shard_field(w, pr, t2 - t1 + (t - t2), pool, cx, cy)
            nb = {"A": 13, "B": 8, "C": 4}[pool]
            h = HEIGHT * min(1.0, k * 2.2)
            veil = scratch((WIDTH, HEIGHT))
            for j in range(nb):
                off = (j - (nb - 1) / 2) * (WIDTH / (nb + 1))
                width = 22 + 14 * math.sin(tt * 7 + j * 1.6)
                col = glow if (pool != "A" or j % 3) else (255, 235, 150)
                x = cx + off
                bright = tuple(min(255, int(c * 0.45 + 255 * 0.55)) for c in col)
                pygame.draw.polygon(veil, col + (95,),
                                    [(x - width * 1.9, HEIGHT), (x + width * 1.9, HEIGHT),
                                     (x + width * 0.3, HEIGHT - h), (x - width * 0.3, HEIGHT - h)])
                pygame.draw.polygon(veil, bright + (150,),
                                    [(x - width * 0.9, HEIGHT), (x + width * 0.9, HEIGHT),
                                     (x + width * 0.14, HEIGHT - h), (x - width * 0.14, HEIGHT - h)])
                pygame.draw.polygon(veil, (255, 255, 255, 120),
                                    [(x - width * 0.34, HEIGHT), (x + width * 0.34, HEIGHT),
                                     (x + width * 0.07, HEIGHT - h * 0.85), (x - width * 0.07, HEIGHT - h * 0.85)])
            flare = self.pack_flare(glow)
            veil.blit(flare, flare.get_rect(center=(cx, HEIGHT - int(h * 0.55))))
            veil.blit(tint((WIDTH, 208), glow + (12,)), (0, HEIGHT - 220))
            w.blit(veil, (0, 0))
            if crossed(t2 + 0.001):
                pass                                          # (no ball-kick sound in packs)
            wash(w, (255, 255, 255, int(235 * max(0.0, 1 - k * 2.4))), slot=1)
        else:
            # ---- 4) the stage: chevrons, the card slams in, confetti
            if plain:
                if self.shop_bg is not None:
                    w.blit(self.shop_bg, (0, 0))
            else:
                w.blit(self.pack_stage(gold), (0, 0))
            w.blit(tint((WIDTH, 260), glow + (40,)), (0, HEIGHT - 260))
            local = t - t3
            slam_len = max(0.01, t4 - t3)
            k = min(1.0, local / slam_len)
            ease = 1 - (1 - k) ** 3
            sc = (1.5 - 0.5 * ease) if plain else (2.6 - 1.6 * ease)
            rect = pygame.Rect(0, 0, int(300 * sc), int(416 * sc))
            rect.center = (cx, cy - 20)
            if not plain:
                a = int(70 + 50 * math.sin(tt * 4)) if pool == "A" else 55
                halo = glow_blob((rect.w + 200, rect.h + 200), glow, a)
                w.blit(halo, halo.get_rect(center=rect.center))
            if crossed(t4):                                # impact
                self.burst_fireworks(cx, cy - 20, glow, 90 if pool == "A" else (45 if not plain else 16))
                if pool == "A":
                    for _ in range(5):
                        self.burst_fireworks(random.uniform(250, WIDTH - 250), random.uniform(120, 480),
                                             random.choice([glow, WHITE, YELLOW, (120, 220, 255)]))
            self.draw_card(w, card, rect, glow=k >= 1.0)
            if k >= 1.0:
                if pool == "A" and int(local * 1.5) != int((local - dt) * 1.5) and local < 5:
                    self.burst_fireworks(random.uniform(250, WIDTH - 250), random.uniform(120, 450),
                                         random.choice([glow, WHITE, YELLOW]))
                dup = pr["count"] > 1
                msg = "DUPLICATE  x%d" % pr["count"] if dup else "NEW PLAYER!"
                if card["design"] == "icon" and not dup:
                    msg = "ICON UNLOCKED!"
                elif card["design"] == "signature" and not dup:
                    msg = "SIGNATURE UNLOCKED!"
                elif card["design"] == "starsign":
                    msg = "STAR SIGNING COMPLETE!"
                self.centre_text(w, msg, self.font_l, (200, 200, 220) if dup else glow, 760)
                self.centre_text(w, "%s  -  %s" % (card["name"].upper(),
                                                   "STAR SIGNING ELITE" if card["design"] == "starsign"
                                                   else "BEGINNER CARD" if card["design"] == "beginner"
                                                   else "POOL %s" % pool), self.font_m, WHITE, 862)
                self.centre_text(w, "CLICK TO CONTINUE  -  DOUBLE-CLICK FOR STATS", self.font_s,
                                 (200, 220, 200), 950)
        self.draw_fx(w, dt)
        if t < t4:
            self.centre_text(w, "CLICK TO SKIP", self.font_s, (150, 150, 160), 1010)

    # ================================================================ TUTORIAL (first launch, replay from TEAM)
    TUT_TEXT = {
        "welcome": ("WELCOME TO A SMALL WORLD CUP!",
                    "This is you - a little ragdoll footballer. You don't walk: you THROW yourself around the pitch."),
        "drag": ("DRAG TO THROW",
                 "Hold the mouse button anywhere, drag, then let go. You fly the way the arrow points - "
                 "the longer the drag, the harder the throw."),
        "air": ("THROW AGAIN - EVEN IN THE AIR",
                "You can throw as often as you like, even mid-air, to change direction. Do 3 more throws."),
        "ball": ("HIT THE BALL",
                 "Fling yourself into the ball. The faster you're moving when you hit it, the further it flies."),
        "goal": ("SCORE!",
                 "Knock the ball into the goal on the RIGHT. The robot in front of it is just a dummy."),
        "match": ("MATCHES",
                  "Two 30-second halves - most goals wins. OVR = how hard you hit, SHO = how steady your aim is, "
                  "STR = how far you can throw. Players get tired, so rotate your squad of 5."),
        "menu": ("THE MENU",
                 "PLAY: World Cup, Club Football, Freeplay and Practice.   STORE: packs, Star Signing and the "
                 "exchange.   TEAM: your squad, kit and badge."),
        "done": ("YOU'RE READY!",
                 "Your new player is in your squad. Check TEAM, then hit PLAY. You can replay this tutorial from TEAM."),
    }
    TUT_ACTION = ("drag", "air", "ball", "goal")               # steps finished by doing something
    TUT_PITCH = ("welcome", "drag", "air", "ball", "goal", "match")

    def tutorial_progress(self):
        return self.save.setdefault("tutorial", {"coins": False, "packs": 0, "picked": None})

    def start_tutorial(self, replay=False):
        prog = self.tutorial_progress()
        self.tut = {"step": "welcome", "throws": 0, "touches": 0, "goals": 0, "replay": replay,
                    "nice": 0.0, "arrow_t": 0.0}
        self.card_detail = None
        if not replay and prog["coins"]:                   # closed the game half way: carry on where we were
            self.tut["step"] = "done" if prog["picked"] else ("pick" if prog["packs"] >= TUTORIAL_PACKS else "packs")
            self.enter_tutorial_step()
            return
        self.start_practice()
        self.clear_robots()
        self.practice_reset_ball()

    def enter_tutorial_step(self):
        t = self.tut
        step = t["step"]
        t["throws"] = t["touches"] = t["goals"] = 0
        t["nice"] = 0.0
        if step in ("ball", "goal"):
            self.practice_reset_ball()
        if step == "goal":
            bot = self.add_robot("DUMMY")
            if bot is not None:
                bot["doll"].reset_to(WIDTH - GOAL_DEPTH - 330)
        if step in ("menu", "packs", "pick", "done") and self.mode == "practice":
            self.end_practice()
            self.menu_page = "main"
        if step == "packs":
            prog = self.tutorial_progress()
            if not prog["coins"]:
                prog["coins"] = True
                self.save["coins"] += TUTORIAL_COINS
                self.toast("+%d COINS - BUY %d PACKS!" % (TUTORIAL_COINS, TUTORIAL_PACKS), YELLOW)
                self.write_save()
            self.state = TITLE
            self.menu_page = "main"
        if step == "pick":
            self.rookie_sel = None
            self.state = ROOKIE_PICK
        if step == "done":
            self.state = TITLE
            self.menu_page = "main"

    def tutorial_next(self):
        t = self.tut
        i = TUTORIAL_STEPS.index(t["step"]) + 1
        nxt = TUTORIAL_STEPS[i] if i < len(TUTORIAL_STEPS) else None
        if t["replay"] and nxt in ("packs", "pick"):
            nxt = "done"                                     # the rewards only come once
        if nxt is None:
            self.finish_tutorial()
            return
        t["step"] = nxt
        self.enter_tutorial_step()

    def skip_tutorial(self):
        """SKIP jumps past the lessons - the 3 packs + beginner pick still happen (first time only)."""
        t = self.tut
        if t["replay"]:
            if self.mode == "practice":
                self.end_practice()
            self.finish_tutorial()
            return
        t["step"] = "packs"
        self.enter_tutorial_step()

    def finish_tutorial(self):
        if self.mode == "practice":
            self.end_practice()
        self.tut = None
        self.save["tutorial_done"] = True
        self.state = TITLE
        self.menu_page = "main"
        self.write_save()

    def update_tutorial(self, dt):
        t = self.tut
        t["arrow_t"] += dt
        step = t["step"]
        if t["nice"] > 0.0:                                  # "NICE!" for a moment, then the next step
            t["nice"] -= dt
            if t["nice"] <= 0.0:
                self.tutorial_next()
            return
        done = {"drag": t["throws"] >= 1, "air": t["throws"] >= 3, "ball": t["touches"] >= 1,
                "goal": t["goals"] >= 1}.get(step, False)
        if done:
            t["nice"] = 1.0
            self.sfx.play("buff", 0.5)
        if step == "packs" and self.tutorial_progress()["packs"] >= TUTORIAL_PACKS and self.state in (PACKS, PACK_VIEW):
            self.tutorial_next()                             # 3 packs opened: pick your beginner
        elif step == "pick" and self.state not in (ROOKIE_PICK, PACK_OPEN):
            self.state = ROOKIE_PICK                         # nothing else to do until he's picked

    TUT_LINE = 38

    def tutorial_texts(self):
        t = self.tut
        step = t["step"]
        if t["nice"] > 0.0:
            return "NICE!", "On to the next one..."
        if step not in self.TUT_TEXT and step != "packs":
            return "", ""                                  # "pick" has its own screen, no text box
        if step == "packs":
            n = self.tutorial_progress()["packs"]
            body = {TITLE: "Here's %d coins! Click STORE." % TUTORIAL_COINS, STORE: "Click PACKS.",
                    PACKS: "Pick a pack on the left, then hit 1 DRAW (300 coins).",
                    PACK_VIEW: "Click BUY to open it (300 coins)."}.get(self.state, "Keep going!")
            return "BUY %d PACKS  (%d / %d)" % (TUTORIAL_PACKS, n, TUTORIAL_PACKS), body
        return self.TUT_TEXT.get(step, ("", ""))

    def wrap_text(self, text, width, height=34):
        """Split text into lines that fit `width` once drawn `height` px tall."""
        k = height / float(max(1, self.font_s.get_height()))
        lines, line = [], ""
        for word in text.split():
            test = (line + " " + word).strip()
            if line and self.font_s.size(test)[0] * k > width:
                lines.append(line)
                line = word
            else:
                line = test
        if line:
            lines.append(line)
        return lines

    def tutorial_layout(self):
        """(text box, NEXT button or None, SKIP button or None) for the current screen."""
        t = self.tut
        step = t["step"]
        if step in self.TUT_PITCH:
            box = pygame.Rect(260, 14, 1400, 0)
        elif self.state == PACK_VIEW:
            box = pygame.Rect(706, 0, 1060, 0)
        else:
            box = pygame.Rect(260, 0, 1400, 0)
        lines = self.wrap_text(self.tutorial_texts()[1], box.w - 60)
        box.h = 70 + len(lines) * self.TUT_LINE + 76
        if step not in self.TUT_PITCH:
            box.bottom = 1030 if self.state == PACK_VIEW else 1064
        nxt = skip = None
        if step in ("welcome", "match", "menu", "done") and t["nice"] <= 0.0:
            nxt = pygame.Rect(box.right - 210, box.bottom - 66, 190, 54)
        if step in self.TUT_PITCH:
            skip = pygame.Rect(box.right - (420 if nxt else 210), box.bottom - 66, 190, 54)
        return box, nxt, skip

    def tutorial_reset_rect(self):
        """RESET BALL in the text box for the ball + goal steps (in case it gets stuck)."""
        if self.tut is None or self.tut["step"] not in ("ball", "goal") or self.tut["nice"] > 0.0:
            return None
        box, nxt, skip = self.tutorial_layout()
        return pygame.Rect(box.right - 460, box.bottom - 66, 230, 54)

    def tutorial_click(self, pos):
        """NEXT / SKIP / DONE. True = the click was the tutorial's."""
        if self.state in (ROOKIE_PICK, PACK_OPEN) or self.tut["step"] == "pick":
            return False
        box, nxt, skip = self.tutorial_layout()
        if nxt is not None and nxt.collidepoint(pos):
            self.tutorial_next()
            return True
        if skip is not None and skip.collidepoint(pos):
            self.skip_tutorial()
            return True
        reset = self.tutorial_reset_rect()
        if reset is not None and reset.collidepoint(pos):
            self.practice_reset_ball()
            return True
        return box.collidepoint(pos) and self.tut["step"] in self.TUT_PITCH

    def tutorial_target(self):
        """The one thing you're allowed to click while buying the tutorial packs."""
        if self.tut is None or self.tut["step"] != "packs":
            return []
        if self.state == TITLE:
            return [r for item, r in zip(self.menu_items(), self.menu_layout()) if item == "STORE"]
        if self.state == STORE:
            return [self.store_layout()[0]]
        if self.state == PACKS:
            return self.packs_layout() + [self.packs_ui()["one"]]
        if self.state == PACK_VIEW:
            return [self.view_layout()["buy"]]
        return []

    def tutorial_allows(self, pos):
        step = self.tut["step"]
        if step in ("menu", "done"):
            return False                                     # only NEXT / DONE for now
        if step == "packs":
            if self.state in (PACK_OPEN, ROOKIE_PICK):
                return True
            L = self.view_layout() if self.state == PACK_VIEW else None
            extra = [L["art"], L["left"], L["right"], pygame.Rect(40, 30, 200, 70)] + \
                [r for _p, r in L["tabs"]] if L else []
            if self.state == PACKS:
                ui = self.packs_ui()
                extra = [ui["info"], ui["all"]] + [r for _p, r in ui["pools"]]
            return any(r.collidepoint(pos) for r in self.tutorial_target() + extra)
        return True

    def draw_tutorial(self, w):
        t = self.tut
        step = t["step"]
        if step == "pick" or self.state in (PACK_OPEN, ROOKIE_PICK):
            if step == "packs" and self.state == PACK_OPEN:
                n = self.tutorial_progress()["packs"]
                tag = self.label("TUTORIAL PACK %d / %d" % (n, TUTORIAL_PACKS), 500, YELLOW)
                w.blit(tag, (40, 30))
            return
        mouse = pygame.mouse.get_pos()
        box, nxt, skip = self.tutorial_layout()
        title, body = self.tutorial_texts()
        # highlight + bouncing arrow on what to click
        bob = int(abs(math.sin(t["arrow_t"] * 5)) * 18)
        for r in self.tutorial_target():
            pygame.draw.rect(w, YELLOW, r.inflate(16, 16), 5, border_radius=16)
            tip = (r.centerx, r.y - 18 - bob)
            pygame.draw.polygon(w, YELLOW, [(tip[0] - 26, tip[1] - 40), (tip[0] + 26, tip[1] - 40), tip])
            pygame.draw.polygon(w, INK, [(tip[0] - 26, tip[1] - 40), (tip[0] + 26, tip[1] - 40), tip], 3)
        w.blit(tint(box.size, (8, 12, 26, 228)), box.topleft)
        pygame.draw.rect(w, YELLOW, box, 4, border_radius=18)
        if step in TUTORIAL_STEPS[:7]:
            k = TUTORIAL_STEPS.index(step) + 1
            num = self.label("STEP %d / 7" % k, 220, (170, 180, 206))
            w.blit(num, num.get_rect(topright=(box.right - 24, box.y + 16)))
        head = self.fit_text(title, self.font_m, YELLOW, box.w - 300, 52)
        w.blit(head, (box.x + 30, box.y + 14))
        reset = self.tutorial_reset_rect()
        for i, line in enumerate(self.wrap_text(body, box.w - 60)):
            img = self.fit_text(line, self.font_s, WHITE, box.w - 60, 34)
            w.blit(img, (box.x + 30, box.y + 70 + i * self.TUT_LINE))
        for r, txt, col in ((nxt, "DONE" if step == "done" else "NEXT >", (40, 170, 70)),
                            (skip, "SKIP", (110, 50, 60)), (reset, "RESET BALL", (40, 90, 170))):
            if r is None:
                continue
            pygame.draw.rect(w, col, r, border_radius=14)
            pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) else WHITE, r, 3, border_radius=14)
            lab = self.fit_text(txt, self.font_s, WHITE, r.w - 24, 34)
            w.blit(lab, lab.get_rect(center=r.center))

    # ---- pick your beginner --------------------------------------------------
    def rookie_layout(self):
        cards = [pygame.Rect(0, 0, 340, 472) for _ in self.rookie_ids]
        for i, r in enumerate(cards):
            r.midtop = (WIDTH // 2 + (i - 1) * 470, 230)
        return cards, pygame.Rect(WIDTH // 2 - 230, 930, 460, 110)

    def rookie_click(self, pos):
        cards, sign = self.rookie_layout()
        for cid, r in zip(self.rookie_ids, cards):
            if r.collidepoint(pos.x, pos.y):
                if self.rookie_sel == cid:
                    self.card_detail = self.cards[cid]
                self.rookie_sel = cid
                return
        if sign.collidepoint(pos.x, pos.y) and self.rookie_sel:
            self.sign_rookie(self.cards[self.rookie_sel])

    def sign_rookie(self, card):
        prog = self.tutorial_progress()
        if prog["picked"]:
            return False
        prog["picked"] = card["id"]
        count = self.give_card(card)
        squad = self.save["squad"]
        if len(squad) < SQUAD_SIZE:
            squad.append(card["id"])
        elif card["id"] not in squad:                        # he replaces your weakest starter
            weakest = min(squad, key=lambda k: self.cards[k]["rating"] if k in self.cards else 0)
            squad[squad.index(weakest)] = card["id"]
        self.pack_reveal = {"card": card, "t": 0.0, "count": count, "pack": 0, "tier": "B",
                            "opened": True, "back": "tutorial", "art": self.pack_art[0]}
        self.fx = []
        self.state = PACK_OPEN
        self.write_save()
        return True

    def draw_rookie_pick(self, w):
        w.blit(self.shop_bg or self.select_bg, (0, 0))
        head = self.outlined("PICK YOUR FIRST STAR", self.font_l, YELLOW, 0.9, width=5)
        w.blit(head, head.get_rect(center=(WIDTH // 2, 80)))
        sub = self.label("BEGINNER VERSIONS  -  HE JOINS YOUR SQUAD  -  CLICK AGAIN FOR STATS", 1300,
                         (200, 230, 214))
        w.blit(sub, sub.get_rect(center=(WIDTH // 2, 170)))
        cards, sign = self.rookie_layout()
        mouse = pygame.mouse.get_pos()
        for cid, r in zip(self.rookie_ids, cards):
            c = self.cards[cid]
            sel = self.rookie_sel == cid
            rr = r.move(0, -14) if sel else r
            self.draw_card(w, c, rr, glow=sel or r.collidepoint(mouse))
            info = self.label("%s  -  %s" % (c["pos"], STAR_CLUB_NAMES.get(c["team"], c["team"]).upper()), r.w + 40,
                              ROOKIE_MINT if sel else WHITE)
            w.blit(info, info.get_rect(center=(r.centerx, r.bottom + 44)))
        ok = self.rookie_sel is not None
        pygame.draw.rect(w, (40, 170, 90) if ok else (60, 76, 70), sign, border_radius=18)
        pygame.draw.rect(w, YELLOW if ok and sign.collidepoint(mouse) else WHITE, sign, 5, border_radius=18)
        txt = "SIGN %s" % self.cards[self.rookie_sel]["name"].split()[-1].upper() if ok else "PICK ONE"
        lab = self.label(txt, sign.w - 40, WHITE if ok else (170, 190, 180), self.font_m)
        w.blit(lab, lab.get_rect(center=sign.center))

    # ================================================================ PRACTICE: spawn robot CPUs
    def start_practice(self):
        if getattr(self, "_match_cpu", None) is None:
            self._match_cpu = (self.cpu, self.brain)       # the normal CPU, parked while we practise
        self.mode = "practice"
        self.practice = {"goals": {"home": 0, "away": 0}, "reset_t": 0.0, "flash": "home", "next_id": 1}
        self.robots = []
        squad = [self.cards[k] for k in self.save["squad"] if k in self.cards]
        self.my_card = squad[0] if squad else None
        self.player.set_stats(self.my_card)
        self.sync_robots()
        self.new_match()
        self.add_robot("MEDIUM")
        self.quit_prompt = False
        self.paused = False

    def end_practice(self):
        if getattr(self, "_match_cpu", None) is not None:
            self.cpu, self.brain = self._match_cpu
            self._match_cpu = None
        self.robots = []
        self.cpu.reset_to(WIDTH * 0.5 + 430)
        self.brain.skill = DIFFICULTY[self.difficulty][1]
        self.brain.impossible = self.difficulty == IMPOSSIBLE
        self.mode = "wc"
        self.quit_prompt = False
        self.paused = False
        self.dragging = False
        self.slowmo = 1.0
        self.state = TITLE
        self.menu_page = "play"

    def robot_look(self, mode):
        key = mode.lower()
        cache = self.__dict__.setdefault("_robot_looks", {})
        if key not in cache:
            look = {}
            for piece in ("head", "torso", "arm", "leg"):
                size, fit = PIECE_SIZE[piece]
                look[piece] = load_pixel("ROBOT_%s_%s" % (key, piece), size, fit=fit, quiet=True)
            cache[key] = look
        return cache[key]

    def sync_robots(self):
        """Robot 1 doubles as `self.cpu` (so abilities have a defender to beat).
        With no robots the normal CPU is parked far off the pitch."""
        if self.robots:
            self.cpu, self.brain = self.robots[0]["doll"], self.robots[0]["brain"]
        else:
            self.cpu, self.brain = self._match_cpu
            self.cpu.pos.update(-4000, GROUND_Y - 100)
            self.cpu.vel.update(0, 0)

    def add_robot(self, mode="MEDIUM"):
        if len(self.robots) >= ROBOT_MAX:
            self.toast("MAX %d ROBOTS" % ROBOT_MAX, (255, 150, 150))
            return None
        n = len(self.robots)
        doll = Player(WIDTH * 0.5 + 260 + n * 150, -1, AWAY_KIT)
        doll.pos.y = 260                                   # dropped in from the sky
        brain = Brain(doll, -1, 0.72, opponent=self.player)
        bot = {"doll": doll, "brain": brain, "mode": mode, "id": self.practice["next_id"]}
        self.practice["next_id"] += 1
        self.robots.append(bot)
        self.set_robot_mode(bot, mode)
        self.sync_robots()
        return bot

    def set_robot_mode(self, bot, mode):
        rating, skill = ROBOT_STATS[mode]
        bot["mode"] = mode
        bot["doll"].set_stats({"rating": rating, "sho": rating, "str": rating})
        bot["brain"].skill = skill
        bot["doll"].set_look(self.robot_look(mode))

    def cycle_robot(self, bot):
        self.set_robot_mode(bot, ROBOT_MODES[(ROBOT_MODES.index(bot["mode"]) + 1) % len(ROBOT_MODES)])

    def remove_robot(self, bot):
        if bot in self.robots:
            self.robots.remove(bot)
            self.sync_robots()

    def clear_robots(self):
        self.robots = []
        self.sync_robots()

    def place_robots(self):
        for i, bot in enumerate(self.robots):
            bot["doll"].reset_to(WIDTH * 0.5 + 300 + i * 150)

    def practice_reset_ball(self):
        self.ball.reset(WIDTH * 0.5, 220, frozen=False)
        self.ball.vel.update(random.uniform(-160, 160), 120.0)
        self.ball.home_ghost_t = 0.0
        self.practice["reset_t"] = 0.0
        self.last_touch = None

    def practice_squad(self):
        return [self.cards[k] for k in self.save["squad"] if k in self.cards]

    def practice_next_player(self):
        squad = self.practice_squad()
        if not squad:
            self.toast("PICK YOUR SQUAD IN TEAM FIRST", (255, 150, 150))
            return
        i = squad.index(self.my_card) + 1 if self.my_card in squad else 0
        self.my_card = squad[i % len(squad)]
        self.player.set_stats(self.my_card)
        self.ren.reset_match()
        self.apply_looks()

    def practice_step(self, h):
        dolls = [b["doll"] for b in self.robots]
        self.player.step(h, self.segments, self.sfx, self.particles)
        for d in dolls:
            d.step(h, self.segments, self.sfx, self.particles)
        self.ball.step(h, self.segments, self.sfx, self.particles)
        prev, v0 = self.last_touch, Vector2(self.ball.vel)
        if self.ball.home_ghost_t <= 0.0 and \
                ball_vs_player(self.ball, self.player, self.sfx, self.particles, self.on_big_hit):
            self.last_touch = "home"
            self.ren.on_touch((self.ball.vel - v0).length(), prev)
            if self.tut is not None:
                self.tut["touches"] += 1
        if self.ball.ghost_t <= 0.0:
            for d in dolls:
                if ball_vs_player(self.ball, d, self.sfx, self.particles, self.on_big_hit):
                    self.last_touch = "away"
        for d in dolls:
            player_vs_player(self.player, d, self.sfx)
        for i in range(len(dolls)):
            for j in range(i + 1, len(dolls)):
                player_vs_player(dolls[i], dolls[j], self.sfx)
        if self.state == PLAY and self.practice["reset_t"] <= 0.0:
            self.check_goal()

    def practice_layout(self):
        L = {"exit": pygame.Rect(24, 18, 170, 62), "player": pygame.Rect(206, 18, 400, 62),
             "ball": pygame.Rect(618, 18, 230, 62), "clear": pygame.Rect(860, 18, 230, 62),
             "add": pygame.Rect(1102, 18, 290, 62), "bots": []}
        for i, bot in enumerate(self.robots):
            chip = pygame.Rect(24 + i * 390, 92, 310, 56)
            L["bots"].append((bot, chip, pygame.Rect(chip.right + 8, 92, 56, 56)))
        return L

    def practice_click(self, pos):
        """Clicks on the practice panel (they never start a throw)."""
        L = self.practice_layout()
        if L["exit"].collidepoint(pos):
            self.end_practice()
        elif L["player"].collidepoint(pos):
            self.practice_next_player()
        elif L["ball"].collidepoint(pos):
            self.practice_reset_ball()
        elif L["clear"].collidepoint(pos):
            self.clear_robots()
        elif L["add"].collidepoint(pos):
            self.add_robot("MEDIUM")
        else:
            for bot, chip, x in L["bots"]:
                if x.collidepoint(pos):
                    self.remove_robot(bot)
                    return True
                if chip.collidepoint(pos):
                    self.cycle_robot(bot)
                    return True
            return False
        return True

    def draw_practice_ui(self, w):
        L = self.practice_layout()
        mouse = pygame.mouse.get_pos()
        name = self.my_card["name"].upper() if self.my_card else "YOU"
        for key, txt, col in (("exit", "< EXIT", (150, 40, 50)), ("player", "PLAYER: %s  >" % name, (40, 90, 170)),
                              ("ball", "RESET BALL", SELECT_GREEN), ("clear", "CLEAR ROBOTS", (90, 70, 40)),
                              ("add", "+ ADD ROBOT  (%d/%d)" % (len(self.robots), ROBOT_MAX),
                               (60, 60, 76) if len(self.robots) >= ROBOT_MAX else (70, 110, 190))):
            r = L[key]
            pygame.draw.rect(w, col, r, border_radius=14)
            pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) else WHITE, r, 3, border_radius=14)
            lab = self.label(txt, r.w - 24, WHITE)
            w.blit(lab, lab.get_rect(center=r.center))
        for i, (bot, chip, x) in enumerate(L["bots"]):
            light = ROBOT_LIGHT[bot["mode"]]
            pygame.draw.rect(w, (26, 30, 40), chip, border_radius=12)
            pygame.draw.rect(w, light, chip, 3, border_radius=12)
            pygame.draw.circle(w, light, (chip.x + 30, chip.centery), 11)
            lab = self.label("ROBOT %d:  %s" % (i + 1, bot["mode"]), chip.w - 70, WHITE)
            w.blit(lab, lab.get_rect(midleft=(chip.x + 52, chip.centery)))
            pygame.draw.rect(w, (150, 40, 50), x, border_radius=12)
            pygame.draw.rect(w, YELLOW if x.collidepoint(mouse) else WHITE, x, 3, border_radius=12)
            self.centre_in(w, "X", x)
        if not self.robots:
            hint = self.label("NO ROBOTS - ADD ONE, OR PRACTISE YOUR SHOTS ON YOUR OWN", 900, (220, 226, 236))
            w.blit(hint, hint.get_rect(midleft=(28, 120)))
        g = self.practice["goals"]
        score = self.label("YOU %d  -  %d ROBOTS" % (g["home"], g["away"]), 400, WHITE, self.font_m)
        pad = pygame.Rect(0, 0, score.get_width() + 36, 70)
        pad.topright = (WIDTH - 20, 14)
        pygame.draw.rect(w, (10, 14, 24), pad, border_radius=14)
        w.blit(score, score.get_rect(center=pad.center))
        tip = self.label("CLICK A ROBOT TO CHANGE ITS LEVEL:  EASY - MEDIUM - HARD - DUMMY", 900, (200, 206, 220))
        if self.robots:
            w.blit(tip, tip.get_rect(midleft=(30, 172)))
        self.draw_practice_flash(w)

    def draw_practice_flash(self, w):
        if self.practice["reset_t"] > 0.0:                    # quick GOAL! flash, then the ball comes back
            k = clamp((PRACTICE_RESET - self.practice["reset_t"]) * 5.0, 0.0, 1.0)
            col = HOME_KIT["shirt"] if self.practice["flash"] == "home" else AWAY_KIT["shirt"]
            txt = self.outlined("GOAL!", self.font_xl, col, 0.6 + 0.4 * k, INK, 6)
            w.blit(txt, txt.get_rect(center=(WIDTH // 2, int(HEIGHT * 0.34))))

    # ================================================================ FREEPLAY: any player you own
    def open_freeplay(self):
        owned = self.owned_cards()
        if not owned:
            self.toast("YOU DON'T OWN ANY PLAYERS YET", (255, 150, 150))
            return
        f = self.__dict__.setdefault("free", {"me": None, "opp": None, "slot": "me", "page": 0, "diff": 1})
        if f["me"] not in self.save["owned"]:
            f["me"] = owned[0]["id"]
        if f["opp"] not in self.save["owned"]:
            f["opp"] = random.choice(owned)["id"]
        f["page"] %= self.free_pages()
        self.state = FREE_SELECT

    def free_pages(self):
        return max(1, math.ceil(len(self.owned_cards()) / FREE_PER_PAGE))

    def free_layout(self):
        f = self.free
        L = {"me": pygame.Rect(84, 236, 206, 286), "opp": pygame.Rect(392, 236, 206, 286),
             "diff": [pygame.Rect(70 + i * 184, 648, 172, 64) for i in range(3)],
             "random": pygame.Rect(70, 736, 540, 70), "play": pygame.Rect(70, 916, 540, 116),
             "prev": pygame.Rect(670, 990, 110, 64), "next": pygame.Rect(1768, 990, 110, 64), "grid": []}
        owned = self.owned_cards()
        page = owned[f["page"] * FREE_PER_PAGE:(f["page"] + 1) * FREE_PER_PAGE]
        for i, c in enumerate(page):
            r, k = divmod(i, 7)
            L["grid"].append((c, pygame.Rect(670 + k * 174, 196 + r * 262, 156, 216)))
        return L

    def free_click(self, pos):
        f = self.free
        L = self.free_layout()
        if pygame.Rect(40, 30, 200, 70).collidepoint(pos.x, pos.y):
            self.state = TITLE
            self.menu_page = "play"
            return
        for key in ("me", "opp"):
            if L[key].collidepoint(pos.x, pos.y):
                if f["slot"] == key:
                    self.card_detail = self.cards[f[key]]
                f["slot"] = key
                return
        for i, r in enumerate(L["diff"]):
            if r.collidepoint(pos.x, pos.y):
                f["diff"] = i
                return
        if L["random"].collidepoint(pos.x, pos.y):
            f["opp"] = random.choice(self.owned_cards())["id"]
            return
        if L["play"].collidepoint(pos.x, pos.y):
            self.start_freeplay()
            return
        if L["prev"].collidepoint(pos.x, pos.y) or L["next"].collidepoint(pos.x, pos.y):
            step = -1 if L["prev"].collidepoint(pos.x, pos.y) else 1
            f["page"] = (f["page"] + step) % self.free_pages()
            return
        now = pygame.time.get_ticks() / 1000.0
        for c, r in L["grid"]:
            if r.collidepoint(pos.x, pos.y):
                last = getattr(self, "free_click_t", (None, -9.0))
                if last[0] == c["id"] and now - last[1] < DOUBLE_CLICK:
                    self.card_detail = c                       # double-click: stats
                    return
                self.free_click_t = (c["id"], now)
                f[f["slot"]] = c["id"]
                if f["slot"] == "me":
                    f["slot"] = "opp"                          # next pick is the opponent
                return

    def start_freeplay(self):
        f = self.free
        me, opp = self.cards.get(f["me"]), self.cards.get(f["opp"])
        if me is None or opp is None:
            return
        self.mode = "free"
        self.my_card, self.cpu_card = me, opp
        self.player.set_stats(me)
        self.cpu.set_stats(opp)
        self.brain.skill = DIFFICULTY[f["diff"]][1]
        self.brain.impossible = False
        self.played_this_match = set()
        self.last_earned = 0
        self.last_xp = 0
        self.new_match()
        self.start_versus()

    # ---- online player vs player ---------------------------------
    def start_pvp(self, info):
        """The page found an opponent: set the match up and kick off."""
        me = self.cards.get(info.get("card")) or (self.owned_cards() or [None])[0]
        opp = self.cards.get(info.get("oppCard")) or me
        if me is None:
            return
        self.pvp = {"role": info.get("role", "host"), "name": info.get("name", "YOU"),
                    "opp": info.get("oppName", "RIVAL"), "ranked": bool(info.get("ranked", True)),
                    "rank": info.get("rank", ""), "oppRank": info.get("oppRank", ""),
                    "sent": 0, "got": 0, "last": 0.0}
        self.mode = "pvp"
        self.my_card, self.cpu_card = me, opp
        self.player.set_stats(me)
        self.cpu.set_stats(opp)
        self.played_this_match = set()
        self.last_earned = self.last_xp = 0
        self.chat_log = []
        self.net_t = 0.0
        self.new_match()
        self.start_versus()
        self.toast("MATCH FOUND  -  %s" % self.pvp["opp"].upper(), CYAN)

    def find_online(self):
        """Ask the page to look for an opponent. It sends back a start message."""
        if not self.net.on:
            self.toast("ONLINE ONLY WORKS ON THE WEBSITE", (255, 150, 150))
            return
        owned = self.owned_cards()
        if not owned:
            self.toast("YOU DON'T OWN ANY PLAYERS YET", (255, 150, 150))
            return
        squad = [c for c in owned if c["id"] in self.save["squad"]] or owned
        best = max(squad, key=lambda c: c["rating"])
        self.searching = {"t": 0.0, "card": best["id"]}
        self.net.send({"t": "find", "ranked": True, "card": best["id"]})
        self.toast("LOOKING FOR AN OPPONENT...", CYAN)

    def cancel_search(self):
        if getattr(self, "searching", None):
            self.net.send({"t": "cancel"})
            self.searching = None
            self.toast("SEARCH CANCELLED", WHITE)

    def pvp_host(self):
        return self.pvp is not None and self.pvp["role"] == "host"

    def leave_pvp(self, why=None):
        self.pvp = None
        self.mode = "free"
        self.quit_prompt = False
        self.paused = False
        self.versus = None
        self.slowmo = 1.0
        self.dragging = False
        self.brain.skill = DIFFICULTY[self.difficulty][1]
        self.state = TITLE
        self.menu_page = "play"
        if why:
            self.toast(why, (255, 150, 150))

    def net_pump(self, dt):
        """Read whatever the page has for us, then (as host) send the world back."""
        for msg in self.net.poll():
            kind = msg.get("t")
            if kind == "start":
                self.searching = None
                self.start_pvp(msg)
            elif kind == "searching":
                self.searching = {"t": 0.0, "card": None}
            elif kind == "nomatch":
                self.searching = None
                self.toast(msg.get("why", "NOBODY AROUND RIGHT NOW"), (255, 150, 150))
            elif kind == "chat":
                self.chat_log.append([msg.get("from", "?"), msg.get("text", ""), 0.0])
                del self.chat_log[:-12]
            elif kind == "left" and self.pvp is not None:
                self.finish_pvp(walkover=True)
            elif kind == "snap" and self.pvp is not None and not self.pvp_host():
                self.apply_snapshot(msg)
            elif kind == "input" and self.pvp is not None and self.pvp_host():
                self.apply_remote_throw(msg)
        if self.searching:
            self.searching["t"] += dt
        for line in self.chat_log:
            line[2] += dt
        self.chat_log = [c for c in self.chat_log if c[2] < CHAT_SECONDS]

        if self.pvp is not None and self.pvp_host() and self.state in (KICKOFF, PLAY, GOAL, FULLTIME):
            self.net_t -= dt
            if self.net_t <= 0.0:
                self.net_t = 1.0 / NET_SNAP_HZ
                self.send_snapshot()

    def doll_state(self, d):
        return [round(d.pos.x, 1), round(d.pos.y, 1), round(d.vel.x, 1), round(d.vel.y, 1),
                round(d.angle, 3), round(d.av, 3)]

    def send_snapshot(self):
        b = self.ball
        self.net.send({
            "t": "snap",
            "p": self.doll_state(self.player), "c": self.doll_state(self.cpu),
            "b": [round(b.pos.x, 1), round(b.pos.y, 1), round(b.vel.x, 1), round(b.vel.y, 1),
                  round(b.spin, 1), 1 if b.frozen else 0],
            "s": [self.score_home, self.score_away],
            "k": round(self.match_time, 2), "h": self.half, "st": self.state,
        })

    def apply_doll(self, d, v, pull):
        if not v or len(v) < 6:
            return
        d.pos.x += (v[0] - d.pos.x) * pull
        d.pos.y += (v[1] - d.pos.y) * pull
        d.vel.update(v[2], v[3])
        d.angle += (v[4] - d.angle) * pull
        d.av = v[5]

    @staticmethod
    def flip_doll(v):
        """Host coordinates -> guest coordinates. Both players see themselves on the left."""
        if not v or len(v) < 6:
            return v
        return [WIDTH - v[0], v[1], -v[2], v[3], -v[4], -v[5]]

    def apply_snapshot(self, msg):
        """Guest: the host's world is the real one - slide onto it rather than snapping.
        Everything is mirrored, so the guest's own doll is always the one on the left."""
        pull = NET_LERP
        self.apply_doll(self.player, self.flip_doll(msg.get("c")), pull)   # mine = host's away doll
        self.apply_doll(self.cpu, self.flip_doll(msg.get("p")), pull)
        b = msg.get("b")
        if b and len(b) >= 6:
            self.ball.pos.x += ((WIDTH - b[0]) - self.ball.pos.x) * pull
            self.ball.pos.y += (b[1] - self.ball.pos.y) * pull
            self.ball.vel.update(-b[2], b[3])
            self.ball.spin = -b[4]
            self.ball.frozen = bool(b[5])
        sc = msg.get("s")
        if sc and len(sc) == 2:
            sc = [sc[1], sc[0]]                                            # their goals are my goals conceded
            if sc[0] > self.score_home or sc[1] > self.score_away:
                self.goal_text_pop = 0.0
                self.sfx.play("cheer", 0.6)
            self.score_home, self.score_away = sc[0], sc[1]
        self.match_time = msg.get("k", self.match_time)
        self.half = msg.get("h", self.half)
        st = msg.get("st")
        if st in (KICKOFF, PLAY, GOAL, FULLTIME) and st != self.state:
            self.state = st
            if st == FULLTIME:
                self.finish_pvp()

    def apply_remote_throw(self, msg):
        """Host: the guest let go somewhere - throw their doll at it."""
        target = Vector2(msg.get("x", 0.0), msg.get("y", 0.0))
        launch = target - self.cpu.pos
        if launch.length() > 1.0:
            self.cpu.throw(launch, self.throw_power_for(self.cpu, launch), self.sfx, self.particles)

    def throw_power_for(self, doll, launch):
        return lerp(THROW_MIN, doll.max_power(), clamp(launch.length() / doll.drag_range(), 0.0, 1.0))

    def send_chat(self, text):
        self.net.chat(text)
        self.chat_log.append([self.pvp["name"] if self.pvp else "YOU", text, 0.0])
        del self.chat_log[:-12]

    def finish_pvp(self, walkover=False):
        """Full time online: the host is the one who reports the score."""
        if self.pvp is None:
            return
        if walkover:
            self.score_home = max(self.score_home, self.score_away + 1)
            self.toast("OPPONENT LEFT  -  YOU WIN", YELLOW)
        self.net.result(self.score_home, self.score_away)   # both sides see themselves as home
        self.state = FULLTIME
        self.pvp["done"] = True

    def leave_freeplay(self):
        self.brain.skill = DIFFICULTY[self.difficulty][1]
        self.brain.impossible = self.difficulty == IMPOSSIBLE
        self.quit_prompt = False
        self.paused = False
        self.versus = None
        self.slowmo = 1.0
        self.dragging = False
        self.open_freeplay()

    def draw_freeplay(self, w):
        w.blit(self.shop_bg or self.select_bg, (0, 0))
        self.draw_back_button(w)
        self.draw_coins(w)
        f = self.free
        L = self.free_layout()
        mouse = pygame.mouse.get_pos()
        head = self.outlined("FREEPLAY", self.font_l, WHITE, 0.85, width=5)
        w.blit(head, head.get_rect(center=(760, 64)))
        sub = self.label("PICK YOUR PLAYER, THEN ANY PLAYER YOU OWN AS THE OPPONENT", 1000, (200, 214, 240))
        w.blit(sub, sub.get_rect(center=(820, 140)))
        for key, title in (("me", "YOU"), ("opp", "OPPONENT")):
            r = L[key]
            on = f["slot"] == key
            lab = self.label(title + ("  (PICKING)" if on else ""), r.w + 60, YELLOW if on else WHITE, self.font_s)
            w.blit(lab, lab.get_rect(center=(r.centerx, r.y - 44)))
            self.draw_card(w, self.cards[f[key]], r, glow=on)
        vs = self.outlined("VS", self.font_m, YELLOW, 1.0, INK, 4)
        w.blit(vs, vs.get_rect(center=(341, L["me"].centery)))
        w.blit(self.label("CPU DIFFICULTY", 540, (200, 214, 240)), (70, 604))
        for i, r in enumerate(L["diff"]):
            on = f["diff"] == i
            pygame.draw.rect(w, (40, 150, 70) if on else (30, 50, 90), r, border_radius=12)
            pygame.draw.rect(w, YELLOW if on or r.collidepoint(mouse) else WHITE, r, 3, border_radius=12)
            lab = self.label(DIFFICULTY[i][0], r.w - 20, WHITE)
            w.blit(lab, lab.get_rect(center=r.center))
        for key, txt, col in (("random", "RANDOM OPPONENT", (60, 70, 130)), ("play", "PLAY", (40, 170, 70))):
            r = L[key]
            pygame.draw.rect(w, col, r, border_radius=16)
            pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) else WHITE, r, 5, border_radius=16)
            lab = self.label(txt, r.w - 40, WHITE, self.font_l if key == "play" else self.font_m)
            w.blit(lab, lab.get_rect(center=r.center))
        note = self.label("REWARD: RANDOM %d-%d COINS  -  NO STAMINA USED" % FREE_REWARD, 540, YELLOW)
        w.blit(note, note.get_rect(center=(340, 856)))
        for c, r in L["grid"]:
            picked = c["id"] in (f["me"], f["opp"])
            self.draw_card(w, c, r, count=self.save["owned"].get(c["id"], 0),
                           glow=r.collidepoint(mouse) or picked)
        for key, txt in (("prev", "<"), ("next", ">")):
            pygame.draw.rect(w, (30, 50, 90), L[key], border_radius=12)
            pygame.draw.rect(w, YELLOW if L[key].collidepoint(mouse) else WHITE, L[key], 3, border_radius=12)
            self.centre_in(w, txt, L[key])
        pg = self.label("PAGE %d / %d  -  %d PLAYERS  -  DOUBLE-CLICK FOR STATS"
                        % (f["page"] + 1, self.free_pages(), len(self.owned_cards())), 900, (200, 214, 240))
        w.blit(pg, pg.get_rect(center=(1274, 1022)))

    # ================================================================ OPEN 10 PACKS AT ONCE
    def buy_pack10(self, pack):
        cost = PACK_PRICE * MULTI_PACKS
        if self.save["coins"] < cost:
            self.toast("OPEN 10x NEEDS %s COINS" % self.fmt(cost), (255, 150, 150))
            return False
        self.save["coins"] -= cost
        before = set(self.save["owned"])
        cards, new, seen = [], [], set()
        for _ in range(MULTI_PACKS):
            c = self.roll_pack(pack)                       # pity counts every single pack
            self.give_card(c)
            cards.append(c)
            new.append(c["id"] not in before and c["id"] not in seen)
            seen.add(c["id"])
        rank = {"A": 2, "B": 1, "C": 0}
        best_i = max(range(len(cards)), key=lambda i: (rank[self.card_pool(cards[i])], cards[i]["rating"]))
        best = cards[best_i]
        self.pack_reveal = {"card": best, "t": 0.0, "count": 1 if new[best_i] else self.save["owned"][best["id"]],
                            "pack": pack, "tier": self.card_pool(best), "opened": False,
                            "multi": {"cards": cards, "new": new, "pack": pack, "best": best_i}}
        self.fx = []
        self.state = PACK_OPEN
        self.write_save()
        return True

    def open_multi(self, m):
        self.multi = dict(m, t=0.0, boom=set())
        self.state = PACK_MULTI

    MULTI_FLIP_AT, MULTI_FLIP_GAP, MULTI_FLIP_LEN = 0.35, 0.2, 0.3

    def multi_done_at(self):
        return self.MULTI_FLIP_AT + (MULTI_PACKS - 1) * self.MULTI_FLIP_GAP + self.MULTI_FLIP_LEN

    def multi_layout(self):
        rects = []
        for i in range(len(self.multi["cards"])):
            r, k = divmod(i, 5)
            rects.append(pygame.Rect(305 + k * 270, 214 + r * 356, 230, 316))
        return rects, pygame.Rect(540, 930, 500, 100), pygame.Rect(1080, 930, 300, 100)

    def multi_click(self, pos):
        m = self.multi
        if m["t"] < self.multi_done_at():
            m["t"] = self.multi_done_at()                    # skip the flips
            return
        rects, again, done = self.multi_layout()
        for c, r in zip(m["cards"], rects):
            if r.collidepoint(pos.x, pos.y):
                self.card_detail = c
                return
        if again.collidepoint(pos.x, pos.y):
            self.buy_pack10(m["pack"])
            return
        self.open_packs(m["pack"])

    def draw_multi(self, w):
        m = self.multi
        w.blit(self.shop_bg or self.select_bg, (0, 0))
        self.draw_coins(w)
        n_new = sum(m["new"])
        head = self.outlined("%d PACKS OPENED" % len(m["cards"]), self.font_l, WHITE, 0.8, width=5)
        w.blit(head, head.get_rect(center=(WIDTH // 2, 58)))
        best = m["cards"][m["best"]]
        sub = self.label("%d NEW   -   BEST: %s %d" % (n_new, best["name"].upper(), best["rating"]), 1100,
                         (200, 214, 240))
        w.blit(sub, sub.get_rect(center=(WIDTH // 2, 124)))
        rects, again, done = self.multi_layout()
        mouse = pygame.mouse.get_pos()
        for i, (c, r) in enumerate(zip(m["cards"], rects)):
            p = (m["t"] - self.MULTI_FLIP_AT - i * self.MULTI_FLIP_GAP) / self.MULTI_FLIP_LEN
            front = p >= 0.5
            sx = abs(1.0 - 2.0 * clamp(p, 0.0, 1.0)) if 0.0 < p < 1.0 else 1.0
            if front and i not in m["boom"]:
                m["boom"].add(i)
                pool = self.card_pool(c)
                if pool in ("A", "B"):
                    self.burst_fireworks(r.centerx, r.centery, self.POOL_GLOW[pool], 50 if pool == "A" else 22)
            tmp = pygame.Surface((r.w + 40, r.h + 40), pygame.SRCALPHA)
            inner = pygame.Rect(20, 20, r.w, r.h)
            if front:
                self.draw_card(tmp, c, inner, glow=self.card_pool(c) == "A" or (p >= 1 and inner.move(
                    r.x - 20, r.y - 20).collidepoint(mouse)))
            elif self.card_back is not None:
                tmp.blit(pygame.transform.scale(self.card_back, inner.size), inner)
            else:
                pygame.draw.rect(tmp, (16, 20, 40), inner, border_radius=14)
            if sx < 1.0:
                tmp = pygame.transform.smoothscale(tmp, (max(1, int(tmp.get_width() * sx)), tmp.get_height()))
            w.blit(tmp, tmp.get_rect(center=r.center))
            if front and p >= 1.0 and m["new"][i]:
                tag = pygame.Rect(0, 0, 110, 40)
                tag.midbottom = (r.centerx, r.y - 4)
                pygame.draw.rect(w, (220, 40, 60), tag, border_radius=10)
                self.centre_in(w, "NEW", tag)
        self.draw_fx(w, 1.0 / FPS)
        if m["t"] >= self.multi_done_at():
            can = self.save["coins"] >= PACK_PRICE * MULTI_PACKS
            for r, txt, col in ((again, "OPEN 10 MORE  %s" % self.fmt(PACK_PRICE * MULTI_PACKS),
                                 (40, 170, 70) if can else (70, 90, 72)), (done, "CONTINUE", (40, 80, 170))):
                pygame.draw.rect(w, col, r, border_radius=16)
                pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) else WHITE, r, 5, border_radius=16)
                lab = self.label(txt, r.w - 40, WHITE, self.font_m)
                w.blit(lab, lab.get_rect(center=r.center))
            self.centre_text(w, "CLICK A CARD FOR ITS STATS", self.font_s, (200, 214, 240), 1044)
        else:
            self.centre_text(w, "CLICK TO SKIP", self.font_s, (170, 176, 190), 1000)

    # ================================================================ STORE: packs, Star Signing, exchange
    def open_store(self):
        self.store_confirm = None
        self.state = STORE

    def star_points(self):
        return int(self.save.get("star_points", 0))

    @staticmethod
    def fmt(n):
        return "{:,}".format(int(n))

    def draw_sp_icon(self, w, centre, r=20):
        x, y = int(centre[0]), int(centre[1])
        pygame.draw.circle(w, (96, 34, 170), (x, y), r)
        pygame.draw.circle(w, STAR_LILAC, (x, y), r, max(2, r // 6))
        pts = []
        for k in range(10):
            a = -math.pi / 2 + k * math.pi / 5
            rad = r * (0.72 if k % 2 == 0 else 0.3)
            pts.append((x + math.cos(a) * rad, y + math.sin(a) * rad))
        pygame.draw.polygon(w, WHITE, pts)

    def draw_star_points(self, w, y=112):
        t = self.font_m.render("%s SP" % self.fmt(self.star_points()), True, STAR_LILAC)
        w.blit(t, (WIDTH - 60 - t.get_width(), y))
        self.draw_sp_icon(w, (WIDTH - 60 - t.get_width() - 30, y + 24), 20)

    def draw_purple_bg(self, w):
        if self.star_bg is not None:
            w.blit(self.star_bg, (0, 0))
        else:
            w.fill((30, 10, 60))

    # ---- store hub ---------------------------------------------------------
    STORE_TILES = (("packs", "PACKS", "300 COINS EACH"), ("stars", "STAR SIGNING", "40 ELITE LEGENDS"),
                   ("exchange", "EXCHANGE", "PLAYERS FOR STAR POINTS"), ("box", "NEYMAR JR GAME BOX", "13 DRAWS"))

    def store_layout(self):
        w, h, gap = 400, 560, 40
        x0 = (WIDTH - (4 * w + 3 * gap)) // 2
        return [pygame.Rect(x0 + i * (w + gap), 230, w, h) for i in range(4)]

    def store_click(self, pos):
        if pygame.Rect(40, 30, 200, 70).collidepoint(pos.x, pos.y):
            self.state = TITLE
            return
        for (key, _t, _s), rect in zip(self.STORE_TILES, self.store_layout()):
            if rect.collidepoint(pos.x, pos.y):
                if key == "packs":
                    self.state = PACKS
                elif key == "stars":
                    self.open_stars()
                elif key == "exchange":
                    self.open_exchange()
                else:
                    self.open_event()
                return

    def draw_store(self, w):
        w.blit(self.shop_bg or self.select_bg, (0, 0))
        self.draw_back_button(w)
        self.draw_coins(w)
        self.draw_star_points(w)
        self.centre_text(w, "STORE", self.font_l, WHITE, 40)
        mouse = pygame.mouse.get_pos()
        t = pygame.time.get_ticks() * 0.001
        cols = {"packs": ((24, 70, 40), YELLOW), "stars": ((58, 18, 104), STAR_LILAC),
                "exchange": ((34, 30, 70), (140, 220, 255)), "box": ((0, 96, 46), (254, 214, 0))}
        for (key, title, sub), rect in zip(self.STORE_TILES, self.store_layout()):
            hover = rect.collidepoint(mouse)
            r = rect.move(0, -8 if hover else 0)
            bg, edge = cols[key]
            pygame.draw.rect(w, bg, r, border_radius=22)
            art = pygame.Rect(r.x + 16, r.y + 16, r.w - 32, r.h - 170)
            pygame.draw.rect(w, _shade(bg, 0.6), art, border_radius=16)
            self.draw_store_tile_art(w, key, art, t)
            pygame.draw.rect(w, YELLOW if hover else edge, r, 6, border_radius=22)
            lab = self.label(title, r.w - 40, WHITE, self.font_m)
            w.blit(lab, lab.get_rect(center=(r.centerx, r.bottom - 112)))
            if key == "box":
                sub = "DRAW %d / %d" % (min(len(self.event_state()["claimed"]) + 1, len(NEYMAR_REWARDS)),
                                        len(NEYMAR_REWARDS))
            elif key == "stars":
                sub = "SIGNED %d / %d" % (sum(1 for c in self.star_ids if c in self.save["owned"]),
                                          len(self.star_ids))
            elif key == "exchange":
                sub = "%d PLAYERS TO EXCHANGE" % sum(n for _c, n in self.exchange_list(False))
            sl = self.label(sub, r.w - 40, edge)
            w.blit(sl, sl.get_rect(center=(r.centerx, r.bottom - 50)))
        foot = self.label("EXCHANGE PLAYERS YOU DON'T USE FOR STAR POINTS  -  THEN SIGN LEGENDS IN STAR SIGNING",
                          WIDTH - 200, (220, 210, 240))
        w.blit(foot, foot.get_rect(center=(WIDTH // 2, 870)))

    def store_star_art(self, cid, size, ang):
        """The little tilted star cards on the store tile - drawn once, then blitted."""
        cache = getattr(self, "_store_stars", None)
        if cache is None:
            cache = self._store_stars = {}
        key = (cid, tuple(size), ang)
        img = cache.get(key)
        if img is None:
            img = pygame.Surface((size[0] + 40, size[1] + 40), pygame.SRCALPHA)
            self.draw_star_card(img, self.cards[cid], pygame.Rect(20, 20, *size))
            if ang:
                img = pygame.transform.rotate(img, ang)
            cache[key] = img
        return img

    def draw_store_tile_art(self, w, key, art, t):
        cx, cy = art.center
        if key == "packs":
            for i, k in enumerate((1, 2, 0)):
                img = self.pack_art[k]
                if img is None:
                    continue
                img = rotated(scaled(img, (170, 238)), (i - 1) * -12)
                w.blit(img, img.get_rect(center=(cx + (i - 1) * 95, cy + abs(i - 1) * 18)))
        elif key == "stars":
            for cid, dx, ang, size in (("STAR_r9", -110, 14, (136, 190)), ("STAR_maradona", 110, -14, (136, 190)),
                                       ("STAR_pele", 0, 0, (176, 245))):
                tmp = self.store_star_art(cid, size, ang)
                w.blit(tmp, tmp.get_rect(center=(cx + dx, cy + (14 if ang else 0))))
        elif key == "exchange":
            r = pygame.Rect(0, 0, 150, 208)
            r.center = (cx - 90, cy)
            ex = self.exchange_list(False)
            if ex:
                self.draw_card(w, ex[0][0], r)
            elif self.card_back is not None:
                w.blit(scaled(self.card_back, r.size), r)
            bob = math.sin(t * 3) * 8
            pts = [(cx - 2 + bob, cy - 22), (cx + 34 + bob, cy - 22), (cx + 34 + bob, cy - 44),
                   (cx + 74 + bob, cy), (cx + 34 + bob, cy + 44), (cx + 34 + bob, cy + 22), (cx - 2 + bob, cy + 22)]
            pygame.draw.polygon(w, (140, 220, 255), pts)
            self.draw_sp_icon(w, (cx + 120, cy), 46)
        else:
            img = self.box_art
            if img is not None:
                img = scaled(img, (220, 308))
                w.blit(img, img.get_rect(center=(cx, cy)))

    # ---- Star Signing card --------------------------------------------------
    def card_overlays(self, surf, rect, count=0, stamina=None, dim=False, card_for_pips=None):
        if card_for_pips is not None:
            self.draw_ability_pips(surf, card_for_pips, rect)
        if count > 1:
            c = self.font_s.render("x%d" % count, True, WHITE)
            pygame.draw.circle(surf, (200, 40, 40), (rect.right - 8, rect.bottom - 8), 24)
            surf.blit(c, c.get_rect(center=(rect.right - 8, rect.bottom - 8)))
        if stamina is not None:
            bar = pygame.Rect(rect.x, rect.bottom + 22, rect.w, 16)
            pygame.draw.rect(surf, (30, 30, 30), bar)
            col = (90, 220, 90) if stamina > 50 else ((240, 200, 60) if stamina > 0 else (220, 60, 60))
            pygame.draw.rect(surf, col, (bar.x, bar.y, int(bar.w * stamina / 100), bar.h))
            pygame.draw.rect(surf, WHITE, bar, 2)
        if dim:
            surf.blit(tint((rect.w, rect.h), (0, 0, 0, 150)), rect.topleft)

    def draw_star_card(self, surf, card, rect, count=0, stamina=None, dim=False, glow=False):
        """Star Signing Elite: purple frame, silver trim, geometric purple, STAR SIGNING band."""
        W, H = rect.w, rect.h
        t = pygame.time.get_ticks() * 0.001
        rookie = card["design"] == "beginner"
        accent = ROOKIE_MINT if rookie else STAR_LILAC
        deep = (8, 60, 36) if rookie else (44, 8, 92)
        if glow:
            pulse = int(12 + 8 * (0.5 + 0.5 * math.sin(t * 3)))
            pygame.draw.rect(surf, (110, 240, 170) if rookie else (196, 120, 255), rect.inflate(pulse, pulse),
                             border_radius=18)
        tpl = self.card_template("rookie" if rookie else "star", W, H)
        if tpl is None:                                    # art missing: plain purple card
            pygame.draw.rect(surf, (98, 34, 176), rect, border_radius=14)
            pygame.draw.rect(surf, (226, 228, 240), rect, max(2, W // 40), border_radius=14)
        else:
            img, ox, oy, _b = tpl
            surf.blit(img, (rect.x - ox, rect.y - oy))
        face = self.card_faces.get(card["id"])
        if face is not None:
            fw = int(W * 0.84)
            img = scaled(face, (fw, fw))
            surf.blit(img, img.get_rect(midbottom=(rect.x + W // 2 + int(W * 0.08), rect.y + int(H * 0.705))))
        else:
            head = self.card_head(card)
            if head is not None:
                hh = fit_flag(head, int(W * 0.5), int(W * 0.5))
                surf.blit(hh, hh.get_rect(center=(rect.centerx, rect.y + int(H * 0.42))))
        num = self.fit_text(str(card["rating"]), self.font_xl, WHITE, W * 0.36, H * 0.115, deep)
        surf.blit(num, (rect.x + int(W * 0.065), rect.y + int(H * 0.035)))
        pos = self.fit_text(card["pos"], self.font_m, accent, W * 0.26, H * 0.058)
        surf.blit(pos, (rect.x + int(W * 0.085), rect.y + int(H * 0.045) + num.get_height()))
        name = card["name"].upper()
        if len(name) > 13 and " " in name:                 # "VIRGIL VAN DIJK" -> "VAN DIJK"
            rest = " ".join(name.split()[1:])
            name = rest if len(rest) <= 13 else name.split()[-1]
        nm = self.fit_text(name, self.font_m, WHITE, W * 0.84, H * 0.06)
        surf.blit(nm, nm.get_rect(center=(rect.centerx, rect.y + int(H * 0.743))))
        row_y = rect.y + int(H * 0.925)                    # flag + club badge along the bottom
        items = [im for im in (self.card_flag(card), self.card_badge(card)) if im is not None]
        for i, im in enumerate(items):
            b = fit_flag(im, int(W * 0.17), int(H * 0.066))
            cx = rect.centerx + int((i - (len(items) - 1) / 2) * W * 0.24)
            surf.blit(b, b.get_rect(center=(cx, row_y)))
        if len(items) == 2:
            pygame.draw.line(surf, (226, 228, 240), (rect.centerx, row_y - int(H * 0.028)),
                             (rect.centerx, row_y + int(H * 0.028)), max(1, int(W / 140)))
        self.card_overlays(surf, rect, count, stamina, dim, card)

    # ---- Star Signing shop ---------------------------------------------------
    def open_stars(self):
        self.store_confirm = None
        if self.stars_sel not in self.cards:
            self.stars_sel = self.star_ids[0]
        self.state = STARS

    def stars_layout(self):
        L = {"card": pygame.Rect(80, 170, 380, 528), "buy": pygame.Rect(80, 930, 560, 104),
             "prev": pygame.Rect(680, 990, 110, 64), "next": pygame.Rect(1764, 990, 110, 64), "grid": []}
        page = self.star_ids[self.stars_page * STARS_PER_PAGE:(self.stars_page + 1) * STARS_PER_PAGE]
        for i, cid in enumerate(page):
            r, k = divmod(i, 7)
            L["grid"].append((cid, pygame.Rect(680 + k * 172, 186 + r * 266, 160, 222)))
        return L

    def star_pages(self):
        return max(1, math.ceil(len(self.star_ids) / STARS_PER_PAGE))

    def turn_page(self, step):
        if self.state == STARS:
            self.stars_page = (self.stars_page + step) % self.star_pages()
        elif self.state == EXCHANGE:
            self.exchange_page = (self.exchange_page + step) % self.exchange_pages()

    def store_page_event(self, event):
        """Mouse wheel turns pages in the Star Signing shop and the exchange."""
        if self.store_confirm is not None or self.card_detail is not None:
            return False
        if hasattr(pygame, "MOUSEWHEEL"):
            if event.type == pygame.MOUSEWHEEL:
                self.turn_page(-1 if getattr(event, "y", 0) > 0 else 1)
                return True
            return event.type == pygame.MOUSEBUTTONDOWN and event.button in (4, 5)   # wheel "clicks"
        if event.type == pygame.MOUSEBUTTONDOWN and event.button in (4, 5):
            self.turn_page(-1 if event.button == 4 else 1)
            return True
        return False

    def stars_click(self, pos):
        if self.store_confirm is not None:
            self.store_confirm_click(pos)
            return
        L = self.stars_layout()
        if pygame.Rect(40, 30, 200, 70).collidepoint(pos.x, pos.y):
            self.open_store()
            return
        if L["prev"].collidepoint(pos.x, pos.y):
            self.turn_page(-1)
            return
        if L["next"].collidepoint(pos.x, pos.y):
            self.turn_page(1)
            return
        card = self.cards[self.stars_sel]
        if L["card"].collidepoint(pos.x, pos.y):
            self.card_detail = card
            return
        if L["buy"].collidepoint(pos.x, pos.y):
            self.ask_signing(card)
            return
        now = pygame.time.get_ticks() / 1000.0
        for cid, r in L["grid"]:
            if r.collidepoint(pos.x, pos.y):
                if cid == self.stars_sel and now - getattr(self, "stars_click_t", -9.0) < DOUBLE_CLICK:
                    self.card_detail = self.cards[cid]          # double-click: stats
                self.stars_sel = cid
                self.stars_click_t = now
                return

    def ask_signing(self, card):
        if card["id"] in self.save["owned"]:
            self.toast("%s IS ALREADY AT YOUR CLUB" % card["name"].upper(), STAR_LILAC)
            return
        need = card["price"] - self.star_points()
        if need > 0:
            self.toast("NOT ENOUGH STAR POINTS - %s MORE NEEDED" % self.fmt(need), (255, 140, 140))
            return
        self.store_confirm = {"card": card, "title": "SIGN %s?" % card["name"].upper(), "ok": "SIGN",
                              "lines": ["%s STAR POINTS" % self.fmt(card["price"]),
                                        "YOU'LL HAVE %s SP LEFT" % self.fmt(self.star_points() - card["price"]),
                                        "STAR SIGNINGS CAN'T BE EXCHANGED"],
                              "action": lambda c=card: self.sign_star(c)}

    def sign_star(self, card):
        if card["id"] in self.save["owned"] or self.star_points() < card["price"]:
            return False
        self.save["star_points"] = self.star_points() - card["price"]
        count = self.give_card(card)
        self.pack_reveal = {"card": card, "t": 0.0, "count": count, "pack": 0, "tier": self.card_pool(card),
                            "opened": False, "back": "stars", "art": self.star_pack}
        self.fx = []
        self.state = PACK_OPEN
        self.write_save()
        return True

    def draw_stars(self, w):
        self.draw_purple_bg(w)
        self.draw_back_button(w)
        self.draw_coins(w)
        self.draw_star_points(w)
        head = self.outlined("STAR SIGNING", self.font_l, WHITE, 0.82, (60, 14, 110), 5)
        w.blit(head, head.get_rect(center=(760, 64)))
        sub = self.label("ELITE  -  EACH LEGEND CAN BE SIGNED ONCE", 700, STAR_LILAC)
        w.blit(sub, sub.get_rect(center=(800, 140)))
        L = self.stars_layout()
        mouse = pygame.mouse.get_pos()
        card = self.cards[self.stars_sel]
        owned = card["id"] in self.save["owned"]
        # left: the selected legend
        self.draw_star_card(w, card, L["card"], glow=True)
        look = self.card_original_look(card)
        pygame.draw.ellipse(w, (70, 26, 130), (512, 606, 140, 34))
        pygame.draw.ellipse(w, STAR_LILAC, (512, 606, 140, 34), 3)
        if look:
            self.draw_look_preview(w, look, (582, 452))
        kit = self.label("CLUB KIT", 130, STAR_LILAC)
        w.blit(kit, kit.get_rect(center=(582, 666)))
        nm = self.label(card["name"].upper(), 560, WHITE, self.font_m)
        w.blit(nm, (80, 724))
        sub = "%s  -  %s  -  %s" % (card["pos"], NATION_NAMES.get(card["nation"], card["nation"]),
                                    STAR_CLUB_NAMES.get(card["team"], card["team"]).upper())
        w.blit(self.label(sub, 560, (220, 210, 240)), (80, 796))
        if owned:
            w.blit(self.font_m.render("SIGNED", True, (120, 240, 140)), (80, 846))
        else:
            self.draw_sp_icon(w, (102, 878), 22)
            w.blit(self.font_m.render("%s SP" % self.fmt(card["price"]), True, STAR_LILAC), (136, 846))
        can = not owned and self.star_points() >= card["price"]
        b = L["buy"]
        hover = b.collidepoint(mouse)
        pygame.draw.rect(w, (126, 52, 220) if can else (60, 46, 84), b, border_radius=18)
        pygame.draw.rect(w, YELLOW if hover and can else (226, 228, 240), b, 5, border_radius=18)
        if owned:
            txt = "SIGNED - IN YOUR CLUB"
        elif can:
            txt = "SIGN FOR %s SP" % self.fmt(card["price"])
        else:
            txt = "NEED %s MORE SP" % self.fmt(card["price"] - self.star_points())
        lab = self.label(txt, b.w - 40, WHITE if can or owned else (190, 180, 210), self.font_m)
        w.blit(lab, lab.get_rect(center=b.center))
        # right: all the legends
        for cid, r in L["grid"]:
            c = self.cards[cid]
            sel = cid == self.stars_sel
            self.draw_star_card(w, c, r, glow=sel or r.collidepoint(mouse))
            tag = pygame.Rect(r.x + 8, r.bottom + 6, r.w - 16, 34)
            got = cid in self.save["owned"]
            pygame.draw.rect(w, (40, 120, 60) if got else (40, 14, 76), tag, border_radius=10)
            pygame.draw.rect(w, (226, 228, 240) if sel else (120, 80, 170), tag, 2, border_radius=10)
            if got:
                self.centre_in(w, "SIGNED", tag)
            else:
                self.draw_sp_icon(w, (tag.x + 20, tag.centery), 12)
                txt = self.fit_text("%dK" % (c["price"] // 1000), self.font_s, WHITE, tag.w - 50, tag.h - 8)
                w.blit(txt, txt.get_rect(center=(tag.centerx + 12, tag.centery)))
        for key, txt in (("prev", "<"), ("next", ">")):
            pygame.draw.rect(w, (90, 36, 160), L[key], border_radius=12)
            pygame.draw.rect(w, YELLOW if L[key].collidepoint(mouse) else WHITE, L[key], 3, border_radius=12)
            self.centre_in(w, txt, L[key])
        pg = self.label("PAGE %d / %d  -  SCROLL FOR MORE" % (self.stars_page + 1, self.star_pages()), 900,
                        (220, 210, 240))
        w.blit(pg, pg.get_rect(center=(1277, 1022)))
        if self.store_confirm is not None:
            self.draw_store_confirm(w)

    # ---- exchange: players -> Star Points ------------------------------------------------
    def can_exchange(self, card):
        return card["kind"] != "star" and card["id"] not in NO_EXCHANGE

    def exchange_list(self, dupes_only=None):
        """[(card, copies you can exchange)] - squad players always keep one copy."""
        dupes_only = self.exchange_dupes if dupes_only is None else dupes_only
        out = []
        squad = self.save["squad"]
        for cid, n in self.save["owned"].items():
            c = self.cards.get(cid)
            if c is None or not self.can_exchange(c):
                continue
            spare = n - 1 if (dupes_only or cid in squad) else n
            if spare > 0:
                out.append((c, spare))
        return sorted(out, key=lambda e: (-e[0]["rating"], e[0]["name"]))

    def exchange_pages(self):
        return max(1, math.ceil(len(self.exchange_list()) / EXCHANGE_PER_PAGE))

    def open_exchange(self):
        self.store_confirm = None
        self.exchange_page = 0
        self.state = EXCHANGE

    def exchange_layout(self):
        L = {"all": pygame.Rect(290, 172, 300, 64), "dupes": pygame.Rect(606, 172, 360, 64),
             "bulk": pygame.Rect(1150, 172, 480, 64), "prev": pygame.Rect(110, 540, 110, 110),
             "next": pygame.Rect(1700, 540, 110, 110), "grid": []}
        items = self.exchange_list()
        pages = max(1, math.ceil(len(items) / EXCHANGE_PER_PAGE))
        self.exchange_page %= pages
        page = items[self.exchange_page * EXCHANGE_PER_PAGE:(self.exchange_page + 1) * EXCHANGE_PER_PAGE]
        for i, (c, n) in enumerate(page):
            r, k = divmod(i, 8)
            L["grid"].append((c, n, pygame.Rect(290 + k * 170, 258 + r * 256, 150, 208)))
        return L

    def dupes_total(self):
        dupes = self.exchange_list(True)
        return sum(n for _c, n in dupes), sum(n * star_points_for(c["rating"]) for c, n in dupes)

    def exchange_click(self, pos):
        if self.store_confirm is not None:
            self.store_confirm_click(pos)
            return
        L = self.exchange_layout()
        if pygame.Rect(40, 30, 200, 70).collidepoint(pos.x, pos.y):
            self.open_store()
            return
        if L["all"].collidepoint(pos.x, pos.y) or L["dupes"].collidepoint(pos.x, pos.y):
            self.exchange_dupes = L["dupes"].collidepoint(pos.x, pos.y)
            self.exchange_page = 0
            return
        if L["prev"].collidepoint(pos.x, pos.y):
            self.turn_page(-1)
            return
        if L["next"].collidepoint(pos.x, pos.y):
            self.turn_page(1)
            return
        if L["bulk"].collidepoint(pos.x, pos.y):
            n, sp = self.dupes_total()
            if n == 0:
                self.toast("NO DUPLICATES TO EXCHANGE", (220, 210, 240))
                return
            self.store_confirm = {"card": None, "title": "EXCHANGE ALL DUPLICATES?", "ok": "EXCHANGE",
                                  "lines": ["%d CARDS  ->  +%s STAR POINTS" % (n, self.fmt(sp)),
                                            "YOU KEEP ONE COPY OF EVERY PLAYER"],
                                  "action": self.exchange_all_dupes}
            return
        for c, n, r in L["grid"]:
            if r.collidepoint(pos.x, pos.y):
                self.card_click(c, lambda card=c: self.ask_exchange(card))
                return

    def ask_exchange(self, card):
        if self.state != EXCHANGE or not self.can_exchange(card):
            return
        n = self.save["owned"].get(card["id"], 0)
        if n <= 0 or (n <= 1 and card["id"] in self.save["squad"]):
            return
        left = n - 1
        self.store_confirm = {"card": card, "title": "EXCHANGE %s?" % card["name"].upper(), "ok": "EXCHANGE",
                              "lines": ["+%s STAR POINTS" % self.fmt(star_points_for(card["rating"])),
                                        "YOU'LL HAVE %d LEFT" % left if left else "LAST COPY - HE LEAVES YOUR CLUB"],
                              "action": lambda c=card: self.exchange_card(c)}

    def exchange_card(self, card, copies=1, save=True):
        """Swap copies of a card for Star Points. Returns the points earned."""
        cid = card["id"]
        owned = self.save["owned"]
        n = owned.get(cid, 0)
        keep = 1 if cid in self.save["squad"] else 0
        copies = min(copies, n - keep)
        if copies <= 0 or not self.can_exchange(card):
            return 0
        owned[cid] = n - copies
        if owned[cid] <= 0:
            del owned[cid]
            self.save["stamina"].pop(cid, None)
        sp = copies * star_points_for(card["rating"])
        self.save["star_points"] = self.star_points() + sp
        if save:
            self.toast("+%s STAR POINTS" % self.fmt(sp), STAR_LILAC)
            self.burst_fireworks(WIDTH // 2, HEIGHT // 2, STAR_LILAC, 30)
            self.write_save()
        return sp

    def exchange_all_dupes(self):
        total = 0
        for c, n in self.exchange_list(True):
            total += self.exchange_card(c, n, save=False)
        if total:
            self.toast("+%s STAR POINTS" % self.fmt(total), STAR_LILAC)
            self.burst_fireworks(WIDTH // 2, HEIGHT // 2, STAR_LILAC, 60)
        self.write_save()
        return total

    def draw_exchange(self, w):
        self.draw_purple_bg(w)
        wash(w, (8, 4, 20, 110))
        self.draw_back_button(w)
        self.draw_coins(w)
        self.draw_star_points(w)
        head = self.outlined("EXCHANGE", self.font_l, WHITE, 0.9, (60, 14, 110), 5)
        w.blit(head, head.get_rect(center=(WIDTH // 2, 64)))
        hint = self.label("CLICK A PLAYER TO EXCHANGE HIM  -  DOUBLE-CLICK FOR STATS", 900, (210, 200, 235))
        w.blit(hint, hint.get_rect(center=(WIDTH // 2 - 60, 132)))
        L = self.exchange_layout()
        mouse = pygame.mouse.get_pos()
        for key, txt, on in (("all", "ALL PLAYERS", not self.exchange_dupes),
                             ("dupes", "DUPLICATES ONLY", self.exchange_dupes)):
            r = L[key]
            pygame.draw.rect(w, (126, 52, 220) if on else (46, 24, 80), r, border_radius=14)
            pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) else (226, 228, 240), r, 3, border_radius=14)
            lab = self.label(txt, r.w - 30, WHITE)
            w.blit(lab, lab.get_rect(center=r.center))
        n, sp = self.dupes_total()
        r = L["bulk"]
        pygame.draw.rect(w, (30, 110, 70) if n else (40, 40, 56), r, border_radius=14)
        pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) and n else (226, 228, 240), r, 3, border_radius=14)
        lab = self.label("EXCHANGE ALL DUPES  +%s SP" % self.fmt(sp) if n else "NO DUPLICATES", r.w - 30, WHITE)
        w.blit(lab, lab.get_rect(center=r.center))
        if not L["grid"]:
            self.centre_text(w, "NOTHING TO EXCHANGE" if not self.exchange_dupes else "NO DUPLICATES YET",
                             self.font_m, WHITE, 480)
            self.centre_text(w, "OPEN PACKS TO GET MORE PLAYERS", self.font_s, (210, 200, 235), 570)
        for c, copies, r in L["grid"]:
            hover = r.collidepoint(mouse)
            self.draw_card(w, c, r, count=copies, glow=hover)
            tag = pygame.Rect(r.x, r.bottom + 8, r.w, 34)
            pygame.draw.rect(w, (40, 14, 76), tag, border_radius=10)
            pygame.draw.rect(w, STAR_LILAC if hover else (120, 80, 170), tag, 2, border_radius=10)
            self.draw_sp_icon(w, (tag.x + 18, tag.centery), 12)
            txt = self.label("+%s" % self.fmt(star_points_for(c["rating"])), tag.w - 44, WHITE)
            w.blit(txt, txt.get_rect(center=(tag.centerx + 12, tag.centery)))
        pages = self.exchange_pages()
        if pages > 1:
            for key, txt in (("prev", "<"), ("next", ">")):
                pygame.draw.rect(w, (90, 36, 160), L[key], border_radius=14)
                pygame.draw.rect(w, YELLOW if L[key].collidepoint(mouse) else WHITE, L[key], 3, border_radius=14)
                self.centre_in(w, txt, L[key], self.font_m)
        pg = self.label("%d / %d" % (self.exchange_page + 1, pages), 170, WHITE, self.font_m)
        w.blit(pg, pg.get_rect(center=(1058, 204)))
        rule = self.label("SQUAD PLAYERS ALWAYS KEEP ONE COPY  -  NEYMAR JR AND STAR SIGNINGS "
                          "CAN'T BE EXCHANGED", WIDTH - 160, (190, 180, 220))
        w.blit(rule, rule.get_rect(center=(WIDTH // 2, 1050)))
        self.draw_fx(w, 1.0 / FPS)
        if self.store_confirm is not None:
            self.draw_store_confirm(w)

    # ---- yes / no popup ------------------------------------------------------------
    def store_confirm_layout(self):
        panel = pygame.Rect(420, 230, 1080, 600)
        return panel, pygame.Rect(880, 690, 300, 96), pygame.Rect(1200, 690, 260, 96)

    def store_confirm_click(self, pos):
        panel, ok, cancel = self.store_confirm_layout()
        pc = self.store_confirm
        if ok.collidepoint(pos.x, pos.y):
            self.store_confirm = None
            pc["action"]()
        elif cancel.collidepoint(pos.x, pos.y) or not panel.collidepoint(pos.x, pos.y):
            self.store_confirm = None

    def draw_store_confirm(self, w):
        pc = self.store_confirm
        wash(w, (6, 2, 14, 200))
        panel, ok, cancel = self.store_confirm_layout()
        pygame.draw.rect(w, (36, 14, 66), panel, border_radius=26)
        pygame.draw.rect(w, STAR_LILAC, panel, 5, border_radius=26)
        x = 900
        if pc["card"] is not None:
            self.draw_card(w, pc["card"], pygame.Rect(480, 290, 340, 472), glow=True)
        else:
            self.draw_sp_icon(w, (650, 520), 120)
            x = 900
        title = self.label(pc["title"], panel.right - x - 40, WHITE, self.font_m)
        w.blit(title, (x, 300))
        for i, line in enumerate(pc["lines"]):
            col = STAR_LILAC if i == 0 else (220, 214, 236)
            img = self.label(line, panel.right - x - 40, col, self.font_m if i == 0 else None)
            if i == 0:
                self.draw_sp_icon(w, (x + 22, 420), 22)
                w.blit(img, (x + 56, 392))
            else:
                w.blit(img, (x, 440 + i * 60))
        mouse = pygame.mouse.get_pos()
        for r, txt, col in ((ok, pc["ok"], (126, 52, 220)), (cancel, "CANCEL", (70, 60, 90))):
            pygame.draw.rect(w, col, r, border_radius=18)
            pygame.draw.rect(w, YELLOW if r.collidepoint(mouse) else WHITE, r, 5, border_radius=18)
            lab = self.label(txt, r.w - 36, WHITE, self.font_m)
            w.blit(lab, lab.get_rect(center=r.center))

    # ================================================================ NEYMAR JR GAME BOX
    def event_state(self):
        ev = self.save.setdefault("neymar_box", {})
        if ev.get("v") != BOX_VERSION:                     # the box was rebalanced: fresh start
            ev.clear()
            ev.update({"v": BOX_VERSION, "claimed": [], "players": []})
        if len(ev["players"]) < 5:
            normal = [c for c in self.cards.values() if c["design"] not in ("icon", "signature")
                      and c["kind"] in ("wc", "club")]

            def pick(lo, hi, n=1, taken=()):
                pool = [c["id"] for c in normal if lo <= c["rating"] <= hi and c["id"] not in taken]
                return random.sample(pool, min(n, len(pool)))
            chosen = pick(70, 89) + pick(90, 109) + pick(110, 119)       # bad, alright, good
            chosen += pick(120, 135, 2, chosen)                           # two pool A jackpots
            ev["players"] = chosen
            self.write_save()
        return ev

    def event_price(self):
        n = len(self.event_state()["claimed"])
        return NEYMAR_PRICES[n] if n < len(NEYMAR_PRICES) else None

    def open_event(self):
        self.event_state()
        self.event_spin = None
        self.event_popup = None
        self.state = EVENT

    def event_layout(self):
        tiles = [pygame.Rect(470 + (i % 4) * 218, 180 + (i // 4) * 188, 200, 170) for i in range(12)]
        return {"tiles": tiles, "prize": pygame.Rect(1370, 160, 380, 560),
                "buy": pygame.Rect(1370, 800, 420, 110), "back": pygame.Rect(40, 30, 200, 70)}

    def event_reward_card(self, i):
        kind, val = NEYMAR_REWARDS[i]
        if kind == "neymar":
            return self.cards[NEYMAR_CARD]
        if kind in ("player", "jackpot_player"):
            ids = self.event_state()["players"]
            return self.cards.get(ids[val]) if val < len(ids) else None
        return None

    def box_odds(self, left):
        """Chance of each unclaimed reward on the next draw."""
        ney = len(NEYMAR_REWARDS) - 1
        if left == [ney]:
            return {ney: 1.0}                              # pity: the last draw is Neymar
        odds = {}
        jack = [i for i in left if NEYMAR_REWARDS[i][0].startswith("jackpot")]
        filler = [i for i in left if i != ney and i not in jack]
        if ney in left:
            odds[ney] = NEYMAR_ODDS
        rest = 1.0 - sum(odds.values())
        if filler:
            for i in jack:
                odds[i] = JACKPOT_ODDS
            rest -= JACKPOT_ODDS * len(jack)
            for i in filler:
                odds[i] = rest / len(filler)
        else:
            for i in jack:
                odds[i] = rest / len(jack)
        return odds

    def event_click(self, pos):
        L = self.event_layout()
        if self.event_popup is not None:
            self.event_popup = None
            return
        if self.event_spin is not None:
            return
        if L["back"].collidepoint(pos.x, pos.y):
            self.open_store()
            return
        if L["buy"].collidepoint(pos.x, pos.y):
            self.event_draw()
            return
        for i, r in enumerate(L["tiles"]):
            card = self.event_reward_card(i)
            if card is not None and r.collidepoint(pos.x, pos.y):
                self.card_click(card, lambda: None)            # double-click = stats
        if L["prize"].collidepoint(pos.x, pos.y):
            self.card_click(self.cards[NEYMAR_CARD], lambda: None)

    def event_draw(self):
        price = self.event_price()
        if price is None:
            return False
        if self.save["coins"] < price:
            self.toast("NOT ENOUGH COINS - NEED %d" % price, (255, 120, 120))
            return False
        self.save["coins"] -= price
        ev = self.event_state()
        left = [i for i in range(len(NEYMAR_REWARDS)) if i not in ev["claimed"]]
        odds = self.box_odds(left)
        target = random.choices(list(odds), weights=list(odds.values()))[0]
        hops = []
        for _ in range(16 if len(left) > 1 else 1):
            hops.append(random.choice([i for i in left if not hops or i != hops[-1]] or left))
        hops.append(target)
        self.event_spin = {"hops": hops, "step": 0, "timer": 0.0, "interval": 0.07}
        self.write_save()
        return True

    def update_event(self, dt):
        sp = self.event_spin
        if sp is None:
            return
        sp["timer"] += dt
        if sp["timer"] < sp["interval"]:
            return
        sp["timer"] = 0.0
        if sp["step"] < len(sp["hops"]) - 1:
            sp["step"] += 1
            sp["interval"] *= 1.14
            return
        self.event_spin = None
        self.event_grant(sp["hops"][-1])

    def event_grant(self, i):
        ev = self.event_state()
        if i in ev["claimed"]:
            return
        ev["claimed"].append(i)
        kind, val = NEYMAR_REWARDS[i]
        if kind in ("coins", "jackpot_coins"):
            self.save["coins"] += val
            jack = kind == "jackpot_coins"
            self.event_popup = {"title": "+%d COINS" % val, "sub": "JACKPOT!" if jack else "", "kind": "coins"}
        elif kind == "training":
            self.save["training_coins"] = self.save.get("training_coins", 0) + val
            self.event_popup = {"title": "+%d TRAINING COINS" % val, "sub": "USED IN A LATER UPDATE", "kind": kind}
        elif kind == "puzzle":
            self.save["puzzle_points"] = self.save.get("puzzle_points", 0) + val
            self.event_popup = {"title": "+%d PUZZLE POINTS" % val, "sub": "USED IN A LATER UPDATE", "kind": kind}
        else:
            card = self.event_reward_card(i)
            count = self.give_card(card)
            self.pack_reveal = {"card": card, "t": 0.0, "count": count, "pack": 0,
                                "tier": self.card_pool(card), "opened": True, "back": "event",
                                "art": self.box_art}
            self.fx = []
            self.state = PACK_OPEN
        self.write_save()

    def draw_reward_icon(self, w, kind, centre, size=1.0):
        x, y = centre
        s = size
        if kind == "coins":
            for j in range(3):
                r = pygame.Rect(0, 0, int(80 * s), int(34 * s))
                r.center = (x + (j - 1) * int(18 * s), y + int(14 * s) - j * int(16 * s))
                pygame.draw.ellipse(w, (190, 140, 20), r.move(0, int(6 * s)))
                pygame.draw.ellipse(w, YELLOW, r)
                pygame.draw.ellipse(w, (255, 244, 170), r.inflate(-int(40 * s), -int(16 * s)))
        elif kind == "training":
            pygame.draw.circle(w, (30, 90, 200), (x, y), int(40 * s))
            pygame.draw.circle(w, (140, 200, 255), (x, y), int(40 * s), max(2, int(6 * s)))
            t = self.font_m.render("T", True, WHITE)
            t = pygame.transform.smoothscale(t, (int(t.get_width() * s), int(t.get_height() * s)))
            w.blit(t, t.get_rect(center=(x, y)))
        elif kind == "puzzle":
            c = (170, 70, 220)
            pygame.draw.rect(w, c, (x - int(34 * s), y - int(26 * s), int(68 * s), int(60 * s)), border_radius=6)
            pygame.draw.circle(w, c, (x, y - int(30 * s)), int(15 * s))
            pygame.draw.circle(w, c, (x + int(38 * s), y + int(4 * s)), int(15 * s))
            pygame.draw.rect(w, (230, 180, 255), (x - int(34 * s), y - int(26 * s), int(68 * s), int(60 * s)),
                             max(2, int(4 * s)), border_radius=6)

    def draw_event(self, w):
        if self.event_bg is not None:
            w.blit(self.event_bg, (0, 0))
        else:
            w.fill((0, 110, 52))
        L = self.event_layout()
        ev = self.event_state()
        mouse = pygame.mouse.get_pos()
        self.draw_back_button(w)
        t = self.outlined("THE WORLD'S GAME BOX", self.font_m, WHITE, 1.0, width=4)
        w.blit(t, (270, 36))
        # currencies, top right
        self.draw_coins(w)
        cur = "%d TRAINING   %d PUZZLE" % (self.save.get("training_coins", 0), self.save.get("puzzle_points", 0))
        img = self.font_s.render(cur, True, (220, 236, 255))
        w.blit(img, img.get_rect(topright=(WIDTH - 60, 104)))
        # left: Neymar
        face = self.icon_faces.get(NEYMAR_CARD)
        if face is not None:
            big = pygame.transform.scale(face, (384, 384))
            w.blit(big, (48, 196))
        pts = []
        for i in range(40):
            tt = i / 39.0
            pts.append((70 + tt * 300, 560 + math.sin(tt * 13.0) * 26 * (1 - tt * 0.5) - tt * 40))
        pygame.draw.lines(w, (255, 230, 130), False, pts, 6)
        plate = pygame.Rect(40, 610, 400, 120)
        veil = pygame.Surface(plate.size, pygame.SRCALPHA)
        veil.fill((0, 30, 16, 200))
        w.blit(veil, plate.topleft)
        for txt, y, col, font in (("NEYMAR JR", plate.y + 38, WHITE, self.font_m),
                                  ("150 OVR  -  SIGNATURE", plate.y + 90, (255, 226, 120), None)):
            img = self.label(txt, plate.w - 30, col, font)
            w.blit(img, img.get_rect(center=(plate.centerx, y)))
        # reward tiles
        sp = self.event_spin
        lit = sp["hops"][sp["step"]] if sp else None
        for i, r in enumerate(L["tiles"]):
            kind, val = NEYMAR_REWARDS[i]
            claimed = i in ev["claimed"]
            jack = kind.startswith("jackpot")
            face = (255, 222, 120) if jack else (246, 242, 226)
            pygame.draw.rect(w, face if not claimed else (120, 124, 120), r, border_radius=10)
            if jack:
                tag = self.fit_text("JACKPOT", self.font_s, (150, 40, 20), r.w * 0.7, 24)
                w.blit(tag, tag.get_rect(center=(r.centerx, r.y + 18)))
            if kind == "jackpot_coins":
                kind = "coins"
            if kind in ("coins", "training", "puzzle"):
                self.draw_reward_icon(w, kind, (r.centerx, r.y + 66), 0.8)
                amt = self.label("x%d" % val, r.w - 30, INK, self.font_m)
                w.blit(amt, amt.get_rect(center=(r.centerx, r.bottom - 32)))
                if kind != "coins":
                    tag = self.font_s.render("LATER UPDATE", True, (120, 80, 160))
                    k = min(1.0, (r.w - 24) / tag.get_width(), 22 / tag.get_height())
                    tag = pygame.transform.smoothscale(tag, (int(tag.get_width() * k), int(tag.get_height() * k)))
                    w.blit(tag, tag.get_rect(center=(r.centerx, r.y + 18)))
            else:
                card = self.event_reward_card(i)
                if card is not None:
                    cr = pygame.Rect(0, 0, 92, 128)
                    cr.center = (r.centerx, r.centery + (8 if jack else 0))
                    self.draw_card(w, card, cr)
            if claimed:
                veil = pygame.Surface(r.size, pygame.SRCALPHA)
                veil.fill((0, 0, 0, 120))
                w.blit(veil, r.topleft)
                pygame.draw.lines(w, (90, 230, 110), False, [(r.centerx - 40, r.centery), (r.centerx - 10, r.centery + 30),
                                                             (r.centerx + 46, r.centery - 36)], 12)
            border = YELLOW if lit == i else (WHITE if r.collidepoint(mouse) else (30, 60, 34))
            pygame.draw.rect(w, border, r, 8 if lit == i else 3, border_radius=10)
        # the prize
        pr = L["prize"]
        claimed = (len(NEYMAR_REWARDS) - 1) in ev["claimed"]
        pygame.draw.rect(w, (250, 238, 200), pr, border_radius=14)
        cr = pygame.Rect(0, 0, 320, 444)
        cr.center = (pr.centerx, pr.centery - 10)
        self.draw_card(w, self.cards[NEYMAR_CARD], cr, dim=claimed)
        if claimed:
            self.centre_text_at(w, "CLAIMED", pr.centerx, pr.bottom - 30, (40, 140, 60), self.font_m)
        pygame.draw.rect(w, YELLOW if lit == len(NEYMAR_REWARDS) - 1 else (190, 150, 50), pr,
                         10 if lit == len(NEYMAR_REWARDS) - 1 else 5, border_radius=14)
        # bottom bar
        bar = pygame.Rect(470, 800, 854, 110)
        veil = pygame.Surface(bar.size, pygame.SRCALPHA)
        veil.fill((250, 238, 200, 230))
        w.blit(veil, bar.topleft)
        for txt, y, col in (("EACH REWARD ONCE  -  JACKPOTS 1% EACH  -  NEYMAR 0.05% (SURE ON THE LAST DRAW)",
                             bar.y + 36, INK),
                            ("DRAW %d OF %d" % (min(len(ev["claimed"]) + 1, len(NEYMAR_REWARDS)),
                                                len(NEYMAR_REWARDS)), bar.y + 80, (90, 90, 90))):
            img = self.font_s.render(txt, True, col)
            k = min(1.0, (bar.w - 40) / img.get_width())
            img = pygame.transform.smoothscale(img, (int(img.get_width() * k), int(img.get_height() * k)))
            w.blit(img, img.get_rect(center=(bar.centerx, y)))
        price = self.event_price()
        b = L["buy"]
        afford = price is not None and self.save["coins"] >= price
        col = (40, 170, 70) if afford else (90, 100, 92)
        pygame.draw.rect(w, col, b, border_radius=50)
        pygame.draw.rect(w, YELLOW if b.collidepoint(mouse) and afford else WHITE, b, 6, border_radius=50)
        label = "SOLD OUT" if price is None else ("FREE" if price == 0 else "%d COINS" % price)
        lab = self.label(label, b.w - 40, WHITE, self.font_m)
        w.blit(lab, lab.get_rect(center=b.center))
        # reward popup
        if self.event_popup is not None:
            wash(w, (0, 0, 0, 170))
            box = pygame.Rect(0, 0, 900, 420)
            box.center = (WIDTH // 2, HEIGHT // 2)
            pygame.draw.rect(w, (250, 238, 200), box, border_radius=20)
            pygame.draw.rect(w, YELLOW, box, 8, border_radius=20)
            self.draw_reward_icon(w, self.event_popup["kind"], (box.centerx, box.y + 120), 1.8)
            self.centre_text_at(w, self.event_popup["title"], box.centerx, box.y + 250, INK, self.font_l)
            if self.event_popup["sub"]:
                self.centre_text_at(w, self.event_popup["sub"], box.centerx, box.y + 320, (110, 90, 140))
            self.centre_text_at(w, "CLICK TO CONTINUE", box.centerx, box.bottom - 40, (90, 90, 90))

    # ---- main menu (like the sketch: art carousel | title + buttons) -----------------
    MENU_ITEMS = ("PLAY", "STORE", "TEAM", "QUIT")
    PLAY_ITEMS = ("WORLD CUP", "CLUB FOOTBALL", "FREEPLAY", "PRACTICE", "BACK")
    PLAY_ITEMS_ONLINE = ("RANKED ONLINE", "WORLD CUP", "CLUB FOOTBALL", "FREEPLAY", "PRACTICE", "BACK")
    SLIDE_SECONDS = 10.0

    def menu_items(self):
        if getattr(self, "menu_page", "main") != "play":
            return self.MENU_ITEMS
        return self.PLAY_ITEMS_ONLINE if self.net.on else self.PLAY_ITEMS

    def menu_layout(self):
        n = len(self.menu_items())
        step = 128 if n <= 5 else 108
        y0 = 330 + (5 - n) * 64 + (24 if n > 5 else 0)     # 4 buttons sit centred where 5 would
        return [pygame.Rect(1180, y0 + i * step, 600, 104 if n <= 5 else 92) for i in range(n)]

    def slide_rect(self):
        return pygame.Rect(210, 170, 560, 680)

    def slide_controls(self):
        n = max(1, len(self.slides))
        dots = [pygame.Rect(0, 0, 30, 30) for _ in range(n)]
        x0 = 490 - (n - 1) * 26 - 110
        for i, r in enumerate(dots):
            r.center = (x0 + i * 52, 905)
        nxt = pygame.Rect(0, 0, 170, 58)
        nxt.center = (x0 + (n - 1) * 52 + 150, 905)
        return dots, nxt

    def current_slide(self):
        now = pygame.time.get_ticks() / 1000.0
        if not hasattr(self, "slide_t0"):
            self.slide_t0, self.slide = now, 0
        if now - self.slide_t0 >= self.SLIDE_SECONDS:     # every 10 s the art changes
            self.slide = (self.slide + 1) % max(1, len(self.slides))
            self.slide_t0 = now
        return self.slide

    def set_slide(self, i):
        self.slide = i % max(1, len(self.slides))
        self.slide_t0 = pygame.time.get_ticks() / 1000.0

    def title_click(self, pos):
        dots, nxt = self.slide_controls()
        if nxt.collidepoint(pos.x, pos.y):
            self.set_slide(self.current_slide() + 1)
            return
        for i, r in enumerate(dots):
            if r.collidepoint(pos.x, pos.y):
                self.set_slide(i)
                return
        if self.slide_rect().collidepoint(pos.x, pos.y):
            s = self.current_slide()
            if s == 0:
                self.menu_page = "play"                    # PLAY NOW
            elif s == 1:
                self.menu_item("WORLD CUP")               # the champions art -> World Cup
            elif s == 2:
                self.open_pack_view(0)                     # World Cup pack
            elif s == 3:
                self.open_event()                          # Neymar Jr Game Box
            elif s == 4:
                self.open_stars()                          # Star Signing
            return
        for item, rect in zip(self.menu_items(), self.menu_layout()):
            if rect.collidepoint(pos.x, pos.y):
                self.menu_item(item)
                return

    def menu_item(self, item):
        if item == "PLAY":
            self.menu_page = "play"
        elif item == "BACK":
            self.menu_page = "main"
        elif item == "WORLD CUP":
            self.mode = "wc"
            self.brain.skill = DIFFICULTY[self.difficulty][1]
            self.go_to_select()
        elif item == "CLUB FOOTBALL":
            self.mode = "club"
            self.go_to_club()
        elif item == "STORE":
            self.open_store()
        elif item == "TEAM":
            self.state = MYCLUB
        elif item == "FREEPLAY":
            self.open_freeplay()
        elif item == "PRACTICE":
            self.start_practice()
        elif item == "RANKED ONLINE":
            self.find_online()
        elif item == "QUIT":
            self.quit_requested = True

    def draw_title(self, w):
        w.blit(self.select_bg, (0, 0))
        mouse = pygame.mouse.get_pos()
        # left: PLAY NOW + the art carousel
        head = self.outlined("PLAY NOW", self.font_l, WHITE, 0.9, width=4)
        w.blit(head, head.get_rect(center=(490, 110)))
        sr = self.slide_rect()
        i = self.current_slide()
        hover = sr.collidepoint(mouse)
        r = sr.move(0, -6) if hover else sr
        pygame.draw.rect(w, (10, 14, 12), r.inflate(22, 22), border_radius=16)
        img = self.slides[i] if self.slides else None
        if img is not None:
            w.blit(pygame.transform.scale(img, r.size), r)
        else:
            pygame.draw.rect(w, (40, 60, 44), r)
        pygame.draw.rect(w, YELLOW if hover else (236, 196, 90), r.inflate(10, 10), 6, border_radius=12)
        left = self.SLIDE_SECONDS - (pygame.time.get_ticks() / 1000.0 - self.slide_t0)
        prog = pygame.Rect(r.x, r.bottom + 14, int(r.w * clamp(1 - left / self.SLIDE_SECONDS, 0, 1)), 6)
        pygame.draw.rect(w, (236, 196, 90), prog)
        dots, nxt = self.slide_controls()
        for k, d in enumerate(dots):
            pygame.draw.circle(w, WHITE, d.center, 13 if k == i else 9, 0 if k == i else 3)
        pygame.draw.rect(w, SELECT_GREEN, nxt, border_radius=28)
        pygame.draw.rect(w, YELLOW if nxt.collidepoint(mouse) else WHITE, nxt, 4, border_radius=28)
        self.centre_in(w, "NEXT >", nxt)
        # the diagonal divider
        pygame.draw.line(w, (230, 236, 230), (1110, -10), (880, HEIGHT + 10), 7)
        # right: title, level, buttons
        title = self.outlined("A SMALL WORLD CUP", self.font_xl, (255, 214, 40), 1.0, width=5)
        if title.get_width() > 760:
            k = 760 / title.get_width()
            title = pygame.transform.smoothscale(title, (int(title.get_width() * k), int(title.get_height() * k)))
        w.blit(title, title.get_rect(center=(1480, 150)))
        self.draw_coins(w)
        self.draw_level(w, 1180, 226, 600)
        for item, rect in zip(self.menu_items(), self.menu_layout()):
            soon = item == "SOON"
            hov = rect.collidepoint(mouse) and not soon
            col = (120, 140, 124) if soon else (YELLOW if hov else WHITE)
            lab = self.outlined(item, self.font_l, col, 1.0, width=4)
            if lab.get_width() > rect.w:
                k = rect.w / lab.get_width()
                lab = pygame.transform.smoothscale(lab, (int(lab.get_width() * k), int(lab.get_height() * k)))
            w.blit(lab, lab.get_rect(center=rect.center))
            if hov:
                for sx in (-1, 1):
                    x = rect.centerx + sx * (lab.get_width() // 2 + 40)
                    pygame.draw.polygon(w, YELLOW, [(x - sx * 14, rect.centery - 18), (x + sx * 8, rect.centery),
                                                    (x - sx * 14, rect.centery + 18)])
        if len(self.save["squad"]) < SQUAD_SIZE and getattr(self, "menu_page", "main") == "play":
            warn = self.label("CLUB FOOTBALL NEEDS 5 PLAYERS - PICK THEM IN TEAM", 760, (255, 140, 140))
            w.blit(warn, warn.get_rect(center=(1480, 1030)))

    def draw_shadow(self, surface, x, bottom_y, width):
        height_above = max(0.0, GROUND_Y - bottom_y)
        k = clamp(1.0 - height_above / 600.0, 0.25, 1.0)
        sw, sh = int(width * 2 * k), max(2, int(12 * k))
        sh_surf = pygame.Surface((sw, sh), pygame.SRCALPHA)
        pygame.draw.ellipse(sh_surf, (0, 0, 0, int(90 * k)), (0, 0, sw, sh))
        surface.blit(sh_surf, (int(x - sw / 2), GROUND_Y - sh // 2 + 2))

    def draw_aim(self, surface):
        """Arrow toward the mouse: longer = more power (strength lets you pull
        it further), and it wobbles for players with low shooting."""
        if not self.dragging:
            return
        p = self.player
        mouse = Vector2(pygame.mouse.get_pos())
        launch = mouse - p.pos
        if launch.length() < 14.0:
            return
        rng = p.drag_range()
        charge = clamp(launch.length() / rng, 0.0, 1.0)
        n = rot(launch.normalize(), p.aim_wobble(pygame.time.get_ticks() * 0.001))
        fill, edge = (250, 248, 236), INK
        if charge >= 0.999:
            fill = (255, 128, 56)                          # maxed out
        side = perp(n)
        tail = p.pos + n * 60.0
        tip = tail + n * (70.0 + ARROW_STRETCH * (rng / THROW_DRAG_RANGE) * charge)
        head_len, hw = 34.0, 5.0
        neck = tip - n * head_len
        pts = [tail + side * hw, neck + side * hw, neck + side * hw * 3.4, tip,
               neck - side * hw * 3.4, neck - side * hw, tail - side * hw]
        pygame.draw.polygon(surface, fill, [(int(q.x), int(q.y)) for q in pts])
        pygame.draw.polygon(surface, edge, [(int(q.x), int(q.y)) for q in pts], 4)

    def draw_clock(self, surface):
        if self.half == 3:
            label, col = "GOLDEN GOAL", YELLOW
        else:
            left = max(0.0, HALF_SECONDS * self.half - self.match_time)
            label = "%s  0:%02d" % ("1ST" if self.half == 1 else "2ND", int(math.ceil(left)))
            col = (255, 120, 120) if left < 5 else WHITE
        img = self.font_m.render(label, True, col)
        pad = tint((img.get_width() + 40, img.get_height() + 16), (10, 14, 24, 150))
        surface.blit(pad, pad.get_rect(midtop=(WIDTH // 2, 24)))
        surface.blit(img, img.get_rect(midtop=(WIDTH // 2, 32)))

    # ---- online: searching, names and chat ------------------------
    def draw_searching(self, w):
        if not self.searching:
            return
        w.blit(tint((WIDTH, HEIGHT), (4, 10, 8, 205)), (0, 0))
        t = self.searching["t"]
        self.centre_text(w, "LOOKING FOR AN OPPONENT", self.font_l, WHITE, 360)
        dots = "." * (1 + int(t * 2) % 3)
        self.centre_text(w, "MATCHMAKING%s" % dots, self.font_m, CYAN, 470)
        self.centre_text(w, "%ds" % int(t), self.font_m, (160, 180, 172), 540)
        r = self.search_cancel_rect()
        pygame.draw.rect(w, (40, 60, 48), r, border_radius=14)
        pygame.draw.rect(w, WHITE if r.collidepoint(pygame.mouse.get_pos()) else (150, 170, 158),
                         r, 3, border_radius=14)
        self.centre_in(w, "CANCEL", r)

    @staticmethod
    def search_cancel_rect():
        return pygame.Rect(WIDTH // 2 - 160, 660, 320, 88)

    def chat_button_rect(self):
        if self.mode != "pvp" or self.state not in (KICKOFF, PLAY, GOAL, FULLTIME):
            return None
        return pygame.Rect(40, HEIGHT - 110, 210, 74)

    def chat_preset_rects(self):
        if not self.chat_open:
            return []
        out = []
        for i, _text in enumerate(CHAT_PRESETS):
            col, row = i % 2, i // 2
            out.append(pygame.Rect(40 + col * 330, HEIGHT - 440 + row * 96, 310, 80))
        return out

    def draw_chat(self, w):
        """Recent messages bottom-left, plus the quick-message buttons when open."""
        if self.mode != "pvp" and not self.chat_log:
            return
        y = HEIGHT - 480 if self.chat_open else HEIGHT - 150      # keep clear of the quick messages
        for name, text, age in self.chat_log[-CHAT_LINES:][::-1]:
            fade = clamp((CHAT_SECONDS - age) / 1.2, 0.0, 1.0)
            line = self.fit_text("%s: %s" % (name.upper(), text.upper()), self.font_s, WHITE, 760, 30)
            pad = tint((line.get_width() + 28, 40), (6, 12, 10, int(170 * fade)))
            w.blit(pad, (36, y - 8))
            img = line.copy()
            img.set_alpha(int(255 * fade))
            w.blit(img, (50, y))
            y -= 46

        btn = self.chat_button_rect()
        if btn is not None:
            w.blit(tint(btn.size, (8, 16, 12, 180)), btn.topleft)
            hot = btn.collidepoint(pygame.mouse.get_pos())
            pygame.draw.rect(w, CYAN if (hot or self.chat_open) else (150, 170, 162), btn, 3, border_radius=12)
            self.centre_in(w, "CHAT", btn, color=CYAN if self.chat_open else WHITE)
        for r, text in zip(self.chat_preset_rects(), CHAT_PRESETS):
            w.blit(tint(r.size, (8, 16, 12, 200)), r.topleft)
            hot = r.collidepoint(pygame.mouse.get_pos())
            pygame.draw.rect(w, YELLOW if hot else (150, 170, 162), r, 3, border_radius=12)
            lab = self.fit_text(text, self.font_s, WHITE, r.w - 24, 30)
            w.blit(lab, lab.get_rect(center=r.center))

    def chat_click(self, pos):
        """The CHAT button and its quick messages. True if the click was ours."""
        for r, text in zip(self.chat_preset_rects(), CHAT_PRESETS):
            if r.collidepoint(pos):
                self.send_chat(text)
                self.chat_open = False
                return True
        btn = self.chat_button_rect()
        if btn is not None and btn.collidepoint(pos):
            self.chat_open = not self.chat_open
            return True
        if self.chat_open:
            self.chat_open = False        # tapping the pitch closes it, no throw
            return True
        return False

    def pvp_plate_top(self, card):
        """Under the ability chips on that side, whatever the card happens to have."""
        rows = len(ability_list(card)) if card else 0
        return 132 + rows * 46 + (14 if rows else 0)

    def draw_pvp_plate(self, w, name, rank, colour, left):
        pad = 16
        who = self.fit_text(name.upper(), self.font_s, colour, 300, 32)
        line = self.fit_text(str(rank).upper(), self.font_s, (180, 200, 190), 300, 26) if rank else None
        width = max(who.get_width(), line.get_width() if line else 0) + pad * 2
        height = 44 + (30 if line else 0)
        card = getattr(self, "my_card" if left else "cpu_card", None)
        top = self.pvp_plate_top(card)
        box = pygame.Rect(34 if left else WIDTH - 34 - width, top, width, height)
        w.blit(tint(box.size, (8, 12, 24, 160)), box.topleft)
        pygame.draw.rect(w, (colour[0] // 2 + 60, colour[1] // 2 + 60, colour[2] // 2 + 60),
                         box, 2, border_radius=10)
        w.blit(who, (box.x + pad, box.y + 8))
        if line:
            w.blit(line, (box.x + pad, box.y + 46))

    def draw_pvp_names(self, w):
        if self.mode != "pvp" or self.pvp is None:
            return
        self.draw_pvp_plate(w, self.pvp["name"], self.pvp.get("rank", ""), (150, 220, 255), True)
        self.draw_pvp_plate(w, self.pvp["opp"], self.pvp.get("oppRank", ""), (255, 170, 150), False)
        if not self.net.connected_hint():
            warn = self.fit_text("RECONNECTING...", self.font_s, (255, 150, 150), 400, 30)
            w.blit(warn, warn.get_rect(midtop=(WIDTH // 2, 118)))

    def draw_hud(self, surface):
        self.draw_clock(surface)
        home = self.font_l.render(str(self.score_home), True, HOME_KIT["shirt"])
        away = self.font_l.render(str(self.score_away), True, AWAY_KIT["shirt"])
        hx, ax = 48, WIDTH - 48
        if self.mode == "club" and self.club is not None and self.club_opps:
            hb, ab = self.clubs[self.club]["badge"], self.clubs[self.club_opps[-1]]["badge"]
            for img, left in ((hb, True), (ab, False)):
                if img is not None:
                    img = fit_flag(img, 64, 76)
                    surface.blit(img, (hx, 32) if left else (ax - img.get_width(), 32))
            hx += 84
            ax -= 84
        elif self.mode == "free" and self.my_card and self.cpu_card:
            for card, left in ((self.my_card, True), (self.cpu_card, False)):
                img = self.card_badge(card)
                if img is not None:
                    img = fit_flag(img, 72, 76)
                    surface.blit(img, (hx, 32) if left else (ax - img.get_width(), 32))
            hx += 92
            ax -= 92
        elif self.team is not None and self.opponents:
            hf = fit_flag(self.teams[self.team]["flag"], 96, 64)
            af = fit_flag(self.teams[self.opponents[-1]]["flag"], 96, 64)
            surface.blit(hf, (hx, 40))
            surface.blit(af, (ax - af.get_width(), 40))
            hx += hf.get_width() + 20
            ax -= af.get_width() + 20
        surface.blit(home, (hx, 30))
        surface.blit(away, (ax - away.get_width(), 30))
        self.draw_pause_button(surface)
        self.draw_pvp_names(surface)
        self.draw_ability_hud(surface)

    PAUSE_BTN = pygame.Rect(WIDTH // 2 + 205, 26, 96, 74)

    def pause_button_rect(self):
        """The on-screen stand-in for Esc (touch devices have no keyboard)."""
        return self.PAUSE_BTN if self.state in (KICKOFF, PLAY) and self.mode != "practice" else None

    def draw_pause_button(self, surface):
        r = self.pause_button_rect()
        if r is None:
            return
        surface.blit(tint(r.size, (10, 14, 24, 150)), r.topleft)
        hot = r.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(surface, YELLOW if hot else (200, 214, 208), r, 3, border_radius=10)
        for i in (-1, 1):                                    # two pause bars
            bar = pygame.Rect(0, 0, 12, 34)
            bar.center = (r.centerx + i * 13, r.centery)
            pygame.draw.rect(surface, YELLOW if hot else (222, 232, 226), bar, border_radius=3)

    def draw_ability_hud(self, surface):
        """Your abilities down the left, the CPU's down the right."""
        for card, left in ((getattr(self, "my_card", None), True), (getattr(self, "cpu_card", None), False)):
            if card is None:
                continue
            for i, (ab, tier) in enumerate(ability_list(card)):
                col = ABILITY_TIERS[tier][1]
                chip = pygame.Rect(0, 0, 250, 40)
                chip.topleft = (34, 132 + i * 46) if left else (WIDTH - 284, 132 + i * 46)
                surface.blit(tint(chip.size, (8, 12, 24, 165)), chip.topleft)
                pygame.draw.rect(surface, col, chip, 3, border_radius=10)
                pygame.draw.circle(surface, col, (chip.x + 20, chip.centery), 9)
                lab = self.fit_text(ab["name"], self.font_s, WHITE, chip.w - 52, 26)
                surface.blit(lab, lab.get_rect(midleft=(chip.x + 38, chip.centery)))

    def draw_banner(self, surface):
        surface.blit(tint((WIDTH, HEIGHT), (8, 10, 18, 150)), (0, 0))
        pop = self.goal_text_pop
        scale = 1.0 + (1.0 - pop) * 1.4 - math.sin(pop * math.pi) * 0.12
        if self.state == FULLTIME and getattr(self, "forfeited", False):
            title, col = "FORFEIT", AWAY_KIT["shirt"]
        elif self.state == FULLTIME and self.mode in ("club", "free"):
            if self.score_home > self.score_away:
                title, col = "YOU WIN", HOME_KIT["shirt"]
            elif self.score_home == self.score_away:
                title, col = "DRAW", WHITE
            else:
                title, col = "YOU LOSE", AWAY_KIT["shirt"]
        elif self.state == FULLTIME:
            if self.score_home > self.score_away and self.team is not None \
                    and self.round + 1 >= len(ROUNDS):
                title, col = "CHAMPIONS!", YELLOW
            elif self.score_home > self.score_away:
                title, col = "YOU WIN", HOME_KIT["shirt"]
            elif self.score_away > self.score_home:
                title = "GAME OVER" if self.team is not None else "CPU WINS"
                col = AWAY_KIT["shirt"]
            else:
                title, col = "DRAW", WHITE
        else:
            title = "OWN GOAL!" if self.own_goal else "GOAL!"
            col = HOME_KIT["shirt"] if self.last_scorer == "home" else AWAY_KIT["shirt"]
        base = self.font_xl.render(title, True, col)          # CachedFont: rendered once
        shadow = self.font_xl.render(title, True, INK)
        # the banner zooms in every frame - round the size so the scaled copies are reused,
        # and use the cheap scaler: the whole frame is pixel-downscaled a moment later anyway
        size = (max(1, int(base.get_width() * scale)) // 8 * 8,
                max(1, int(base.get_height() * scale)) // 8 * 8)
        try:
            big = scaled(base, size)
            big_sh = scaled(shadow, size)
        except Exception:
            big, big_sh = base, shadow
        cx, cy = WIDTH // 2, int(HEIGHT * 0.36)
        surface.blit(big_sh, big_sh.get_rect(center=(cx + 8, cy + 10)))
        surface.blit(big, big.get_rect(center=(cx, cy)))
        self.centre_text(surface, f"{self.score_home}  -  {self.score_away}", self.font_l, WHITE,
                         HEIGHT * 0.52)
        if self.state != FULLTIME:
            prompt = "CLICK TO CONTINUE"
        elif self.mode == "club":
            prompt = "CLICK FOR THE LEAGUE TABLE"
        elif self.mode == "free":
            prompt = "CLICK TO PICK THE NEXT MATCH"
        elif self.team is None:
            prompt = "CLICK TO PLAY AGAIN"
        elif self.score_home > self.score_away:
            prompt = "CLICK TO CONTINUE"
        else:
            prompt = "CLICK TO RESTART"
        self.centre_text(surface, prompt, self.font_s, (206, 212, 228), HEIGHT * 0.62)
        if self.state == FULLTIME and self.last_earned:
            extra = "  (IMPOSSIBLE x%d)" % IMPOSSIBLE_COINS if self.impossible_run() else ""
            self.centre_text(surface, "+%d COINS%s" % (self.last_earned, extra), self.font_m, YELLOW,
                             HEIGHT * 0.69)
        if self.state == FULLTIME and self.last_xp:
            self.centre_text(surface, "+%d XP" % self.last_xp, self.font_m, (140, 220, 255), HEIGHT * 0.76)
            self.draw_level(surface, WIDTH // 2 - 260, int(HEIGHT * 0.84), 520)

    def centre_text(self, surface, text, font, color, y):
        s = font.render(text, True, color)
        surface.blit(s, (WIDTH // 2 - s.get_width() // 2, int(y)))

    # ---- loop --------------------------------------------
    def run(self, max_frames=None, autoplay=False):
        """Desktop entry point. The browser build goes through run_async()."""
        asyncio.run(self.run_async(max_frames, autoplay))

    def show_crash(self, exc):
        """Browser build: paint the error on the canvas and print it to the console."""
        if not getattr(self, "crashed", False):
            self.crashed = True
            try:
                import traceback
                traceback.print_exc()                      # shows up in the browser console
            except Exception:
                pass
        try:
            self.screen.fill((16, 20, 28))
            w, h = self.screen.get_size()
            lines = (("SOMETHING BROKE", (255, 120, 120)),
                     ("%s: %s" % (type(exc).__name__, exc), (235, 235, 235)),
                     ("open the browser console (F12) for the full details", (170, 180, 190)))
            for i, (text, col) in enumerate(lines):
                img = self.font_s.render(text[:78], True, col)
                self.screen.blit(img, img.get_rect(center=(w // 2, h // 2 + (i - 1) * 46)))
        except Exception:
            pass

    async def run_async(self, max_frames=None, autoplay=False):
        frames = 0
        running = True
        while running:
            dt = min(self.clock.tick(FPS) / 1000.0, 1.0 / 30.0)
            running = self.handle_events()
            if autoplay and self.state == TITLE:
                self.mode = "wc"
                self.state = SELECT
            if autoplay and self.state == LINEUP:
                self.pick_player([c for c in self.lineup_cards() if self.available(c)][0])
            if autoplay and self.state == SELECT and self.roulette is None:
                if self.team is None:
                    self.new_tournament(0)
                self.start_draw()
            if autoplay and self.state == PLAY and frames % 45 == 0:
                target = self.ball.pos + Vector2(-60, -120)
                self.release_throw(target)
            if WEB_BUILD:
                try:
                    self.update(dt)
                    self.draw()
                except Exception as exc:                   # grey screens tell you nothing
                    self.show_crash(exc)
            else:
                self.update(dt)
                self.draw()
            pygame.display.flip()
            frames += 1
            if max_frames is not None and frames >= max_frames:
                running = False
            await asyncio.sleep(0)         # hands the frame back to the browser (pygbag)
        pygame.quit()


# ==========================================================
# ENTRY
# ==========================================================
def web_flag(name):
    """?small=1 style switches on the game frame's own URL (browser build only)."""
    if not WEB_BUILD:
        return False
    try:
        return name in (js_window().location.search or "")
    except Exception:
        return False


async def main():
    selftest = "--selftest" in sys.argv
    if selftest:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    try:
        pygame.mixer.pre_init(44100, -16, 2, MIXER_BUFFER)
    except Exception:
        pass
    pygame.init()
    if web_flag("small") and PIXEL > 1:
        globals()["WEB_VIEW"] = True                   # draw straight into a 640 x 360 canvas
        globals()["VIEW_SCALE"] = PIXEL
    game = Game(headless=selftest)
    if selftest:
        await game.run_async(max_frames=600, autoplay=True)
        print("selftest ok: 600 frames simulated, score %d-%d" % (game.score_home, game.score_away))
    else:
        await game.run_async()
    if not WEB_BUILD:
        sys.exit(0)


# pygbag runs this file as main.py and needs the whole game inside one asyncio task
if __name__ == "__main__":
    asyncio.run(main())
